
param(
	[string[]] $ndtests = (
		"ndping",
		"ndrping",
		"ndpingpong",
		"ndrpingpong",
		"ndmrrate",
		"ndmrlat",
		"ndmpic",
		"ndmw"),
	[string[]] $mpitests = (
		"mpi_allreduce", 
		"mpi_alltoall", 
		"mpi_alltoallv",
		"mpi_bcast",
		"mpi_intercomm_create1",
		"mpi_isend_perf",
		"mpi_reduce",
		"mpi_send_flood",
		"accfence1",
		"async",
		"coll2",
		"coll13",
		"putpscw1",
		"scattern",
		"sendmany",
		"sendrecv1",
		"transpose1")
)

$ErrorActionPreference = "SilentlyContinue"

$output = @()
$output += Set-Location ..
$env:ndlogo_root = (Get-Location).Path

$logoStartTime = Get-Date
$resultsDirName = "Results-$($logoStartTime.ToString('yyyyMMdd-HHmmss'))"
$resultsdir = mkdir "$($env:ndlogo_root)\$resultsdirname"

"`tSaving results to $($resultsdir.FullName)"
$env:ndlogo_logfile = "$($resultsdir.FullName)\ndlogo_tests.log"


$output += . $env:ndlogo_root\scripts\load-guifunctions.ps1 

$output += Get-PSSnapin -Name Microsoft.Hpc # | Out-Null

if (-not $?)
{
	$output += Add-PSSnapin Microsoft.Hpc # | Out-Null # load HPC Powershell cmdlets
}

if (-not $?) 
{
	$errormsg = "Failed to load HPC Powershell Snapins."
	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}
else
{
	$output += log "`tHPC Powershell cmdlets loaded."
}

$output += . $env:ndlogo_root\scripts\load-ndlogofunctions.ps1

$output += . {
	net share /d ndlogo 
	net share ndlogo="$($resultsdir.FullName)" /grant:"everyone,full"
} # >> $env:ndlogo_logfile

if (-not $?) 
{
	$errormsg = `
"Failed to create results share.
(Did you run this script with administrative priviliges?)"

	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}


$output += . { 
	net share /d ndlogotests
	net share ndlogotests="$($env:ndlogo_root)\bin\amd64" /grant:"everyone,full"
} # >> $env:ndlogo_logfile 

if (-not $?) 
{
	$errormsg = `
"Failed to create test binaries share.
(Did you run this script with administrative priviliges?)"

	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}

$env:ndlogo_share = "\\$(hostname)\ndlogo"
$output += log "`tNDLogo Share:  $($env:ndlogo_share)"
$env:ndlogo_testshare = "\\$(hostname)\ndlogotests"
$output += log "`tNDLogo Tests Share: $($env:ndlogo_testshare)"

if (-not (( Get-HpcNetworkTopology ) -match "Application"))
{
	$errormsg = 
"You haven't configured an Application network.
Please check your network topology in the Cluster Manager.
You must configure the 'Private / Application' or the 
'Enterprise / Private / Application' topology, with your 
NetworkDirect devices on the Application network."

	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}

$headnodend = Get-HpcNetworkInterface -Type Application

if (-not $headnodend) 
{
	$errormsg = 
"Your Application network seems to be misconfigured.
Your headnode does not have a NIC identified as 'Application'.
Your headnode must have a NetworkDirect device installed on 
its Application network interface."

	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}

$output += .$env:ndlogo_testshare\ndcat.exe $headnodend.IpAddress # >> $env:ndlogo_logfile
if (-not $?) 
{
	$errormsg = `
"Your Application network seems to be misconfigured.
NetworkDirect does not appear to be enabled 
on your Application network interface."

	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}
else
{
$output += log `
"`tApplication network configured: $($headnodend.IpAddress)/$($headnodend.SubnetMask)
`tNetworkDirect-enabled device detected on Application network: $($headnodend.Name)"
}

$onlinenodes = ( Get-HpcClusterOverview ).ReadyNodeCount
if ($onlinenodes -lt 8)
{
	$errormsg = 
"Your cluster must contain at least 8 online nodes to run
the NetworkDirect logo suite."

	$output += show-errordialog -errormsg $errormsg
	$output >> $env:ndlogo_logfile ; exit 255
}

$output += log "`tTaking headnode offline for NetworkDirect functional tests..."
$output += Get-HpcNode -GroupName HeadNodes | Set-HpcNodeState -State Offline 

$output += Get-HpcGroup -Name NDLogo # >> $env:ndlogo_logfile

if ($?) { $groupname = "NDLogo" } else { $groupname = "ComputeNodes" }

$output += log "`tUsing group $groupname for NetworkDirect functional tests..."
$nodes = Get-HpcNode -State Online -GroupName $groupname
$output += $nodes
$errorcount = 0
foreach ($node in $nodes) 
{
	$nodeip = `
		[System.Net.Dns]::GetHostAddresses( `
			"Application.$($node.NetBiosName)") | % { $_.IPAddressToString }

	if (-not $?)
	{
		$errorcount += 1
		$nodeip = "0.0.0.0"
	}
	
	$output += Add-Member `
		-InputObject $node `
		-MemberType NoteProperty `
		-Name ApplicationIpAddress `
		-Value $nodeip
}

if (($onlinenodes - $errorcount) -lt 7)
{
	$errormsg = 
"The Application network IP address of $errorcount of your compute 
nodes can not be found c:\windows\system32\drivers\etc\hosts.

Please check the configuration of your Application network."

	$output += show-errordialog -errormsg $errormsg
	$goodnodes = ($onlinenodes | Format-Table -auto)
	$output += log $goodnodes
	$output >> $env:ndlogo_logfile ; exit 255
}

$nodes = $nodes | ?{$_.ApplicationIpAddress -and $_.ApplicationIpAddress -ne "0.0.0.0"}

$output >> $env:ndlogo_logfile

$output = @()

foreach ($ndtest in $ndtests) 
{
	$output += log "`tRunning test: $ndtest ..."
	run-ndtest -test $ndtest -nodes $nodes
	$result = check-ndtest -test $ndtest `
					-outdir $env:ndlogo_share\$ndtest `
					-summaryfile $env:ndlogo_share\results_summary.txt
	$output += log "`t`t$result"
}

$output >>  $env:ndlogo_logfile
$output = @()

$output += Get-HpcNode -GroupName Headnodes | Set-HpcNodeState -State Online

$output += Set-HpcClusterProperty -Environment "MPICH_DISABLE_SOCK=1","MPICH_DISABLE_ND=0"

foreach ($mpitest in $mpitests)
{
	$output += log "`tRunning test: $mpitest ..."
	$job, $output2 = run-ndmpitest -testname $mpitest -groupname $groupname
	$output += $output2
	$result = check-mpitest -test $mpitest `
					-job $job `
					-outdir $env:ndlogo_share\$mpitest `
					-summaryfile $env:ndlogo_share\results_summary.txt
	$output += log "`t`t$result"
}

$output >> $env:ndlogo_logfile
$output = @()

#process results

$results = @()
$results += "Summary of results ($((get-item $env:ndlogo_share\results_summary.txt).FullName)):"
$results += (gc $env:ndlogo_share\results_summary.txt)

$resultszip = zip-ndresultsfolder( $resultsdir )

$message = 
"
The NetworkDirect Logo test suite has finished.

Your results for submission have been placed in
$resultszip"

$results | out-host

$output += show-alertdialog -message $message

$output >> $env:ndlogo_logfile