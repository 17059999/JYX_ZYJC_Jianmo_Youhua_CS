[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

function log( $message, $logfile = $env:ndlogo_logfile )
{
	"$message"
	"$message" | Out-Host

}

function show-errordialog([string] $errormsg)
{
	log "$errormsg" 
	[System.Windows.Forms.MessageBox]::Show( `
		$errormsg, `
		"NDLogo Test Fatal Error", `
		[System.Windows.Forms.MessageBoxButtons]::OK, `
		[System.Windows.Forms.MessageBoxIcon]::Error )

}

function show-alertdialog([string] $message)
{
	log "$message" 
	[System.Windows.Forms.MessageBox]::Show( `
		$message, `
		"NDLogo Test Suite", `
		[System.Windows.Forms.MessageBoxButtons]::OK, `
		[System.Windows.Forms.MessageBoxIcon]::Information )
}

