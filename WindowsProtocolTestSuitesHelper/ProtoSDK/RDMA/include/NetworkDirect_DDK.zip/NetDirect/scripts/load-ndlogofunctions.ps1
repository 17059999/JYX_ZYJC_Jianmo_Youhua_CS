
$ndtestrunner = @{}
$ndtestchecker = @{}

#ndping
$ndtestrunner["ndping"] = 
{
	param( [object[]] $nodes )
	run-ndlogotestpair -testname "ndping" -nodes $nodes[1,2] # # >> $env:ndlogo_logfile
}

#ndrping
$ndtestrunner["ndrping"] = 
{
	param( [object[]] $nodes )
	run-ndlogotestpair -testname "ndrping" -nodes $nodes[3,4] # # >> $env:ndlogo_logfile
}

#ndpingpong
$ndtestrunner["ndpingpong"] = 
{
	param( [object[]] $nodes )
	run-ndlogotestpair -testname "ndpingpong" -nodes $nodes[5,6] # # >> $env:ndlogo_logfile
}

#ndrpingpong
$ndtestrunner["ndrpingpong"] = 
{
	param( [object[]] $nodes )
	run-ndlogotest -testname "ndrpingpong" -clientnode $nodes[0] -mode "poll"
}

 #ndconn
$ndtestrunner["ndconn"] = 
{
	param( [object[]] $nodes )
	run-ndconntestpair -testname "ndconn" -nodes $nodes[2,3] -mode "poll"
}


#ndmrrate
$ndtestrunner["ndmrrate"] = 
{
	param( [object[]] $nodes )
	run-ndmrtestpair -testname "ndmrrate" -nodes $nodes[4,5] # # >> $env:ndlogo_logfile
}

$ndtestrunner["ndmrlat"] = 
{
	param( [object[]] $nodes )
	run-ndmrtestpair -testname "ndmrlat" -nodes $nodes[6,0] # # >>  $env:ndlogo_logfile
}

#ndmpic
$ndtestrunner["ndmpic"] = 
{
	param( [object[]] $nodes )
	run-ndmpisim -testname "ndmpic" -clientnode $nodes[1] # # >> $env:ndlogo_logfile
}

#ndmw
$ndtestrunner["ndmw"] = 
{
	param( [object[]] $nodes )
	run-ndmpisim -testname "ndmw" -clientnode $nodes[2] # # >> $env:ndlogo_logfile
}

function run-ndtest( [string] $test, [object[]] $nodes)
{
	&$ndtestrunner[$test] -nodes $nodes
}

function check-ndtest( [string] $test, [string] $outdir, [string] $summaryfile )
{
	# &$ndtestchecker[$test] -outdir $outdir -summaryfile $summaryfile
	$passed = $TRUE; $faillines = @()
	
	foreach ($file in (dir $outdir))
	{
		(gc $file.FullName) | Out-Null # make sure file is up-to-date
	}
	foreach ($file in (dir $outdir))
	{
		foreach ($line in (gc $file.FullName))
		{
			if ($line -match "Line:" -or $line -match "failed") 
			{ 
				$faillines += "`t$($file.FullName): `t$line"  
				$passed = $FALSE
			}
		}
	}
	
	if ($passed) { $result = "$test passed" } else { $result = "$test failed" }
	$result >> $summaryfile
	$faillines >> $summaryfile
	$result
}

function check-mpitest( [string] $test, $job, [string] $outdir, [string] $summaryfile )
{
	$passed = $TRUE ; $faillines = @();
	$job.Refresh()
	if ($job.State -ne "Finished") 
	{ 
		$passed = $FALSE ; 
		$faillines += "`t$test job $($job.id) completed in state $($job.state)"
	} 
	else 
	{ 
		foreach ($file in (dir $outdir))
		{
			(gc $file.FullName) | Out-Null # make sure file is up-to-date
		}
		foreach ($file in (dir $outdir))
		{
			foreach ($line in (gc $file.FullName))
			{
				if ($line -match "^Summary:")
				{ 
					$null = $line -match "Failed=(\d+)"
					if (([int] $matches[1]) -gt 0) 
					{
						$faillines += "`t$($file.FullName): `t$line"  
						$passed = $FALSE
					}			
				}
			}
		}
	}
	if ($passed) { $result = "$test passed" } else { $result = "$test failed" }
	$result >> $summaryfile
	$faillines >> $summaryfile
	$result
}

function WaitFor-HpcJob( $job, [switch] $print ) 
{
	. { 
		if (-not $job) { exit; }
		while ($job.state -ne "Finished" `
		-and $job.state -ne "Canceled" `
		-and $job.state -ne "Failed") 
{
			$job.Refresh()
			if ($print) { $job.state }
			sleep -seconds 1
		}
	} # # >> $env:ndlogo_logfile
}

function mkdir-ifneeded( [string] $path )
{
	if (-not (Test-Path $path)) { mkdir $path } else { get-item $path } # # >> $env:ndlogo_logfile
}

function run-ndlogotestpair( 
[string] $testname,
[object[]] $nodes)
{

	run-ndlogotest -testname $testname -clientnode $nodes[0] -mode "poll"
	run-ndlogotest -testname $testname -clientnode $nodes[1] -mode "block"

}

function run-ndlogotest(
[string] $testname,
[string] $ndlogo = $env:ndlogo_share,
[string] $ndlogotests = $env:ndlogo_testshare,
[string] $mode,
$clientnode)
{

	$null = mkdir-ifneeded $ndlogo\$testname
	$serverip = (Get-HpcNetworkInterface -Type Application).IpAddress

	if ($mode -eq "poll") { $s = "p1" }
	else { $s = "b1" }

	# "cmd /c start cmd /c $ndlogotests\$testname.exe s $serverip 8989 $s `"l$ndlogo\$testname\$testname-$mode-server-results.txt`""

	log "`t`tServer start ($(hostname))." >> $env:ndlogo_logfile
	cmd /c start cmd /c $ndlogotests\$testname.exe s $serverip 8989 $s "l$ndlogo\$testname\$testname-$mode-server-results.txt"
	sleep -Seconds 5
	log "`t`tClient start ($($clientnode.NetBiosName))." >> $env:ndlogo_logfile
	clusrun /nodes:"$($clientnode.NetBiosName)" /interleaved $ndlogotests\$testname.exe c $serverip 8989 $s "l$ndlogo\$testname\$testname-$mode-client-results.txt" > $null

	taskkill /im "$testname.exe" /f 2> $null > $null
}

function run-ndconntestpair(
[string] $testname,
[object[]] $nodes)
{
	run-ndconntest -testname $testname -clientnode $nodes[0] -mode "client"
	run-ndconntest -testname $testname -clientnode $nodes[1] -mode "server"
}

function run-ndconntest(
[string] $testname,
[string] $ndlogo = $env:ndlogo_share,
[string] $ndlogotests = $env:ndlogo_testshare,
[string] $mode,
$clientnode)
{
	$null = mkdir-ifneeded $ndlogo\$testname
	$cn = $clientnode.NetBiosName
	$serverip = $clientnode.ApplicationIpAddress

	if ($mode -eq "server") { $ss = "t4"; $cs = "t1" }
	else { $ss = "t1"; $cs = "t4" }

	log "`t`tClient start ($($clientnode.NetBiosName))." >> $env:ndlogo_logfile
	cmd /c start cmd /c call clusrun /nodes:"$cn" /interleaved $ndlogotests\$testname.exe s $serverip 8989 $ss "l$ndlogo\$testname\$testname-$mode-s-results.txt"
	sleep -Seconds 5
	# "cmd /c start cmd /c $ndlogotests\$testname.exe c $serverip 8989 $cs `"l$ndlogo\$testname\$testname-$mode-c-results.txt`""

	log "`t`tServer start ($(hostname))." >> $env:ndlogo_logfile
	.$ndlogotests\$testname.exe c $serverip 8989 $cs "l$ndlogo\$testname\$testname-$mode-c-results.txt"

	taskkill /im "$testname.exe" /f 2> $null > $null
}

function run-ndmrtestpair(
[string] $testname,
[object[]] $nodes)
{
	foreach ($node in $nodes) { run-ndmrtest -testname $testname -clientnode $node }
}

function run-ndmrtest(
[string] $testname,
[string] $ndlogo = $env:ndlogo_share,
[string] $ndlogotests = $env:ndlogo_testshare,
$clientnode)
{
	$null = mkdir-ifneeded $ndlogo\$testname

	$cn = $clientnode.NetBiosName
	$cip = $clientnode.ApplicationIpAddress

	# "clusrun /nodes:$cn /c $ndlogotests\$testname.exe $cip `"l$ndlogo\$testname\$testname-$cn-results.txt`""
	log "`t`tClient start ($cn)." >> $env:ndlogo_logfile
	clusrun /nodes:"$cn" $ndlogotests\$testname.exe "$cip" "l$ndlogo\$testname\$testname-$cn-results.txt" > $null 
}

function run-ndmpisim(
[string] $testname,
[string] $ndlogo = $env:ndlogo_share,
[string] $ndlogotests = $env:ndlogo_testshare,
$clientnode)
{

	$null = mkdir-ifneeded $ndlogo\$testname

	$cn = $clientnode.NetBiosName
	$cip = $clientnode.ApplicationIpAddress
	$serverip = (Get-HpcNetworkInterface -Type Application).IpAddress

	if ($testname -eq "ndmpic") { $s = "1"; $c = "0"}
	else { $s = "s"; $c = "c"; $cip = $serverip ; $port = "8989" }


	log "`t`tServer start ($(hostname))." >> $env:ndlogo_logfile
	cmd /c start cmd /c $ndlogotests\$testname.exe $s $cip $port "l$ndlogo\$testname\$testname-$mode-server-results.txt"
	sleep -Seconds 1
	log "`t`tClient start ($cn)." >> $env:ndlogo_logfile
	clusrun /nodes:"$cn" $ndlogotests\$testname.exe $c $serverip $port "l$ndlogo\$testname\$testname-$mode-client-results.txt" > $null

	taskkill /im "$testname.exe" /f 2> $null

}


function new-ndmpitest(
[string] $testname,
[string] $ndlogo,
[string] $ndlogotests,
[string] $runtime = "20", 
[string] $groupname = "ComputeNodes")

{
	$job = ""
	$output = @()

	.{
		$output += mkdir-ifneeded $ndlogo\$testname

		if ($testname -eq "sendrecv1" -or $testname -eq "transpose1") { $numnodes = 2 }
		elseif ($testname -eq "accfence1" -or $testname -eq "putpscw1") { $numnodes = 4 }
		else { $numnodes = 8 }

		if ($testname -eq "mpi_bcast" -or `
		$testname -eq "coll13" -or `
		$testname -eq "scattern" ) { $corespernode = 4 }
		else { $corespernode = 1 }

		$job = New-HpcJob -Project "ND_Logo_Tests" `
		-Name "$testname" `
		-NumNodes $numnodes `
		-RunTime $runtime
		$output += $job
		if ($groupname -ne "ComputeNodes") { $output += Set-HpcJob -Job $job -NodeGroups $groupname }
		$output += Add-HpcTask -Job $job `
		-NumNodes $numnodes `
		-WorkDir $ndlogotests `
		-RunTime $runtime `
		-Stderr "$ndlogo\$testname\%CCP_JOBID%_STDERR.txt" `
		-Stdout "$ndlogo\$testname\%CCP_JOBID%_STDOUT.txt" `
		-CommandLine "mpiexec -cores $corespernode $ndlogotests\mpi\$testname.exe"
	} 

	return $job, @($output)

}

function run-ndmpitest(
[string] $testname,
[string] $ndlogo = $env:ndlogo_share,
[string] $ndlogotests = $env:ndlogo_testshare,
[string] $groupname = "ComputeNodes",
[string] $runtime = "20")
{
	$job = ""
	$output = @()
	.{
		$job, $output = new-ndmpitest `
		-testname $testname `
		-ndlogo $ndlogo `
		-ndlogotests $ndlogotests `
		-runtime $runtime `
		-groupname $groupname

		$output += Submit-HpcJob -job $job

		$output += WaitFor-HpcJob -job $job

	} 
	return $job,@($output)
}

function zip-ndresultsfolder($results)
{
	$zipheader = "PK" + [char]5 + [char]6 + ("$([char]0)" * 18)

	$zippath = $results.FullName + ".zip"
	Set-Content -Path $zippath -Value $zipheader

	$zipfile = (New-Object -ComObject shell.application).NameSpace($zippath)
	$zipfile.CopyHere($results.FullName)

	return $zippath

}