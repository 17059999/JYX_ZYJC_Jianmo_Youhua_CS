// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndmrlat.cpp - Network Direct memory registration latency test
//

#include "precomp.h"


const SIZE_T x_MaxSize = (4 * 1024 * 1024);
const SIZE_T x_Iterations = 10000;


void ShowUsage()
{
    printf( "ndmrlat <ip> [l<log>]\n"
        "\t<ip> - IPv4 Address\n"
        "\tl - log output to a file named <log>.\n");
}


inline DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}


inline LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}


inline LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}


inline LONGLONG GetFrequency()
{
    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    return Frequency.QuadPart;
}


void RunTest( INDAdapter* pAdapter, HANDLE hIocp, OVERLAPPED* pOv )
{
    char* Buf = new char[x_MaxSize];
    if( Buf == NULL )
    {
        printf( "Failed to allocate buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;

    LONGLONG Frequency = GetFrequency();

    for( SIZE_T szXfer = 1; szXfer <= x_MaxSize; szXfer <<= 1 )
    {
        LONGLONG cpuRegStart = 0;
        LONGLONG tRegStart = 0;
        LONGLONG cpuRegMiddle = 0;
        LONGLONG tRegMiddle = 0;
        LONGLONG tRegEnd = 0;
        LONGLONG cpuRegEnd = 0;

        LONGLONG cpuDeregStart = 0;
        LONGLONG tDeregStart = 0;
        LONGLONG cpuDeregMiddle = 0;
        LONGLONG tDeregMiddle = 0;
        LONGLONG tDeregEnd = 0;
        LONGLONG cpuDeregEnd = 0;

        for( SIZE_T i = 0; i < x_Iterations; i++ )
        {
            //
            // Register
            //
            cpuRegStart += GetCPUTime();
            tRegStart += GetElapsedTime();
            HRESULT hr = pAdapter->RegisterMemory( Buf, szXfer, pOv, &hMr );
            cpuRegMiddle += GetCPUTime();
            tRegMiddle += GetElapsedTime();

            if( FAILED( hr ) )
            {
                printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
                exit( __LINE__ );
            }

            if( pOv->hEvent == NULL )
            {
                DWORD BytesRet2;
                ULONG_PTR Key;
                OVERLAPPED* pOv2;
                BOOL fSuccess = GetQueuedCompletionStatus(
                    hIocp,
                    &BytesRet2,
                    &Key,
                    &pOv2,
                    INFINITE
                    );

                if( fSuccess == FALSE )
                {
                    printf( "GetQueuedCompletionStatus failed with %d\n", GetLastError() );
                    exit( __LINE__ );
                }
                if( pOv2 != pOv )
                {
                    printf(
                        "Unexpected overlapped %p returned but expected %p\n",
                        pOv2,
                        pOv
                        );
                    exit( __LINE__ );
                }
            }

            SIZE_T BytesRet;
            hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, pOv->hEvent != NULL );
            if( FAILED( hr ) )
            {
                printf( "INDAdapter->GetOverlappedResult failed with %08x\n", hr );
                exit( __LINE__ );
            }
            tRegEnd += GetElapsedTime();
            cpuRegEnd += GetCPUTime();

            //
            // Deregister
            //
            cpuDeregStart += GetCPUTime();
            tDeregStart += GetElapsedTime();
            hr = pAdapter->DeregisterMemory( hMr, pOv );
            cpuDeregMiddle += GetCPUTime();
            tDeregMiddle += GetElapsedTime();

            if( FAILED( hr ) )
            {
                printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );
                exit( __LINE__ );
            }

            if( pOv->hEvent == NULL )
            {
                DWORD BytesRet2;
                ULONG_PTR Key;
                OVERLAPPED* pOv2;
                BOOL fSuccess = GetQueuedCompletionStatus(
                    hIocp,
                    &BytesRet2,
                    &Key,
                    &pOv2,
                    INFINITE
                    );

                if( fSuccess == FALSE )
                {
                    printf( "GetQueuedCompletionStatus failed with %d\n", GetLastError() );
                    exit( __LINE__ );
                }
                if( pOv2 != pOv )
                {
                    printf(
                        "Unexpected overlapped %p returned but expected %p\n",
                        pOv2,
                        pOv
                        );
                    exit( __LINE__ );
                }
            }

            hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, pOv->hEvent != NULL );
            if( FAILED( hr ) )
            {
                printf( "INDAdapter->GetOverlappedResult failed with %08x\n", hr );
                exit( __LINE__ );
            }
            tDeregEnd += GetElapsedTime();
            cpuDeregEnd += GetCPUTime();
        }

        LONGLONG ElapsedNanoSecReg1 = (tRegMiddle - tRegStart) * 1000000000I64 / Frequency / x_Iterations;
        LONGLONG CpuNanoSecReg1 = ((cpuRegMiddle - cpuRegStart) * 100I64) / x_Iterations;
        LONGLONG ElapsedNanoSecReg2 = (tRegEnd - tRegStart) * 1000000000I64 / Frequency / x_Iterations;
        LONGLONG CpuNanoSecReg2 = ((cpuRegEnd - cpuRegStart) * 100I64) / x_Iterations;

        LONGLONG ElapsedNanoSecDereg1 = (tDeregMiddle - tDeregStart) * 1000000000I64 / Frequency / x_Iterations;
        LONGLONG CpuNanoSecDereg1 = ((cpuDeregMiddle - cpuDeregStart) * 100I64) / x_Iterations;
        LONGLONG ElapsedNanoSecDereg2 = (tDeregEnd - tDeregStart) * 1000000000I64 / Frequency / x_Iterations;
        LONGLONG CpuNanoSecDereg2 = ((cpuDeregEnd - cpuDeregStart) * 100I64) / x_Iterations;

        printf(
            "%9Id %9.2f %7.2f %9.2f %7.2f %9.2f %7.2f %9.2f %7.2f\n",
            szXfer,
            (double) ElapsedNanoSecReg1 / 1000.0,
            (double) CpuNanoSecReg1 / (double) ElapsedNanoSecReg1 * 100.0,
            (double) ElapsedNanoSecReg2 / 1000.0,
            (double) CpuNanoSecReg2 / (double) ElapsedNanoSecReg2 * 100.0,
            (double) ElapsedNanoSecDereg1 / 1000.0,
            (double) CpuNanoSecDereg1 / (double) ElapsedNanoSecDereg1 * 100.0,
            (double) ElapsedNanoSecDereg2 / 1000.0,
            (double) CpuNanoSecDereg2 / (double) ElapsedNanoSecDereg2 * 100.0
            );
    }

    delete Buf;
}


int __cdecl main(int argc, char* argv[])
{
    ULONG Address = 0;

    if( argc < 2 || argc > 3 )
    {
        ShowUsage();
        exit( __LINE__ );
    }

    Address = inet_addr( argv[1] );

    if( argc == 3 )
    {
        if( argv[2][0] != 'l' &&
            argv[2][0] != 'L' )
        {
            ShowUsage();
            exit( __LINE__ );
        }

//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
        if( freopen( &argv[2][1], "w", stdout ) == NULL ||
            freopen( &argv[2][1], "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
        {
            printf( "Could not open log file.\n" );
            exit( __LINE__ );
        }
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = 0;

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    HANDLE hIocp = CreateIoCompletionPort( pAdapter->GetFileHandle(), NULL, 0, 0 );
    if( hIocp == NULL )
    {
        printf( "Failed to bind adapter to IOCP, error %d\n", GetLastError() );
        exit( __LINE__ );
    }

    printf(
        "Using %d processors. Sender Frequency is %I64d\n",
        GetProcessorCount(),
        GetFrequency() );

    printf(
        "\n Event Driven:\n"
        "                Register       Reg Complete        Deregister      Dereg Complete\n"
        "     Size    usec      cpu     usec      cpu     usec      cpu     usec      cpu\n"
        );

    OVERLAPPED Ov;

    //
    // Note that we run the test using GetOverlappedResult even though the adapter
    // is bound to an I/O completion port to make sure that the IOCP semantics are
    // working - that is, setting the lower bit of the hEvent member of the
    // OVERLAPPED structure prevents the completion from being reported to the IOCP.
    //
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        printf( "Create event failed with %d\n", GetLastError() );
        exit( __LINE__ );
    }

    //
    // Set the lower bit of the event handle so completions don't go to the IOCP.
    //
    Ov.hEvent = (HANDLE)(((SIZE_T)Ov.hEvent) | 0x1);

    RunTest( pAdapter, hIocp, &Ov );

    //
    // Now we run again, using the IOCP, to see if performance is any different.
    //
    CloseHandle( Ov.hEvent );
    Ov.hEvent = NULL;

    printf(
        "\n IOCP:\n"
        "                Register       Reg Complete        Deregister      Dereg Complete\n"
        "     Size    usec      cpu     usec      cpu     usec      cpu     usec      cpu\n"
        );

    RunTest( pAdapter, hIocp, &Ov );

    pAdapter->Release();

    CloseHandle( hIocp );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    _fcloseall();

    return 0;
}

