// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndping.cpp - Network Direct unidirectional send/recv ping test
//

#include "precomp.h"
#include <logging.h>

const SIZE_T x_MaxXfer = (4 * 1024 * 1024);
const SIZE_T x_HdrLen = 40;
const SIZE_T x_MaxVolume = (500 * x_MaxXfer);
const SIZE_T x_MaxIterations = 500000;

const LPWSTR TESTNAME = L"ndping.exe";

void ShowUsage()
{
    printf( "ndping s|c <ip> <port> b|p<nSge> [q<pipeline>] [l<log>]\n"
        "\ts - start as server (listen on IP/Port)\n"
        "\tc - start as client (connect to server IP/Port)\n"
        "\t<ip> - IPv4 Address\n"
        "\t<port> - Port number\n"
        "\tb - blocking I/O (wait for CQ notification)\n"
        "\tp - polling I/O (Poll on the CQ)\n"
        "\t<nSge> - Number of scatter/gather entries per transfer.\n"
        "\tq - pipeline limit of <pipeline> requests\n"
        "\tl - log output to a file named <log>.\n");
}

DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}

LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}

LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}

void Server(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in bool bUseEvents )
{
    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    INDAdapter *pAdapter;
    HRESULT hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &pAdapter );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdOpenIAdapter failed with %08x", __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Query failed with %08x", __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf ) 
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate data buffer.", __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::RegisterMemory failed with %08x", __LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate SGL.", __LINE__ );
    }

    for( SIZE_T i = 0; i < nSge; i++ )
    {
        Sgl[i].pAddr = pBuf + (x_HdrLen * i);
        Sgl[i].Length = x_HdrLen;
        Sgl[i].hMr = hMr;
    }

    // Last SGE has the remainder of the data.
    Sgl[nSge - 1].Length = x_MaxXfer + x_HdrLen - (x_HdrLen * (nSge - 1));

    //
    // Listen and get incoming connection request.
    //
    INDListen *pListen;
    hr = pAdapter->Listen( 0, 234, Port, NULL, &pListen );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Listen failed with %08x", __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    hr = pListen->GetConnectionRequest( pConnector, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDListen::GetConnectionRequest failed with %08x", __LINE__ );
    }

    //
    // Create a CQ.
    //
    SIZE_T QueueDepth = min( Info.MaxCqEntries, Info.MaxInboundRequests ) - 1;
    INDCompletionQueue *pCq;
    hr = pAdapter->CreateCompletionQueue( QueueDepth + 3, &pCq );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateCompletionQueue failed with %08x", __LINE__ );
    }    

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        QueueDepth,
        3,
        nSge,
        1,
        0,
        0,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CreateEndpoint failed with %08x", __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[QueueDepth + 1];
    if( Results == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate ND_RESULT array.", __LINE__ );
    }

    //
    // Pre-post receive requests.
    //
    pEndpoint->StartRequestBatch();
    for( SIZE_T i = 0; i < QueueDepth; i++ )
    {
        hr = pEndpoint->Receive( &Results[i], Sgl, nSge );
        if( FAILED( hr ) ) 
        {
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
        }
    }
    pEndpoint->SubmitRequestBatch();

    //
    // Accept the connection, notifying the caller of our queue depth.
    // Note that we send the queue depth in host order (little endian)
    // so that we don't have to worry about 32/64 bit SIZE_T issues.
    // The lower bytes will always be transferred first.
    //
    hr = pConnector->Accept(
        pEndpoint,
        &QueueDepth,
        sizeof(QueueDepth),
        pOv );

    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Accept failed with %08x", __LINE__ );
    }

    //
    // Prepare an SGE that we use for our credit updates.
    // We actually need a real SGE here as we use zero-byte transfers
    // to indicate SYNC/SYNC_ACK at the end of each loop.
    //
    ND_SGE CreditSge;
    CreditSge.pAddr = pBuf;
    CreditSge.Length = 4;
    CreditSge.hMr = hMr;
    ND_RESULT SyncResult;

    SIZE_T Threshold = QueueDepth / 2;
    do
    {
        if( bUseEvents )
        {
            hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );

            if( hr == ND_PENDING )
            {
                SIZE_T BytesRet;
                hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
            }

            if( FAILED( hr ) ) 
            {
                LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDCompletionQueue::Notify failed with %08x", __LINE__ );
            }
        }

        SIZE_T nResults;
        do
        {
            ND_RESULT* pResult;
            nResults = pCq->GetResults( &pResult, 1 );
            if( nResults == 0 )
                break;

            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                //
                // Ignore send completions
                //
                if( pResult == &Results[QueueDepth] ||
                    pResult == &SyncResult )
                {
                    break;
                }

                //
                // Check for zero-byte recv, indicating SYNC.
                //
                if( pResult->BytesTransferred == 0 )
                {
                    //
                    // Send a zero-byte send as SYNC_ACK.
                    //
                    hr = pEndpoint->Send( &SyncResult, NULL, 0, 0 );
                    if( FAILED( hr ) ) 
                    {
                        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
                    }
                }

                //
                // Repost the receive.
                //
                hr = pEndpoint->Receive( pResult, Sgl, nSge );
                if( FAILED( hr ) ) 
                {
                    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
                }

                //
                // Check if credit update is needed.
                //
                if( --Threshold == 0 )
                {
                    hr = pEndpoint->Send( &Results[QueueDepth], &CreditSge, 1, 0 );
                    if( FAILED( hr ) ) 
                    {
                        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
                    }
                    Threshold = QueueDepth / 2;
                }

                __fallthrough;
            case ND_CANCELED:
                break;

            default: 
                LOG_FAILURE_HRESULT_AND_EXIT(
                    pResult->Status,
                    L"INDCompletionQueue::GetResults returned result with %08x.",
                    __LINE__ );
            }

        } while( nResults != 0 );

    } while( hr == ND_SUCCESS );

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) )  
        LOG_FAILURE_HRESULT( hr, L"INDEndpoint::Disconnect failed with %08x", __LINE__ );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();
    pListen->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        LOG_FAILURE_HRESULT( hr, L"INDAdapter::DeregisterMemory failed with %08x", __LINE__ );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


HRESULT Send(
    __in INDEndpoint* pEndpoint,
    __in INDCompletionQueue* pCq,
    __in OVERLAPPED* pOv,
    __in ND_RESULT* Results,
    __in const ND_SGE* Sgl,
    __in const SIZE_T nSge,
    __in const SIZE_T QueueDepth,
    __in const SIZE_T RemoteQueueDepth,
    __in SIZE_T nPipeline,
    __in SIZE_T *pCredits,
    __in SIZE_T Iterations,
    __in bool bUseEvents )
{
    //
    // We'll blast QueueDepth requests out, make sure we don't overrun
    // either the local or remote endpoint.
    //
    if( nPipeline > Iterations )
        nPipeline = Iterations;
    if( nPipeline > QueueDepth )
        nPipeline = QueueDepth;

    //
    // First we post up to our limit (either Credits or QueueDepth).
    //
    SIZE_T nPosted = 0;
    while( *pCredits != 0 && Iterations != 0 && nPosted < nPipeline )
    {
        //
        // Post send.
        //
        HRESULT hr = pEndpoint->Send( &Results[Iterations % nPipeline], Sgl, nSge, 0 );
        if( FAILED( hr ) ) 
        {
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
        }
        (*pCredits)--;
        Iterations--;
        nPosted++;
    }

    //
    // Now that things are under way, poll/post as needed.
    //
    bool SyncAck = false;
    bool Sync = false;
    HRESULT hr = ND_SUCCESS;
    do
    {
        if( bUseEvents )
        {
            hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( hr == ND_PENDING )
            {
                SIZE_T BytesRet;
                hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
            }
            if( FAILED( hr ) ) 
            {
                LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDCompletionQueue::Notify failed with %08x", __LINE__ );
            }
        }

        SIZE_T nResults;
        ND_RESULT* pResult;
        while( (nResults = pCq->GetResults( &pResult, 1 )) != 0 )
        {
            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                //
                // Update credits for receive completions
                //
                if( pResult >= &Results[QueueDepth] )
                {
                    if( pResult->BytesTransferred )
                        (*pCredits) += (RemoteQueueDepth / 2);
                    else
                        SyncAck = true;

                    //
                    // Repost the receive (for the next run).
                    //
                    hr = pEndpoint->Receive( pResult, Sgl, 1 );
                    if( FAILED( hr ) ) 
                    {
                        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
                    }

                    //
                    // Top up the send queue.
                    //
                    while( *pCredits != 0 && Iterations != 0 && nPosted < nPipeline )
                    {
                        hr = pEndpoint->Send( &Results[Iterations % nPipeline], Sgl, nSge, 0 );
                        if( FAILED( hr ) ) 
                        {
                            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
                        }
                        (*pCredits)--;
                        Iterations--;
                        nPosted++;
                    }
                    break;
                }

                if( (*pCredits) && Iterations )
                {
                    //
                    // Repost the Send.
                    //
                    hr = pEndpoint->Send( pResult, Sgl, nSge, 0 );
                    if( FAILED( hr ) ) 
                    {
                        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
                    }
                    (*pCredits)--;
                    Iterations--;
                }
                else if( Iterations == 0 && !Sync )
                {
                    //
                    // Now synchronize - send a zero-byte message (SYNC),
                    // and we'll wait to receive a 0-byte reply (SYNC_ACK).
                    //
                    hr = pEndpoint->Send( pResult, NULL, 0, 0 );
                    if( FAILED( hr ) ) 
                    {
                        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
                    }
                    (*pCredits)--;
                    Sync = true;
                }
                else
                {
                    nPosted--;
                }
                break;

            case ND_CANCELED:
                Iterations = 0;
                SyncAck = true;
                break;

            default: 
                LOG_FAILURE_HRESULT_AND_EXIT(
                    pResult->Status,
                    L"INDCompletionQueue::GetResults returned result with %08x.",
                    __LINE__ );
            }

        }// while( nResults != 0 );

    } while( Iterations != 0 || nPosted != 0 || !SyncAck );

    return hr;
}


void Client(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in bool bUseEvents,
    __in SIZE_T nPipeline )
{
    struct sockaddr_in v4 = {0};
    struct sockaddr_in LocalAddr;

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdResolveAddress failed with %08x", __LINE__ );
    }

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &pAdapter );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdOpenIAdapter failed with %08x", __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Query failed with %08x", __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate data buffer.", __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::RegisterMemory failed with %08x",__LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate SGL.", __LINE__ );
    }

    //
    // Create a CQ.
    //
    SIZE_T QueueDepth = min( Info.MaxCqEntries, Info.MaxOutboundRequests ) - 2;
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( QueueDepth + 2, &pCq );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateCompletionQueue failed with %08x", __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        2,
        QueueDepth,
        1,
        nSge,
        0,
        0,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CreateEndpoint failed with %08x", __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[QueueDepth + 2];
    if( Results == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate ND_RESULT array.", __LINE__ );
    }

    //
    // Pre-post receive request for credit update.
    //
    Sgl[0].pAddr = pBuf;
    Sgl[0].Length = x_HdrLen;
    Sgl[0].hMr = hMr;
    hr = pEndpoint->Receive( &Results[QueueDepth], Sgl, 1 );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
    }

    hr = pEndpoint->Receive( &Results[QueueDepth + 1], Sgl, 1 );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
    }

    //
    // Connect to the server.
    //
    hr = pConnector->Connect(
        pEndpoint,
        (const struct sockaddr*)&v4,
        sizeof(v4),
        234,
        0,
        NULL,
        0,
        pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Connect failed with %08x", __LINE__ );
    }

    //
    // Get the remote queue depth.
    // Note that we receive the queue depth in host order (little endian)
    // so that we don't have to worry about 32/64 bit SIZE_T issues.
    // The lower bytes will always be transferred first.
    //
    SIZE_T RemoteQueueDepth = 0;
    Len = sizeof(RemoteQueueDepth);
    hr = pConnector->GetConnectionData(
        NULL,
        NULL,
        &RemoteQueueDepth,
        &Len );
    if( FAILED( hr ) && hr != ND_BUFFER_OVERFLOW )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::GetCalleeData failed with %08x", __LINE__ );
    }

    //
    // Complete the connection - this transitions the endpoint so it can send.
    //
    hr = pConnector->CompleteConnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::CompleteConnect failed with %08x", __LINE__ );
    }

    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    printf( "Using %d processors. Sender Frequency is %I64d\n",
        GetProcessorCount(),
        Frequency.QuadPart );

    SIZE_T Credits = RemoteQueueDepth;
    //
    // Warm up run, transfer only header.
    //
    hr = Send(
        pEndpoint,
        pCq,
        pOv,
        Results,
        Sgl,
        1,
        QueueDepth,
        RemoteQueueDepth,
        nPipeline,
        &Credits,
        1000,
        false );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_AND_EXIT( L"Connection unexpectedly aborted." , __LINE__ );
    }

    Sleep(1000);

    for( SIZE_T szXfer = 1; szXfer <= x_MaxXfer; szXfer <<= 1 )
    {

        for( SIZE_T i = 0; i < nSge; i++ )
        {
            Sgl[i].pAddr = pBuf + (x_HdrLen * i);
            Sgl[i].Length = x_HdrLen;
            Sgl[i].hMr = hMr;
        }

        // Last SGE has the remainder of the data.
        Sgl[nSge - 1].Length = x_HdrLen + szXfer - (x_HdrLen * (nSge - 1));

        SIZE_T Iterations = x_MaxIterations;
        if( (Iterations * szXfer) > x_MaxVolume )
            Iterations = x_MaxVolume / szXfer;

        LONGLONG cpuStart = GetCPUTime();
        LONGLONG tStart = GetElapsedTime();

        hr = Send(
            pEndpoint,
            pCq,
            pOv,
            Results,
            Sgl,
            nSge,
            QueueDepth,
            RemoteQueueDepth,
            nPipeline,
            &Credits,
            Iterations,
            bUseEvents );
        if( FAILED( hr ) )
        {
            LOG_FAILURE_AND_EXIT( L"Connection unexpectedly aborted.", __LINE__ );
        }
        LONGLONG tEnd = GetElapsedTime();
        LONGLONG cpuEnd = GetCPUTime();

        LONGLONG ElapsedNanoSec = (tEnd - tStart) / Iterations * 1000000000I64 / Frequency.QuadPart;
        LONGLONG CpuNanoSec = ((cpuEnd - cpuStart) * 100I64 / Iterations);
        LONGLONG BytesSec = szXfer * 1000000000I64 / ElapsedNanoSec;

        double elapsed = (double) ElapsedNanoSec / 1000.0;
        double cpu = (double) CpuNanoSec / (double) ElapsedNanoSec * 100.0;
        printf(" %9Id %9Id %9.2f %7.2f %11I64d\n", szXfer, Iterations, elapsed, cpu, BytesSec);
    }

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        LOG_FAILURE_HRESULT( hr, L"INDEndpoint::Disconnect failed wtih %08x", __LINE__ );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) ) 
        LOG_FAILURE_HRESULT( hr, L"INDAdapter::DeregisterMemory failed with %08x", __LINE__ );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


int __cdecl main(int argc, char* argv[])
{
    bool bServer = false;
    bool bClient = false;
    ULONG Address = 0;
    USHORT Port = 0;
    SIZE_T nSge = 0;
    bool bPolling = false;
    bool bBlocking = false;
    SIZE_T nPipeline = 128;

    INIT_LOG( TESTNAME );

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 's':
        case 'S':
            bServer = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'c':
        case 'C':
            bClient = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'p':
        case 'P':
            bPolling = true;
            nSge = atol( ++pArg );
            break;
        case 'b':
        case 'B':
            bBlocking = true;
            nSge = atol( ++pArg );
            break;
        case 'q':
        case 'Q':
            nPipeline = atol( ++pArg );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( (bClient && bServer) || (!bClient && !bServer) )
    {
        printf( "Exactly one of client (c or "
            "server (s) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( Port == 0 )
    {
        printf( "Bad port.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( (bPolling && bBlocking) || (!bPolling && !bBlocking) )
    {
        printf( "Exactly one of blocking (b or "
            "polling (p) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( nSge == 0 )
    {
        printf( "Invalid or missing SGE, expected positive integer after p or b.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    OVERLAPPED Ov;
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate event for overlapped operations.", __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdStartup failed with %08x", __LINE__ );
    }

    if( bServer )
        Server( &Ov, Address, Port, nSge, bBlocking );
    else
        Client( &Ov, Address, Port, nSge, bBlocking, nPipeline );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdCleanup failed with %08x", __LINE__ );
    }

    CloseHandle( Ov.hEvent );

    END_LOG( TESTNAME );

    _fcloseall();

    return 0;
}

