// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndpingpong.cpp - Network Direct send/recv pingpong test
//

#include "precomp.h"

const SIZE_T x_MaxXfer = (4 * 1024 * 1024);
const SIZE_T x_HdrLen = 40;
const SIZE_T x_MaxVolume = (500 * x_MaxXfer);
const SIZE_T x_MaxIterations = 100000;

#define SEND    0
#define BIND    1
#define RECV1   2
#define RECV2   3

void ShowUsage()
{
    printf( "ndping s|c <ip> <port> p<nSge> [l<log>\n"
        "\ts - start as server (listen on IP/Port)\n"
        "\tc - start as client (connect to server IP/Port)\n"
        "\t<ip> - IPv4 Address\n"
        "\t<port> - Port number\n"
        "\t<nSge> - Number of scatter/gather entries per transfer.\n"
        "\tl - log output to a file named <log>.\n");
}

DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}

LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}

LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}

void Pong(
    __in INDEndpoint* pEndpoint,
    __in INDCompletionQueue* pCq,
    __in ND_RESULT* Results,
    __in ND_SGE* Sgl,
    __in const SIZE_T nSge,
    __in const ND_MW_DESCRIPTOR* pMwDescriptor,
    __in const SIZE_T QueueDepth )
{
    UINT32 *pSize = (UINT32*)Sgl[0].pAddr;
    UINT8 *pBuf = (UINT8*)Sgl[0].pAddr;

    SIZE_T nPosted = 0;
    bool bPong = false;
    HRESULT hr = ND_SUCCESS;
    do
    {
        //
        // Check the CQ for completions - a receive completion indicates
        // that the test is over.
        //
        SIZE_T nResults;
        ND_RESULT* pResult;
        while( (nResults = pCq->GetResults( &pResult, 1 )) != 0 )
        {
            hr = pResult->Status;

            //
            // Receive completions indicate test is over.
            //
            if( pResult == &Results[RECV1] )
                return;

            switch( hr )
            {
            case ND_SUCCESS:
            case ND_CANCELED:
                nPosted--;
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }

        }// while( nResults != 0 );

        if( !bPong )
        {
            //
            // We wait for the length to be advertised, then go poll on the last
            // byte to detect completion.
            //
            if( *pSize == 0 )
                continue;

            //
            // We now have the size.  Go poll on the last byte.
            //
            if( pBuf[(*pSize) - 1] == 0 )
                continue;

            //
            // Clear the last byte to toggle the sender.
            //
            pBuf[*pSize - 1] = 0;

            //
            // Set the size in our reply area (offset 4).
            //
            *(pSize + 1) = *pSize;

            //
            // Adjust the SGL to pong the size we just received.
            //
            Sgl[nSge - 1].Length = *pSize - (x_HdrLen * (nSge - 1));

            //
            // Clear the size for the next iteration.
            //
            *pSize = 0;

            bPong = true;
        }

        if( bPong && nPosted < QueueDepth )
        {
            //
            // Send the pong.
            //
            hr = pEndpoint->Write( &Results[SEND], Sgl, nSge, pMwDescriptor, 0, 0 );
            if( FAILED( hr ) )
            {
                printf( "INDEndpoint::Write failed with %08x\n", hr );
                exit( __LINE__ );
            }
            nPosted++;
            bPong = false;
        }

    } while( hr == ND_SUCCESS || nPosted != 0 );
}

void Server(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in SIZE_T QueueDepth )
{
    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    INDAdapter* pAdapter;
    HRESULT hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        printf( "Failed to allocate data buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDMemoryWindow* pMw;
    ND_RESULT InvalidateResult;
    hr = pAdapter->CreateMemoryWindow( &InvalidateResult, &pMw );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateMemoryWindow failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        printf( "Failed to allocate SGL.\n" );
        exit( __LINE__ );
    }

    //
    // Listen and get incoming connection request.
    //
    INDListen* pListen;
    hr = pAdapter->Listen( 0, 234, Port, NULL, &pListen );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Listen failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x", hr );
        exit( __LINE__ );
    }

    hr = pListen->GetConnectionRequest( pConnector, pOv );
   if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDListen::GetConnectionRequest failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Create a CQ.
    //
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( (QueueDepth>2?QueueDepth:2) * 2, &pCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        QueueDepth>2?QueueDepth:2,
        QueueDepth>2?QueueDepth:2,
        nSge,
        nSge,
        0,
        0,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[3];
    if( Results == NULL )
    {
        printf( "Failed to allocate ND_RESULT array.\n" );
        exit( __LINE__ );
    }

    for( SIZE_T i = 0; i < nSge; i++ )
    {
        Sgl[i].pAddr = pBuf + (x_HdrLen * i);
        Sgl[i].Length = x_HdrLen;
        Sgl[i].hMr = hMr;
    }

    // Last SGE has the remainder of the data.
    Sgl[nSge - 1].Length = x_MaxXfer + x_HdrLen - (x_HdrLen * (nSge - 1));

    //
    // Pre-post receive request.
    //
    ND_SGE Sge;
    Sge.pAddr = pBuf;
    Sge.Length = sizeof(ND_MW_DESCRIPTOR);
    Sge.hMr = hMr;

    hr = pEndpoint->Receive( &Results[RECV1], &Sge, 1 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Accept the connection, notifying the caller of our queue depth.
    // Note that we send the queue depth in host order (little endian)
    // so that we don't have to worry about 32/64 bit SIZE_T issues.
    // The lower bytes will always be transferred first.
    //
    hr = pConnector->Accept(
        pEndpoint,
        NULL,
        0,
        pOv
        );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDListen::Accept failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Exchange MW descriptors.
    //
    SIZE_T nPosted = 1;
    ND_MW_DESCRIPTOR MwDescriptor;
    do
    {
        hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
        if( hr == ND_PENDING )
        {
            SIZE_T BytesRet;
            hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
        }
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }

        SIZE_T nResults;
        do
        {
            ND_RESULT* pResult;
            nResults = pCq->GetResults( &pResult, 1 );
            if( nResults == 0 )
                break;

            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                //
                // Ignore send completions
                //
                if( pResult < &Results[RECV1] )
                    break;

                //
                // If we don't get data, exit.
                //
                if( pResult->BytesTransferred != sizeof(ND_MW_DESCRIPTOR) )
                {
                    printf(
                        "Received bad buffer, expeced %d bytes, got %d.\n",
                        sizeof(ND_MW_DESCRIPTOR),
                        pResult->BytesTransferred );
                    exit( __LINE__ );
                }

                //
                // Read the memory window descriptor.
                //
                MwDescriptor = *(ND_MW_DESCRIPTOR*)pBuf;

                //
                // Repost the receive, no data segments.
                // This is to get notification of end of test.
                //
                hr = pEndpoint->Receive( pResult, 0, 0 );
                if( FAILED( hr ) )
                {
                    printf( "INDEndpoint::Receive failed with %08x\n", hr );
                    exit( __LINE__ );
                }

                //
                // Bind the MW.
                //
                hr = pEndpoint->Bind(
                    &Results[BIND],
                    hMr,
                    pMw,
                    pBuf,
                    x_MaxXfer + x_HdrLen,
                    ND_OP_FLAG_ALLOW_READ | ND_OP_FLAG_ALLOW_WRITE,
                    (ND_MW_DESCRIPTOR*)pBuf );
                if( FAILED( hr ) )
                {
                    printf( "INDEndpoint::Bind failed with %08x\n", hr );
                    exit( __LINE__ );
                }

                //
                // Send the MW descriptor.
                //
                hr = pEndpoint->Send( &Results[SEND], &Sge, 1, 0 );
                if( FAILED( hr ) )
                {
                    printf( "INDEndpoint::Send failed with %08x\n", hr );
                    exit( __LINE__ );
                }
                nPosted += 2;
                break;

            case ND_CANCELED:
                printf( "MW Descriptor exchange aborted.\n" );
                exit( __LINE__ );
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }

            nPosted--;

        } while( nResults != 0 );

    } while( nPosted );

    //
    // Clear the memory buffer.  The first 4 bytes alwasy contain the length
    // of the transfer (including the header), and the last byte is toggled
    // from zero to one to indicate completion of the transfer.
    //
    ZeroMemory( pBuf, x_MaxXfer + x_HdrLen );

    //
    // Send a zero-byte message to indicate we're ready to start.
    //
    hr = pEndpoint->Send( &Results[SEND], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }

    hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }

    SIZE_T nResults;
    do
    {
        ND_RESULT* pResult;
        nResults = pCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
            break;

        hr = pResult->Status;

        switch( hr )
        {
        case ND_SUCCESS:
            if( pResult == &Results[RECV1] )
            {
                printf( "Test aborted.\n" );
                exit( __LINE__ );
            }
            break;

        case ND_CANCELED:
            printf( "Test aborted.\n" );
            exit( __LINE__ );
            break;

        default:
            printf(
                "INDCompletionQueue::GetResults returned result with %08x.\n",
                pResult->Status );
            exit( __LINE__ );
        }

    } while( nResults != 0 );

    Pong( pEndpoint, pCq, Results, Sgl, nSge, &MwDescriptor, QueueDepth );

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    pMw->Release();

    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDEndpoint::Disconnect failed wtih %08x\n", hr );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    pListen->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}

HRESULT Ping(
    __in INDEndpoint* pEndpoint,
    __in INDCompletionQueue* pCq,
    __in ND_RESULT* Results,
    __in const ND_SGE* Sgl,
    __in const SIZE_T nSge,
    __in const ND_MW_DESCRIPTOR* pMwDescriptor,
    __in SIZE_T QueueDepth,
    __in SIZE_T Iterations )
{
    UINT32 *pSize = (UINT32*)Sgl[0].pAddr;
    UINT8 *pBuf = (UINT8*)Sgl[0].pAddr;

    SIZE_T BytesTransferred = 0;
    for( SIZE_T i = 0; i < nSge; i++ )
        BytesTransferred += Sgl[i].Length;

    HRESULT hr = ND_SUCCESS;
    SIZE_T nSendPosted = 0;
    bool NeedSend = true;
    do
    {
        if( Iterations && NeedSend && nSendPosted < QueueDepth )
        {
            //
            // Set the send size.
            //
            *pSize = (UINT32)BytesTransferred;

            //
            // Set the last byte.
            //
            pBuf[BytesTransferred - 1] = 1;

            //
            // Send the ping.
            //
            hr = pEndpoint->Write( &Results[SEND], Sgl, nSge, pMwDescriptor, 0, 0 );
            if( FAILED( hr ) )
            {
                printf( "INDEndpoint::Write failed with %08x\n", hr );
                exit( __LINE__ );
            }
            nSendPosted++;
            NeedSend = false;
        }

        if( nSendPosted > (QueueDepth >> 1) || !Iterations )
        {
            SIZE_T nResults;
            ND_RESULT* pResult;
            while( (nResults = pCq->GetResults( &pResult, 1 )) != 0 )
            {
                hr = pResult->Status;

                switch( hr )
                {
                case ND_SUCCESS:
                    if( pResult->BytesTransferred != BytesTransferred )
                    {
                        printf( "Received %d bytes, expected %d\n",
                            pResult->BytesTransferred, BytesTransferred );
                        exit( __LINE__ );
                    }

                    if( pResult >= &Results[RECV1] )
                    {
                        hr = ND_CANCELED;
                        break;
                    }
                    nSendPosted--;

                    __fallthrough;
                case ND_CANCELED:
                    break;

                default:
                    printf(
                        "INDCompletionQueue::GetResults returned result with %08x.\n",
                        pResult->Status );
                    exit( __LINE__ );
                }
            }// while( nResults != 0 )
        }

        if( !NeedSend )
        {
            if( pBuf[BytesTransferred - 1] != 0 )
                continue;

            if( *(pSize + 1) != BytesTransferred )
            {
                printf( "Received %d bytes, expected %d\n",
                    *(pSize + 1), BytesTransferred );
                exit( __LINE__ );
            }

            NeedSend = true;
            Iterations--;
        }

    } while( (hr == ND_SUCCESS && Iterations != 0) || nSendPosted > 0 );

    return hr;
}

void Client(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in SIZE_T QueueDepth )
{
    struct sockaddr_in v4 = {0};
    struct sockaddr_in LocalAddr;

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) )
    {
        printf( "NdResolveAddress failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        printf( "Failed to allocate data buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDMemoryWindow* pMw;
    ND_RESULT InvalidateResult;
    hr = pAdapter->CreateMemoryWindow( &InvalidateResult, &pMw );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateMemoryWindow failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        printf( "Failed to allocate SGL.\n" );
        exit( __LINE__ );
    }

    //
    // Create a CQ.
    //
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( (QueueDepth>2?QueueDepth:2) * 2, &pCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x", hr );
        exit( __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        QueueDepth>2? QueueDepth : 2,
        QueueDepth>2? QueueDepth : 2,
        nSge,
        nSge,
        0,
        0,
        NULL,
        &pEndpoint );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[4];
    if( Results == NULL )
    {
        printf( "Failed to allocate ND_RESULT array.\n" );
        exit( __LINE__ );
    }

    //
    // Connect to the server.
    //
    hr = pConnector->Connect(
        pEndpoint,
        (const struct sockaddr*)&v4,
        sizeof(v4),
        234,
        0,
        NULL,
        0,
        pOv
        );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::Connect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Pre-post receive request.
    //
    ND_SGE Sge;
    Sge.pAddr = pBuf;
    Sge.Length = sizeof(ND_MW_DESCRIPTOR);
    Sge.hMr = hMr;

    hr = pEndpoint->Receive( &Results[RECV1], &Sge, 1 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    hr = pEndpoint->Receive( &Results[RECV2], &Sge, 1 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Complete the connection - this transitions the endpoint so it can send.
    //
    hr = pConnector->CompleteConnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::CompleteConnect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Exchange memory window descriptors.
    //

    //
    // Bind the MW.
    //
    hr = pEndpoint->Bind(
        &Results[BIND],
        hMr,
        pMw,
        pBuf,
        x_MaxXfer + x_HdrLen,
        ND_OP_FLAG_ALLOW_READ | ND_OP_FLAG_ALLOW_WRITE,
        (ND_MW_DESCRIPTOR*)pBuf );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Bind failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Send the MW descriptor.
    //
    hr = pEndpoint->Send( &Results[SEND], &Sge, 1, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }
    SIZE_T nPosted = 3;
    ND_MW_DESCRIPTOR MwDescriptor;
    do
    {
        hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
        if( hr == ND_PENDING )
        {
            SIZE_T BytesRet;
            hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
        }
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }

        SIZE_T nResults;
        do
        {
            ND_RESULT* pResult;
            nResults = pCq->GetResults( &pResult, 1 );
            if( nResults == 0 )
                break;

            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                //
                // Ignore send completions
                //
                if( pResult < &Results[RECV1] )
                    break;

                //
                // If we don't get data, exit.
                //
                if( pResult->BytesTransferred != sizeof(ND_MW_DESCRIPTOR) )
                {
                    printf(
                        "Received bad buffer, expeced %d bytes, got %d.\n",
                        sizeof(ND_MW_DESCRIPTOR),
                        pResult->BytesTransferred );
                    exit( __LINE__ );
                }

                //
                // Read the memory window descriptor.
                //
                MwDescriptor = *(ND_MW_DESCRIPTOR*)pBuf;

                //
                // Repost the receive, no data segments.
                // This is to get notification of end of test.
                //
                hr = pEndpoint->Receive( pResult, 0, 0 );
                if( FAILED( hr ) )
                {
                    printf( "INDEndpoint::Receive failed with %08x\n", hr );
                    exit( __LINE__ );
                }

                __fallthrough;
            case ND_CANCELED:
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }

            nPosted--;

        } while( nResults != 0 );

    } while( nPosted );

    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    printf( "Using %d processors. Sender Frequency is %I64d\n",
        GetProcessorCount(),
        Frequency.QuadPart );

    //
    // Set all the bytes to 1.  The server will toggle them off.
    //
    FillMemory( pBuf, x_MaxXfer + x_HdrLen, 0x1 );

    //
    // Wait for the server to be ready.
    //
    hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }

    SIZE_T nResults;
    do
    {
        ND_RESULT* pResult;
        nResults = pCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
            break;

        hr = pResult->Status;

        switch( hr )
        {
        case ND_SUCCESS:
            //
            // Ignore send completions
            //
            if( pResult < &Results[RECV1] )
                break;

            //
            // Repost the receive, no data segments.
            // This is to get notification of end of test.
            //
            hr = pEndpoint->Receive( pResult, 0, 0 );
            if( FAILED( hr ) )
            {
                printf( "INDEndpoint::Receive failed with %08x\n", hr );
                exit( __LINE__ );
            }

            __fallthrough;
        case ND_CANCELED:
            break;

        default:
            printf(
                "INDCompletionQueue::GetResults returned result with %08x.\n",
                pResult->Status );
            exit( __LINE__ );
        }

    } while( nResults != 0 );

    //
    // Warm up run, transfer only header.
    //
    Sgl[0].pAddr = pBuf;
    Sgl[0].Length = x_HdrLen;
    Sgl[0].hMr = hMr;

    hr = Ping(
        pEndpoint,
        pCq,
        Results,
        Sgl,
        1,
        &MwDescriptor,
        QueueDepth,
        1000 );
    if( FAILED( hr ) )
    {
        printf( "Connection unexpectedly aborted.\n" );
        exit( __LINE__ );
    }

    Sleep(1000);

    for( SIZE_T szXfer = 1; szXfer <= x_MaxXfer; szXfer <<= 1 )
    {

        for( SIZE_T i = 0; i < nSge; i++ )
        {
            Sgl[i].pAddr = pBuf + (x_HdrLen * i);
            Sgl[i].Length = x_HdrLen;
            Sgl[i].hMr = hMr;
        }

        // Last SGE has the remainder of the data.
        Sgl[nSge - 1].Length = x_HdrLen + szXfer - (x_HdrLen * (nSge - 1));

        SIZE_T Iterations = x_MaxIterations;
        if( (Iterations * szXfer) > x_MaxVolume )
            Iterations = x_MaxVolume / szXfer;

        LONGLONG cpuStart = GetCPUTime();
        LONGLONG tStart = GetElapsedTime();

        hr = Ping(
            pEndpoint,
            pCq,
            Results,
            Sgl,
            nSge,
            &MwDescriptor,
            QueueDepth,
            Iterations );
        if( FAILED( hr ) )
        {
            printf( "Connection unexpectedly aborted.\n" );
            exit( __LINE__ );
        }
        LONGLONG tEnd = GetElapsedTime();
        LONGLONG cpuEnd = GetCPUTime();

        LONGLONG ElapsedNanoSec = (tEnd - tStart) / Iterations / 2I64* 1000000000I64 / Frequency.QuadPart;
        LONGLONG CpuNanoSec = ((cpuEnd - cpuStart) * 100I64 / Iterations / 2I64 );
        LONGLONG BytesSec = szXfer * 1000000000I64 / ElapsedNanoSec;

        double elapsed = (double) ElapsedNanoSec / 1000.0;
        double cpu = (double) CpuNanoSec / (double) ElapsedNanoSec * 100.0;
        printf(" %9Id %9Id %9.2f %7.2f %11I64d\n", szXfer, Iterations, elapsed, cpu, BytesSec);
    }

    //
    // Send a message to the server so it exits.
    //
    hr = pEndpoint->Send( &Results[SEND], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }

    do
    {
        ND_RESULT* pResult;
        nResults = pCq->GetResults( &pResult, 1 );
    } while( nResults == 0 );

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    pMw->Release();

    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDEndpoint::Disconnect failed wtih %08x\n", hr );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


int __cdecl main(int argc, char* argv[])
{
    bool bServer = false;
    bool bClient = false;
    ULONG Address = 0;
    USHORT Port = 0;
    SIZE_T nSge = 0;
    SIZE_T QueueDepth = 1;

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 's':
        case 'S':
            bServer = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'c':
        case 'C':
            bClient = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'p':
        case 'P':
            nSge = atol( ++pArg );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( (bClient && bServer) || (!bClient && !bServer) )
    {
        printf( "Exactly one of client (c or "
            "server (s) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( Port == 0 )
    {
        printf( "Bad port.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( nSge == 0 )
    {
        printf( "Invalid or missing SGE, expected positive integer after p.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    OVERLAPPED Ov;
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        printf( "Failed to allocate event for overlapped operations.\n" );
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    if( bServer )
        Server( &Ov, Address, Port, nSge, QueueDepth );
    else
        Client( &Ov, Address, Port, nSge, QueueDepth );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    CloseHandle( Ov.hEvent );

    _fcloseall();

    return 0;
}
