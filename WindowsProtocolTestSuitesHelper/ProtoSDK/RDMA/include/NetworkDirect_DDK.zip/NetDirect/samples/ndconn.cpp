// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndconn.cpp - Network Direct connection scalability test
//

#include "precomp.h"
#include "ndconn.h"


const SIZE_T x_XferLen = 4096;


void ShowUsage()
{
    printf( "ndconn s|c <ip> <port> t<threads> [l<log>]\n"
        "\ts - start as server (listen on IP/Port)\n"
        "\tc - start as client (connect to server IP/Port)\n"
        "\t<ip> - IPv4 Address\n"
        "\t<port> - Port number\n"
        "\tt - number of threads\n"
        "\tl - log output to a file named <log>.\n");
}


CTest::CTest(__in SIZE_T BufferSize ) :
    m_BufferSize( BufferSize ),
    m_fEndTest( false ),
    m_hIocp( NULL ),
    m_pAdapter( NULL ),
    m_hMr( NULL )
{
}


void CTest::Start()
{
    m_hIocp = CreateIoCompletionPort( m_pAdapter->GetFileHandle(), NULL, 0, 0 );
    if( m_hIocp == NULL )
    {
        printf( "Failed to bind adapter to IOCP, error %d\n", GetLastError() );
        exit( __LINE__ );
    }

    m_pBuf = new char[m_BufferSize];
    if( m_pBuf == NULL )
    {
        printf( "Failed to allocate buffer (%d bytes)\n", m_BufferSize );
        exit( __LINE__ );
    }

    OVERLAPPED Ov = {0};
    HRESULT hr = m_pAdapter->RegisterMemory( m_pBuf, m_BufferSize, &Ov, &m_hMr );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    DWORD BytesRet1;
    ULONG_PTR Key;
    OVERLAPPED* pOv;
    BOOL fSuccess = GetQueuedCompletionStatus( m_hIocp, &BytesRet1, &Key, &pOv, INFINITE );
    if( !fSuccess && pOv == NULL )
    {
        printf( "GetQueuedCompletionStatus failed (%d)\n", GetLastError() );
        exit( __LINE__ );
    }

    SIZE_T BytesRet2;
    hr = m_pAdapter->GetOverlappedResult( pOv, &BytesRet2, FALSE );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


CTest::~CTest()
{
    if( m_hMr != NULL )
    {
        OVERLAPPED Ov = {0};
        HRESULT hr = m_pAdapter->DeregisterMemory( m_hMr, &Ov );
        if( FAILED( hr ) )
        {
            printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );
            exit( __LINE__ );
        }

        DWORD BytesRet1;
        ULONG_PTR Key;
        OVERLAPPED* pOv;
        BOOL fSuccess = GetQueuedCompletionStatus( m_hIocp, &BytesRet1, &Key, &pOv, INFINITE );
        if( !fSuccess && pOv == NULL )
        {
            printf( "GetQueuedCompletionStatus failed (%d)\n", GetLastError() );
            exit( __LINE__ );
        }

        SIZE_T BytesRet2;
        hr = m_pAdapter->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( FAILED( hr ) )
        {
            printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );
            exit( __LINE__ );
        }
    }

    m_pAdapter->Release();

    CloseHandle( m_hIocp );
}


void CConnReq::GetNextRequest()
{
    HRESULT hr = m_pTest->m_pAdapter->CreateConnector( &m_pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x\n", hr );
        exit( __LINE__ );
    }

    InterlockedIncrement( &m_pTest->m_nOv );
    hr = m_pTest->m_pListen->GetConnectionRequest( m_pConnector, this );
    if( FAILED( hr ) )
    {
        InterlockedDecrement( &m_pTest->m_nOv );
        printf( "INDListen::GetConnectionRequest failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


void CConnReq::GetConnSucceeded( __in COverlapped *pOv )
{
    CConnReq* This = static_cast<CConnReq*>( pOv );

    CServerEp::Create( This->m_pTest, This->m_pConnector );
    This->m_pConnector = NULL;

    //
    // Issue the next GetConnectionRequest.
    //
    This->GetNextRequest();

    InterlockedDecrement( &This->m_pTest->m_nOv );
}


void CConnReq::GetConnFailed( __in COverlapped *pOv )
{
    CConnReq* This = static_cast<CConnReq*>( pOv );

    SIZE_T BytesRet;
    HRESULT hr = This->m_pTest->m_pListen->GetOverlappedResult( pOv, &BytesRet, FALSE );
    if( hr != ND_CANCELED )
    {
        printf( "INDListen::GetConnectionRequest failed with %08x\n", hr );
        exit( __LINE__ );
    }

    InterlockedDecrement( &This->m_pTest->m_nOv );
}


CServerTest::CServerTest( __in SIZE_T BufferSize, __in LONG nThreads ) :
    CTest( BufferSize ),
    m_nThreads( nThreads ),
    m_nEpCreated( 0 ),
    m_nEpDestroyed( 0 ),
    m_nOv( 0 ),
    m_SendOv( SendSucceeded, SendFailed ),
    m_RecvOv( RecvSucceeded, RecvFailed ),
    m_nConnFailure( 0 ),
    m_AcceptTime( 0 ),
    m_DisconnectTime( 0 ),
    m_pSendCq( NULL ),
    m_pRecvCq( NULL ),
    m_pListen( NULL )
{
}


void CServerTest::Run()
{
    CTest::Start();

    //
    // Create a CQ for completion processing (detecting disconnection)
    //
    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    HRESULT hr = m_pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }
    hr = m_pAdapter->CreateCompletionQueue( Info.MaxCqEntries, &m_pSendCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    hr = m_pAdapter->CreateCompletionQueue( Info.MaxCqEntries, &m_pRecvCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Request CQ notifications.
    //
    hr = m_pSendCq->Notify( ND_CQ_NOTIFY_ANY, &m_SendOv );
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }
    hr = m_pRecvCq->Notify( ND_CQ_NOTIFY_ANY, &m_RecvOv );
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Create and launch test threads.
    //
    for( LONG i = 0; i < m_nThreads; i++ )
    {
        HANDLE hThread = CreateThread( NULL, 0, TestRoutine, this, 0, NULL );
        if( hThread == NULL )
        {
            printf( "CreateThread for thread %d of %d failed with %d.\n", i + 1, m_nThreads, GetLastError() );
            exit( __LINE__ );
        }
    }

    LONGLONG StartTime = GetElapsedTime();

    //
    // Run for a minute and a bit.  The extra bit allows the client to finish up first.
    //
    Sleep( 65000 );

    //
    // Indicate to the connecting threads that they should stop accepting connections.
    //
    m_fEndTest = true;

    //
    // Let things run down.
    //
    while( m_nEpCreated > m_nEpDestroyed )
    {
        Sleep( 0 );
    }

    LONGLONG RunTime = GetElapsedTime() - StartTime;

    while( m_nOv > 0 )
    {
        //
        // Cancel outstanding connection requests.
        //
        m_pListen->CancelOverlappedRequests();
        Sleep( 100 );
    }

    //
    // Post a NULL completion so the threads exit.
    //
    for( LONG i = 0; i < m_nThreads; i++ )
    {
        PostQueuedCompletionStatus( m_hIocp, 0, 0, NULL );
    }

    //
    // Stop listening.
    //
    m_pListen->Release();

    LONGLONG nEpConnected = m_nEpCreated - m_nConnFailure;
    double ConnRate = (double)(m_nEpCreated - m_nConnFailure) / ((double)RunTime / (double)GetFrequency());
    printf( "%7.2f connections per second\n", ConnRate );

    //
    // Print results
    //
    printf(
        "Per connection times (microsec):\nAccept: %9.2f\nDisconnect: %9.2f\n",
        (double)(m_AcceptTime / nEpConnected) / (GetFrequency() / 1000000.0),
        (double)(m_DisconnectTime / nEpConnected) / (GetFrequency() / 1000000.0)
        );

    printf( "%d connection failures.\n", m_nConnFailure );
}


CServerTest::~CServerTest()
{
    DWORD BytesRet;
    ULONG_PTR Key;
    OVERLAPPED* pOv;

    if( m_pSendCq != NULL )
    {
        m_pSendCq->CancelOverlappedRequests();
        GetQueuedCompletionStatus( m_hIocp, &BytesRet, &Key, &pOv, INFINITE );
        m_pSendCq->Release();
    }

    if( m_pRecvCq != NULL )
    {
        m_pRecvCq->CancelOverlappedRequests();
        GetQueuedCompletionStatus( m_hIocp, &BytesRet, &Key, &pOv, INFINITE );
        m_pRecvCq->Release();
    }
}


void CServerTest::OpenAdapter( __in ULONG Address, __in USHORT Port )
{
    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    HRESULT hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &m_pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Listen for incoming connection request.
    //
    hr = m_pAdapter->Listen( 0, 234, Port, NULL, &m_pListen );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Listen failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


DWORD WINAPI CServerTest::TestRoutine( LPVOID This )
{
    CServerTest* pTest = (CServerTest*)This;
    CConnReq ConnReq( pTest );

    for( ;; )
    {
        DWORD BytesRet1;
        ULONG_PTR Key;
        OVERLAPPED* pOv;
        BOOL fSuccess = GetQueuedCompletionStatus( pTest->m_hIocp, &BytesRet1, &Key, &pOv, INFINITE );
        if( !fSuccess )
        {
            if( pOv == NULL )
                return 0;

            static_cast<COverlapped*>(pOv)->Failed();
        }
        else
        {
            if( pOv == NULL )
                return 0;

            static_cast<COverlapped*>(pOv)->Succeeded();
        }
    }
}


void CServerTest::SendSucceeded( __in COverlapped* pOv )
{
    CServerTest* pTest = CONTAINING_RECORD( pOv, CServerTest, m_SendOv );

    ND_RESULT* pResult;
    for( ;; )
    {
        SIZE_T nResults = pTest->m_pSendCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
        {
            HRESULT hr = pTest->m_pSendCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
            return;
        }

        CServerEp::SendDone( pResult );
    }
}


void CServerTest::SendFailed( __in COverlapped* pOv )
{
    CServerTest* pTest = CONTAINING_RECORD( pOv, CServerTest, m_SendOv );

    SIZE_T BytesRet;
    HRESULT hr = pTest->m_pSendCq->GetOverlappedResult( pOv, &BytesRet, FALSE );

    pTest->m_pSendCq->Release();

    if( hr == ND_CANCELED )
        return;

    printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
    exit( __LINE__ );
}


void CServerTest::RecvSucceeded( __in COverlapped* pOv )
{
    CServerTest* pTest = CONTAINING_RECORD( pOv, CServerTest, m_RecvOv );

    ND_RESULT* pResult;
    for( ;; )
    {
        SIZE_T nResults = pTest->m_pRecvCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
        {
            HRESULT hr = pTest->m_pRecvCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
            return;
        }

        CServerEp::RecvDone( pResult );
    }
}


void CServerTest::RecvFailed( __in COverlapped* pOv )
{
    CServerTest* pTest = CONTAINING_RECORD( pOv, CServerTest, m_RecvOv );

    SIZE_T BytesRet;
    HRESULT hr = pTest->m_pRecvCq->GetOverlappedResult( pOv, &BytesRet, FALSE );

    pTest->m_pRecvCq->Release();

    if( hr == ND_CANCELED )
        return;

    printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
    exit( __LINE__ );
}


CServerEp::CServerEp( __in CServerTest* pTest ) :
    m_AcceptOv( AcceptSucceeded, AcceptFailed ),
    m_DisconnectOv( DisconnectSucceeded, DisconnectFailed ),
    m_NotifyDisconnectOv( NotifyDisconnectSucceeded, NotifyDisconnectFailed ),
    m_pTest( pTest ),
    m_fDoSend( 0 ),
    m_pEp( NULL ),
    m_pConnector( NULL )
{
}


CServerEp::~CServerEp()
{
    if( m_pEp != NULL )
    {
        m_pEp->Release();
    }
    if( m_pConnector != NULL )
    {
        m_pConnector->Release();
    }
    InterlockedIncrement( &m_pTest->m_nEpDestroyed );
}


HRESULT CServerEp::Init( __in INDConnector* pConnector )
{
    m_pConnector = pConnector;

    HRESULT hr = m_pConnector->CreateEndpoint(
        m_pTest->m_pRecvCq,
        m_pTest->m_pSendCq,
        1,
        1,
        1,
        1,
        0,
        0,
        NULL,
        &m_pEp
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        return hr;
    }

    //
    // Pre-post receive request.
    //
    ND_SGE Sge;
    Sge.pAddr = m_pTest->m_pBuf;
    Sge.Length = m_pTest->m_BufferSize;
    Sge.hMr = m_pTest->m_hMr;
    AddRef();
    hr = m_pEp->Receive( &m_Result, &Sge, 1 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        Release();
        return hr;
    }

    InterlockedIncrement( &m_pTest->m_nEpCreated );

    //
    // Accept the connection
    //
    AddRef();
    m_AcceptTime = GetElapsedTime();
    hr = m_pConnector->Accept(
        m_pEp,
        NULL,
        0,
        &m_AcceptOv
        );
    if( FAILED( hr ) )
    {
        AcceptError( hr );
        Release();
    }

    return ND_SUCCESS;
}


HRESULT CServerEp::Create( __in CServerTest* pTest, __in INDConnector* pConnector )
{
    CServerEp* pEp = new CServerEp( pTest );
    if( pEp == NULL )
        return ND_NO_MEMORY;

    HRESULT hr = pEp->Init( pConnector );
    if( FAILED( hr ) )
        pEp->Release();

    return hr;
}


void CServerEp::AcceptSucceeded( __in COverlapped* pOv )
{
    CServerEp* pEp = CONTAINING_RECORD( pOv, CServerEp, m_AcceptOv );

    pEp->AddRef();
    HRESULT hr = pEp->m_pConnector->NotifyDisconnect( &pEp->m_NotifyDisconnectOv );
    if( FAILED( hr ) )
    {
        pEp->Release();	// NotifyDisconnect Reference
        pEp->AcceptError( ND_CONNECTION_ABORTED );
        pEp->Release();	// Accept Reference
        return;
    }

    InterlockedExchangeAdd64( &pEp->m_pTest->m_AcceptTime, GetElapsedTime() - pEp->m_AcceptTime );
    if( InterlockedIncrement( &pEp->m_fDoSend ) == 2 )
    {
        pEp->Send();
    }
    pEp->Release();
}


void CServerEp::AcceptFailed( __in COverlapped* pOv )
{
    CServerEp* pEp = CONTAINING_RECORD( pOv, CServerEp, m_AcceptOv );

    SIZE_T BytesRet;
    HRESULT hr = pEp->m_pConnector ->GetOverlappedResult( pOv, &BytesRet, FALSE );

    pEp->AcceptError( hr );
    pEp->Release();
}


void CServerEp::AcceptError( __in HRESULT hr )
{
    if( hr == ND_CONNECTION_ABORTED )
    {
        InterlockedIncrement( &m_pTest->m_nConnFailure );
        m_pEp->Flush();
        //
        // Release again to destroy it.
        //
        Release();
        return;
    }

    printf( "INDConnector::Accept failed with %08x\n", hr );
    exit( __LINE__ );
}


void CServerEp::SendDone( __in ND_RESULT* pResult )
{
    CServerEp* pEp = CONTAINING_RECORD( pResult, CServerEp, m_Result );

    if( pResult->Status != ND_SUCCESS )
    {
        printf( "INDEndpoint::Send failed with %08x\n", pResult->Status );
        exit( __LINE__ );
    }

    //
    // We have a reference from the send - reuse it for the disconnect.
    //
    pEp->m_DisconnectTime = GetElapsedTime();

    HRESULT hr = pEp->m_pConnector->Disconnect( &pEp->m_DisconnectOv );
    if( FAILED( hr ) )
    {
        pEp->Release();
        printf( "INDEndpoint::Disconnect failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


void CServerEp::RecvDone( __in ND_RESULT* pResult )
{
    CServerEp* pEp = CONTAINING_RECORD( pResult, CServerEp, m_Result );

    if( pResult->Status != ND_SUCCESS && pResult->Status != ND_CANCELED )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", pResult->Status );
        exit( __LINE__ );
    }

    if( InterlockedIncrement( &pEp->m_fDoSend ) == 2 )
    {
        pEp->Send();
    }

    pEp->Release();
}


void CServerEp::Send()
{
    ND_SGE Sge;
    Sge.pAddr = m_pTest->m_pBuf;
    Sge.Length = m_pTest->m_BufferSize;
    Sge.hMr = m_pTest->m_hMr;
    AddRef();
    HRESULT hr = m_pEp->Send( &m_Result, &Sge, 1, 0 );
    if( FAILED( hr ) )
    {
        Release();
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


void CServerEp::DisconnectSucceeded( __in COverlapped* pOv )
{
    CServerEp* pEp = CONTAINING_RECORD( pOv, CServerEp, m_DisconnectOv );
    pEp->Release();

    InterlockedExchangeAdd64( &pEp->m_pTest->m_DisconnectTime, GetElapsedTime() - pEp->m_DisconnectTime );
    InterlockedIncrement( &pEp->m_pTest->m_nEpDestroyed );

    //
    // Cancel the NotifyDisconnect request.
    //
    pEp->m_pConnector->CancelOverlappedRequests();

    //
    // Release again to destroy it.
    //
    pEp->Release();
}


void CServerEp::DisconnectFailed( __in COverlapped* pOv )
{
    CServerEp* pEp = CONTAINING_RECORD( pOv, CServerEp, m_DisconnectOv );

    SIZE_T BytesRet;
    printf(
        "INDConnector::Disconnect failed with %08x\n",
        pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE )
        );
    exit( __LINE__ );
}


void CServerEp::NotifyDisconnectSucceeded( __in COverlapped* pOv )
{
    CServerEp* pEp = CONTAINING_RECORD( pOv, CServerEp, m_NotifyDisconnectOv );

    if( pEp->m_fDoSend == 2 )
    {
        pEp->Release();
        return;
    }

    pEp->AcceptError( ND_CONNECTION_ABORTED );
}


void CServerEp::NotifyDisconnectFailed( __in COverlapped* pOv )
{
    CServerEp* pEp = CONTAINING_RECORD( pOv, CServerEp, m_NotifyDisconnectOv );

    SIZE_T BytesRet;
    HRESULT hr = pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE );
    if( hr != ND_CANCELED )
    {
        printf( "INDConnector::NotifyDisconnect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    pEp->Release();
}


CClientTest::CClientTest( __in SIZE_T BufferSize, __in LONG nThreads ) :
    CTest( BufferSize ),
    m_nThreads( nThreads ),
    m_nEpCreated( 0 ),
    m_nEpDestroyed( 0 ),
    m_SendOv( SendSucceeded, SendFailed ),
    m_RecvOv( RecvSucceeded, RecvFailed ),
    m_nConnFailure( 0 ),
    m_ConnectTime( 0 ),
    m_CompleteConnectTime( 0 ),
    m_DisconnectTime( 0 ),
    m_nConnTimeout( 0 )
{
}


void CClientTest::Run()
{
    CTest::Start();

    //
    // Create a CQ for completion processing (detecting disconnection)
    //
    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    HRESULT hr = m_pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }
    hr = m_pAdapter->CreateCompletionQueue( Info.MaxCqEntries, &m_pSendCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    hr = m_pAdapter->CreateCompletionQueue( Info.MaxCqEntries, &m_pRecvCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Request CQ notifications.
    //
    hr = m_pSendCq->Notify( ND_CQ_NOTIFY_ANY, &m_SendOv );
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }
    hr = m_pRecvCq->Notify( ND_CQ_NOTIFY_ANY, &m_RecvOv );
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Wait 5 seconds for the server to be ready.
    //
    Sleep( 5000 );

    //
    // Create and launch test threads.
    //
    for( LONG i = 0; i < m_nThreads; i++ )
    {
        HANDLE hThread = CreateThread( NULL, 0, TestRoutine, this, 0, NULL );
        if( hThread == NULL )
        {
            printf( "CreateThread for thread %d of %d failed with %d.\n", i + 1, m_nThreads, GetLastError() );
            exit( __LINE__ );
        }
    }
    LONGLONG StartTime = GetElapsedTime();

    //
    // Run for a minute.
    //
    Sleep( 60000 );

    //
    // Signal the end of the test.
    //
    m_fEndTest = true;

    //
    // Let things run down.
    //
    while( m_nEpCreated > m_nEpDestroyed )
        Sleep( 0 );

    //
    // Post a NULL completion so the threads exit.
    //
    for( LONG i = 0; i < m_nThreads; i++ )
    {
        PostQueuedCompletionStatus( m_hIocp, 0, 0, NULL );
    }

    //
    // Print results
    //
    LONGLONG RunTime = GetElapsedTime() - StartTime;
    LONGLONG nEpConnected = m_nEpCreated - m_nConnFailure;
    double ConnRate = (double)nEpConnected / ((double)RunTime / (double)GetFrequency());
    printf( "%7.2f connections per second\n", ConnRate );

    printf(
        "Per connection times (microsec):\nConnect: %9.2f\nCompleteConnect: %9.2f\nDisconnect: %9.2f\n",
        (double)(m_ConnectTime / nEpConnected) / (GetFrequency() / 1000000.0),
        (double)(m_CompleteConnectTime / nEpConnected) / (GetFrequency() / 1000000.0),
        (double)(m_DisconnectTime / nEpConnected) / (GetFrequency() / 1000000.0)
        );

    printf( "%d connection failures.\n", m_nConnFailure );
    printf( "%d connection timeouts.\n", m_nConnTimeout );
}


CClientTest::~CClientTest()
{
    DWORD BytesRet;
    ULONG_PTR Key;
    OVERLAPPED* pOv;

    m_pSendCq->CancelOverlappedRequests();
    GetQueuedCompletionStatus( m_hIocp, &BytesRet, &Key, &pOv, INFINITE );
    m_pSendCq->Release();

    m_pRecvCq->CancelOverlappedRequests();
    GetQueuedCompletionStatus( m_hIocp, &BytesRet, &Key, &pOv, INFINITE );
    m_pRecvCq->Release();
}


void CClientTest::OpenAdapter( __in ULONG Address, __in USHORT Port )
{
    struct sockaddr_in LocalAddr;

    m_Addr.sin_family = AF_INET;
    m_Addr.sin_addr.s_addr = Address;
    m_Addr.sin_port = Port;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&m_Addr,
        sizeof(m_Addr),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) )
    {
        printf( "NdResolveAddress failed with %08x\n", hr );
        exit( __LINE__ );
    }

    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &m_pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


DWORD WINAPI CClientTest::TestRoutine( LPVOID This )
{
    CClientTest* pTest = (CClientTest*)This;
    //
    // Artificially increase the number of EPs by 1.
    // This prevents the main thread from exiting prematurely without
    // the worker threads properly detecting that the connection
    // establishment should stop.
    //
    InterlockedIncrement( &pTest->m_nEpCreated );
    bool fExit = false;

    for( ;; )
    {
        DWORD Timeout = 0;

        //
        // Create a new EP and start connection establishment.
        // Note that creation could fail if the adapter under test
        // or system is out of resources, and we don't treat that as
        // a test failure.
        //
        HRESULT hr;
        if( pTest->m_fEndTest == false )
        {
            hr = CClientEp::Create( pTest );
        }
        else
        {
            if( fExit == false )
            {
                fExit = true;
                //
                // We will not create any more endpoints, and all existing
                // endpoints are accounted for in the EP count.
                // We can release our artificial extra count.
                //
                InterlockedDecrement( &pTest->m_nEpCreated );
            }
            hr = ND_CANCELED;
        }
        if( FAILED( hr ) )
        {
            Timeout = INFINITE;
        }
        else
        {
            Timeout = 0;
        }

        BOOL fSuccess;
        do
        {
            DWORD BytesRet1;
            ULONG_PTR Key;
            OVERLAPPED* pOv;
            fSuccess = GetQueuedCompletionStatus(
                pTest->m_hIocp,
                &BytesRet1,
                &Key,
                &pOv,
                Timeout
                );
            if( !fSuccess )
            {
                if( GetLastError() == WAIT_TIMEOUT )
                    break;

                if( pOv == NULL )
                    return 0;

                static_cast<COverlapped*>(pOv)->Failed();
            }
            else
            {
                if( pOv == NULL )
                    return 0;

                static_cast<COverlapped*>(pOv)->Succeeded();
            }

        } while( fSuccess == TRUE );
    }
}


void CClientTest::SendSucceeded( __in COverlapped* pOv )
{
    CClientTest* pTest = CONTAINING_RECORD( pOv, CClientTest, m_SendOv );

    ND_RESULT* pResult;
    for( ;; )
    {
        SIZE_T nResults = pTest->m_pSendCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
        {
            HRESULT hr = pTest->m_pSendCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
            return;
        }

        CClientEp::SendDone( pResult );
    }
}


void CClientTest::SendFailed( __in COverlapped* pOv )
{
    CClientTest* pTest = CONTAINING_RECORD( pOv, CClientTest, m_SendOv );

    SIZE_T BytesRet;
    HRESULT hr = pTest->m_pSendCq->GetOverlappedResult( pOv, &BytesRet, FALSE );

    pTest->m_pSendCq->Release();

    if( hr == ND_CANCELED )
        return;

    printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
    exit( __LINE__ );
}


void CClientTest::RecvSucceeded( __in COverlapped* pOv )
{
    CClientTest* pTest = CONTAINING_RECORD( pOv, CClientTest, m_RecvOv );

    ND_RESULT* pResult;
    for( ;; )
    {
        SIZE_T nResults = pTest->m_pRecvCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
        {
            HRESULT hr = pTest->m_pRecvCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
            return;
        }

        CClientEp::RecvDone( pResult );
    }
}


void CClientTest::RecvFailed( __in COverlapped* pOv )
{
    CClientTest* pTest = CONTAINING_RECORD( pOv, CClientTest, m_RecvOv );

    SIZE_T BytesRet;
    HRESULT hr = pTest->m_pRecvCq->GetOverlappedResult( pOv, &BytesRet, FALSE );

    pTest->m_pRecvCq->Release();

    if( hr == ND_CANCELED )
        return;

    printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
    exit( __LINE__ );
}


CClientEp::CClientEp( __in CClientTest* pTest ) :
    m_ConnectOv( ConnectSucceeded, ConnectFailed ),
    m_CompleteConnectOv( CompleteConnectSucceeded, CompleteConnectFailed ),
    m_DisconnectOv( DisconnectSucceeded, DisconnectFailed ),
    m_pTest( pTest ),
    m_pEp( NULL ),
    m_pConnector( NULL )
{
}


CClientEp::~CClientEp()
{
    if( m_pEp != NULL )
    {
        m_pEp->Release();
    }

    if( m_pConnector != NULL )
    {
        m_pConnector->Release();
    }
}


HRESULT CClientEp::Init()
{
    HRESULT hr = m_pTest->m_pAdapter->CreateConnector( &m_pConnector );
    if( FAILED( hr ) )
        return hr;

    hr = m_pConnector->CreateEndpoint(
        m_pTest->m_pRecvCq,
        m_pTest->m_pSendCq,
        1,
        1,
        1,
        1,
        0,
        0,
        NULL,
        &m_pEp
        );
    //
    // In the client side test, EP creation failure is not an
    // error (we're trying to connect as fast as possible).
    //
    if( FAILED( hr ) )
        return hr;

    //
    // Pre-post receive request.
    //
    ND_SGE Sge;
    Sge.pAddr = m_pTest->m_pBuf;
    Sge.Length = m_pTest->m_BufferSize;
    Sge.hMr = m_pTest->m_hMr;
    AddRef();
    hr = m_pEp->Receive( &m_Result, &Sge, 1 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    InterlockedIncrement( &m_pTest->m_nEpCreated );

    //
    // Connect the endpoint
    //
    AddRef();
    m_ConnectTime = GetElapsedTime();
    hr = m_pConnector->Connect(
        m_pEp,
        (struct sockaddr*)&m_pTest->m_Addr,
        sizeof( m_pTest->m_Addr ),
        234,
        0,
        NULL,
        0,
        &m_ConnectOv
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::Connect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    return hr;
}


HRESULT CClientEp::Create( __in CClientTest* pTest )
{
    CClientEp* pEp = new CClientEp( pTest );
    if( pEp == NULL )
        return ND_NO_MEMORY;

    HRESULT hr = pEp->Init();
    if( FAILED( hr ) )
        pEp->Release();

    return hr;
}


void CClientEp::ConnectSucceeded( __in COverlapped* pOv )
{
    CClientEp* pEp = CONTAINING_RECORD( pOv, CClientEp, m_ConnectOv );

    //
    // ND_TIMEOUT is a success return value.
    //
    SIZE_T BytesRet;
    HRESULT hr = pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE );
    if( hr == ND_TIMEOUT )
    {
        InterlockedIncrement( &pEp->m_pTest->m_nConnTimeout );
        //
        // Retry, but don't reset the connect time.
        //
        hr = pEp->m_pConnector->Connect(
            pEp->m_pEp,
            (struct sockaddr*)&pEp->m_pTest->m_Addr,
            sizeof( pEp->m_pTest->m_Addr ),
            234,
            0,
            NULL,
            0,
            pOv
            );
        if( FAILED( hr ) )
        {
            pEp->ConnectError( hr );
        }
        return;
    }

    InterlockedExchangeAdd64( &pEp->m_pTest->m_ConnectTime, GetElapsedTime() - pEp->m_ConnectTime );
    pEp->m_CompleteConnectTime = GetElapsedTime();
    hr = pEp->m_pConnector->CompleteConnect( &pEp->m_CompleteConnectOv );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::CompleteConnect failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


void CClientEp::ConnectFailed( __in COverlapped* pOv )
{
    CClientEp* pEp = CONTAINING_RECORD( pOv, CClientEp, m_ConnectOv );

    SIZE_T BytesRet;
    HRESULT hr = pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE );

    pEp->ConnectError( hr );
}


void CClientEp::ConnectError( __in HRESULT hr )
{
    if( hr == ND_CONNECTION_REFUSED && m_pTest->m_fEndTest == false )
    {
        printf( "INDEndpoint::Connect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    if( !m_pTest->m_fEndTest )
    {
        InterlockedIncrement( &m_pTest->m_nConnFailure );
    }
    InterlockedDecrement( &m_pTest->m_nEpCreated );
    Release();
    //
    // Release again to destroy it.
    //
    Release();
}


void CClientEp::CompleteConnectSucceeded( __in COverlapped* pOv )
{
    CClientEp* pEp = CONTAINING_RECORD( pOv, CClientEp, m_CompleteConnectOv );

    //
    // ND_TIMEOUT is a success return value.
    //
    SIZE_T BytesRet;
    HRESULT hr = pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE );
    if( hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::CompleteConnect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    InterlockedExchangeAdd64( &pEp->m_pTest->m_CompleteConnectTime, GetElapsedTime() - pEp->m_CompleteConnectTime );
    //
    // Send a message.
    // We have a reference from the connection - reuse it for the send.
    //
    ND_SGE Sge;
    Sge.pAddr = pEp->m_pTest->m_pBuf;
    Sge.Length = pEp->m_pTest->m_BufferSize;
    Sge.hMr = pEp->m_pTest->m_hMr;
    hr = pEp->m_pEp->Send( &pEp->m_Result, &Sge, 1, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


void CClientEp::CompleteConnectFailed( __in COverlapped* pOv )
{
    CClientEp* pEp = CONTAINING_RECORD( pOv, CClientEp, m_CompleteConnectOv );

    SIZE_T BytesRet;
    printf(
        "INDEndpoint::CompleteConnect failed with %08x\n",
        pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE )
        );
    exit( __LINE__ );
}


void CClientEp::SendDone( __in ND_RESULT* pResult )
{
    CClientEp* pEp = CONTAINING_RECORD( pResult, CClientEp, m_Result );

    if( pResult->Status != ND_SUCCESS )
    {
        printf( "INDEndpoint::Send failed with %08x\n", pResult->Status );
        exit( __LINE__ );
    }

    pEp->Release();
}


void CClientEp::RecvDone( __in ND_RESULT* pResult )
{
    CClientEp* pEp = CONTAINING_RECORD( pResult, CClientEp, m_Result );

    if( pResult->Status != ND_SUCCESS )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", pResult->Status );
        exit( __LINE__ );
    }

    //
    // We have a reference from the receive - reuse it for the disconnect.
    //
    pEp->m_DisconnectTime = GetElapsedTime();

    HRESULT hr = pEp->m_pConnector->Disconnect( &pEp->m_DisconnectOv );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Disconnect failed with %08x\n", hr );
        exit( __LINE__ );
    }
}


void CClientEp::DisconnectSucceeded( __in COverlapped* pOv )
{
    CClientEp* pEp = CONTAINING_RECORD( pOv, CClientEp, m_DisconnectOv );
    pEp->Release();

    InterlockedExchangeAdd64( &pEp->m_pTest->m_DisconnectTime, GetElapsedTime() - pEp->m_DisconnectTime );
    InterlockedIncrement( &pEp->m_pTest->m_nEpDestroyed );
    //
    // Release again to destroy it.
    //
    pEp->Release();
}


void CClientEp::DisconnectFailed( __in COverlapped* pOv )
{
    CClientEp* pEp = CONTAINING_RECORD( pOv, CClientEp, m_DisconnectOv );

    SIZE_T BytesRet;
    printf(
        "INDEndpoint::Disconnect failed with %08x\n",
        pEp->m_pConnector->GetOverlappedResult( pOv, &BytesRet, FALSE )
        );
    exit( __LINE__ );
}


int __cdecl main(int argc, char* argv[])
{
    bool bServer = false;
    bool bClient = false;
    ULONG Address = 0;
    USHORT Port = 0;
    DWORD nThreads = 1;

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 's':
        case 'S':
            bServer = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'c':
        case 'C':
            bClient = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 't':
        case 'T':
            nThreads = atol( ++pArg );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( (bClient && bServer) || (!bClient && !bServer) )
    {
        printf( "Exactly one of client (c or "
            "server (s) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( Port == 0 )
    {
        printf( "Bad port.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( nThreads == 0 )
    {
        printf( "Invalid or missing number of threads, expected positive integer after t.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    if( bServer )
    {
        CServerTest Test( x_XferLen, nThreads );

        Test.OpenAdapter( Address, Port );
        Test.Run();
    }
    else
    {
        CClientTest Test( x_XferLen, nThreads );
        Test.OpenAdapter( Address, Port );
        Test.Run();
    }

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    _fcloseall();

    return 0;
}

