// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndmpic.cpp - Network Direct MS-MPI connection emulator test
//
// This test establishes connections following the same logic as MS-MPI.
//
// Operation:
//  1. Create 2 'ranks', {0,2} for client, {1,3} for server.
//  2. Establish connections:
//      - {0} actively connects to {1,3}
//      - {2} actively connects to {1}, waits for connection from {3}
//      - {1} actively connects to {2}, waits for connection from {0}
//      - {3} actively connects to {0,2}
//
//     This gives:
//      - one active-passive connections between {0,1}
//      - one active-passive connections between {3,2}
//      - two active-active connections between {0,3} and {1,2} with the higher
//        numbered rank taking the active role.
//  3. Transfer a 'close' message
//  4. On each connection, acknowledge the 'close' message with a 'close_ack'
//  5. Wait for completion of 'close_ack' send
//  6. Tear-down connection

#include "precomp.h"
#include <logging.h>

struct PRIVATE_DATA
{
    USHORT Rank;
    UINT8 Key[37];
};

const PRIVATE_DATA x_DefaultData = {
    0,
    64,
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    30,
    31,
    32,
    33,
    34,
    35
};


const LPWSTR TESTNAME = L"ndmpic.exe";

enum NdResultIndex
{
    Recv,
    Send,
    Read,
    MwBind = Read,
    Write,
    MwInvalidate = Write,
    ResultCount
};


class __declspec( novtable) CReference
{
public:
    CReference() : m_nRef( 1 ){};

    void AddRef()
    {
        InterlockedIncrement( &m_nRef );
    }

    void Release()
    {
        if( InterlockedDecrement( &m_nRef ) > 0 )
            return;

        delete this;
    }

protected:
    virtual ~CReference(){};

private:
    LONG m_nRef;
};


//
// COverlapped is a rudimentary class for handling overlapped completions.
//


class COverlapped : public OVERLAPPED
{
public:
    typedef void (*CompletionRoutine)( __in COverlapped* This );

public:
    COverlapped() :
        m_pfnSucceeded( NULL ),
        m_pfnFailed( NULL )
    {
        Internal = 0;
        InternalHigh = 0;
        Pointer = NULL;
        hEvent = NULL;
    };

    void Set( __in CompletionRoutine pfnSucceeded, __in CompletionRoutine pfnFailed )
    {
        m_pfnSucceeded = pfnSucceeded;
        m_pfnFailed = pfnFailed;
    }

    void Complete( __in HRESULT hr )
    {
        if( FAILED( hr ) )
            m_pfnFailed( this );
        else
            m_pfnSucceeded( this );
    }

protected:
    CompletionRoutine m_pfnSucceeded;
    CompletionRoutine m_pfnFailed;
};


//
// CConn: Class representing a connection between two ranks.
// A single rank can have multiple CConn objects.
//
class CConn : public CReference
{
public:
    CConn( __in INDAdapter* pAdapter, __in USHORT Rank );
    ~CConn();

    void Accept(
        __in INDConnector* pConnector,
        __in USHORT PeerRank
        );

    void Connect(
        __in struct sockaddr_in* pAddr,
        __in USHORT PeerRank
        );

    UINT32 GetPeerRank(){ return m_PeerRank; }
    bool IsDone(){ return m_fDone; }

private:
    void DoConnect();
    void SendClose();

private:
    static void AcceptSucceeded( COverlapped* pOv );
    static void AcceptFailed( COverlapped* pOv );
    static void ConnectSucceeded( COverlapped* pOv );
    static void ConnectFailed( COverlapped* pOv );
    static void CompleteConnectSucceeded( COverlapped* pOv );
    static void CompleteConnectFailed( COverlapped* pOv );
    static void NotifySucceeded( COverlapped* pOv );
    static void NotifyFailed( COverlapped* pOv );
    static void DisconnectSucceeded( COverlapped* pOv );
    static void DisconnectFailed( COverlapped* pOv );

private:
    bool m_fDone;
    INDAdapter* m_pAdapter;
    INDCompletionQueue* m_pCq;
    COverlapped m_NotifyOv;
    INDConnector* m_pConn;
    COverlapped m_Ov;
    INDEndpoint* m_pEp;

    ND_MR_HANDLE m_hMr;
    UINT32 m_Buf[2];
    ND_RESULT m_Recv[2];
    ND_RESULT m_Send[2];
    int m_DelayDisconnect;
    bool m_Active;
    enum SendType
    {
        Close,
        CloseAck
    };

    struct sockaddr_in m_Addr;
    USHORT m_Rank;
    USHORT m_PeerRank;
};

CConn::CConn( __in INDAdapter* pAdapter, __in USHORT Rank ) :
    m_fDone( false ),
    m_pAdapter( pAdapter ),
    m_pConn( NULL ),
    m_pEp( NULL ),
    m_DelayDisconnect( 4 ),
    m_Rank( Rank ),
    m_PeerRank( (USHORT)-1 )
{
    m_pAdapter->AddRef();

    //
    // Synchronous memory registration.
    //
    OVERLAPPED Ov = {0};
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( GetLastError(), L"CreateEvent failed with %d", __LINE__ );
    }
    //
    // Prevent completion to the IOCP.
    //
    Ov.hEvent = (HANDLE)((ULONG_PTR)Ov.hEvent | 1);

    HRESULT hr = m_pAdapter->RegisterMemory( m_Buf, sizeof(m_Buf), &Ov, &m_hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = m_pAdapter->GetOverlappedResult( &Ov, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::RegisterMemory failed with %08x", __LINE__ );
    }

    CloseHandle( Ov.hEvent );

    hr = m_pAdapter->CreateCompletionQueue( 4, &m_pCq );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateCompletionQueue failed with %08x", __LINE__ );
    }

    m_NotifyOv.Set( NotifySucceeded, NotifyFailed );
    AddRef();
    hr = m_pCq->Notify( ND_CQ_NOTIFY_ANY, &m_NotifyOv );
    if( FAILED( hr ) )
    {
        Release();
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDCompletionQueue::Notify failed with %08x", __LINE__ );
    }
}

void CConn::NotifySucceeded( COverlapped* pOv )
{
    HRESULT hr;
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_NotifyOv );

    for( ;; )
    {
        ND_RESULT* pResult;
        SIZE_T nResults = pConn->m_pCq->GetResults( &pResult, 1 );
        if( nResults == 0 )
            break;

        pConn->m_DelayDisconnect--;
        pConn->Release();

        if( pResult >= pConn->m_Recv && pResult < &pConn->m_Recv[_countof( pConn->m_Recv )] )
        {
            if( pResult->Status != ND_SUCCESS )
            {
                if( pResult->Status == ND_CANCELED )
                {
                    continue;
                }
                LOG_FAILURE_HRESULT_AND_EXIT( pResult->Status, L"INDEndpoint::Receive failed with %08x", __LINE__ );
            }

            if( pResult->BytesTransferred != 0 )
            {
                //
                // Received 'close' message, send close-ack.  If we took the passive connection role,
                // send our own close.
                //
                if( !pConn->m_Active )
                    pConn->SendClose();

                pConn->AddRef();
                printf( "%d close from %d\n", pConn->m_Rank, pConn->m_PeerRank );
                hr = pConn->m_pEp->Send( &pConn->m_Send[CloseAck], NULL, 0, 0 );
                if( FAILED( hr ) )
                {
                    pConn->Release();
                    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
                }
            }
            else
            {
                printf( "%d close_ack from %d\n", pConn->m_Rank, pConn->m_PeerRank );
            }
        }
        else if( pResult->Status != ND_SUCCESS )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( pResult->Status, L"INDEndpoint::Send failed with %08x", __LINE__ );
        }
    }

    if( pConn->m_DelayDisconnect == 0 )
    {
        printf( "%d disconnect from %d\n", pConn->m_Rank, pConn->m_PeerRank );
        pConn->m_Ov.Set( DisconnectSucceeded, DisconnectFailed );
        pConn->AddRef();
        hr = pConn->m_pConn->Disconnect( &pConn->m_Ov );
        if( FAILED( hr ) )
        {
            pConn->Release();
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Disconnect failed with %08x", __LINE__ );
        }
    }

    hr = pConn->m_pCq->Notify( ND_CQ_NOTIFY_ANY, &pConn->m_NotifyOv );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDCompletionQueue::Notify failed with %08x", __LINE__ );
    }
}

void CConn::NotifyFailed( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_NotifyOv );
    SIZE_T BytesRet;
    HRESULT hr = pConn->m_pCq->GetOverlappedResult( pOv, &BytesRet, FALSE );
    if( hr == ND_CANCELED )
    {
        pConn->Release();
        return;
    }

    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDCompletionQueue::Notify failed with %08x", __LINE__ );
}

void CConn::DisconnectSucceeded( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );
    printf( "%d disconnected from %d\n", pConn->m_Rank, pConn->m_PeerRank );
    pConn->m_fDone = true;
    pConn->Release();
}

void CConn::DisconnectFailed( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );
    SIZE_T BytesRet;
    HRESULT hr = pConn->m_pConn->GetOverlappedResult( pOv, &BytesRet, FALSE );

    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Disconnect failed with %08x", __LINE__ );
}

CConn::~CConn()
{
    m_pEp->Release();
    m_pConn->CancelOverlappedRequests();
    m_pConn->Release();
    m_pCq->CancelOverlappedRequests();
    m_pCq->Release();
    m_pAdapter->Release();
}

void CConn::Accept(
    INDConnector* pConnector,
    USHORT PeerRank
    )
{
    HRESULT hr;

    m_pConn = pConnector;
    m_PeerRank = PeerRank;

    hr = m_pConn->CreateEndpoint( m_pCq, m_pCq, 2, 2, 1, 1, 0, 0, NULL, &m_pEp );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CreateEndpoint failed with %08x", __LINE__ );
    }

    ND_SGE Sge;
    Sge.hMr = m_hMr;

    for( int i = 0; i < _countof( m_Recv ); i++ )
    {
        Sge.pAddr = &m_Buf[i];
        Sge.Length = sizeof(m_Buf[i]);

        AddRef();
        hr = m_pEp->Receive( &m_Recv[i], &Sge, 1 );
        if( FAILED( hr ) )
        {
            Release();
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
        }
    }

    m_Ov.Set( AcceptSucceeded, AcceptFailed );
    printf( "%d accept from %d\n", m_Rank, m_PeerRank );
    AddRef();
    hr = m_pConn->Accept( m_pEp, NULL, 0, &m_Ov );
    if( FAILED( hr ) )
    {
        Release();
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Accept failed with %08x", __LINE__ );
    }

    m_Active = false;
}

void CConn::AcceptSucceeded( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );

    printf( "%d connected to %d\n", pConn->m_Rank, pConn->m_PeerRank );

    //
    // Release the reference for the Accept
    //
    pConn->Release();
}

void CConn::SendClose()
{
    //
    // Send the 'close' message.
    //
    ND_SGE Sge;
    Sge.pAddr = &m_Buf[0];
    Sge.Length = sizeof(m_Buf[0]);
    Sge.hMr = m_hMr;
    AddRef();
    printf( "%d close to %d\n", m_Rank, m_PeerRank );
    HRESULT hr = m_pEp->Send( &m_Send[Close], &Sge, 1, 0 );
    if( FAILED( hr ) )
    {
        Release();
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }
}

void CConn::AcceptFailed( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );

    SIZE_T BytesRet;
    HRESULT hr = pConn->m_pConn->GetOverlappedResult( pOv, &BytesRet, FALSE );

    if( hr == ND_CONNECTION_ABORTED )
    {
        //
        // The other side will retry the connection, which will cause this object
        // to be destroyed by its owning CRank.
        //
        // Flush the endpoint to release the Receive references, and release
        // the Accept reference.
        //
        pConn->m_pEp->Flush();
        pConn->Release();
        return;
    }
    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Accept failed with %08x", __LINE__ );
}

void CConn::Connect(
    __in struct sockaddr_in* pAddr,
    __in USHORT PeerRank
    )
{
    HRESULT hr;

    hr = m_pAdapter->CreateConnector( &m_pConn );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    hr = m_pConn->CreateEndpoint( m_pCq, m_pCq, 2, 2, 1, 1, 0, 0, NULL, &m_pEp );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CreateEndpoint failed with %08x", __LINE__ );
    }

    ND_SGE Sge;
    Sge.hMr = m_hMr;

    for( int i = 0; i < _countof( m_Recv ); i++ )
    {
        Sge.pAddr = &m_Buf[i];
        Sge.Length = sizeof(m_Buf[i]);

        AddRef();
        hr = m_pEp->Receive( &m_Recv[i], &Sge, 1 );
        if( FAILED( hr ) )
        {
            Release();
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
        }
    }

    m_PeerRank = PeerRank;
    m_Addr = *pAddr;
    m_Addr.sin_port = htons( 1000 + m_PeerRank );

    DoConnect();
}

void CConn::DoConnect()
{
    PRIVATE_DATA Data = x_DefaultData;
    Data.Rank = m_Rank;

    m_Ov.Set( ConnectSucceeded, ConnectFailed );
    AddRef();
    printf( "%d connect to %d\n", m_Rank, m_PeerRank );
    HRESULT hr = m_pConn->Connect( m_pEp, (sockaddr*)&m_Addr, sizeof(m_Addr), 234, 0, &Data, sizeof(Data), &m_Ov );
    if( FAILED( hr ) )
    {
        Release();
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Connect failed with %08x", __LINE__ );
    }
    m_Active = true;
}

void CConn::ConnectSucceeded( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );

    SIZE_T BytesRet;
    HRESULT hr = pConn->m_pConn->GetOverlappedResult( pOv, &BytesRet, FALSE );

    if( hr == ND_TIMEOUT )
    {
        //
        // Try again.
        //
        pConn->DoConnect();
    }
    else
    {
        pOv->Set( CompleteConnectSucceeded, CompleteConnectFailed );
        pConn->AddRef();
        hr = pConn->m_pConn->CompleteConnect( pOv );
        if( FAILED( hr ) )
        {
            pConn->Release();
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CompleteConnect failed with %08x", __LINE__ );
        }
    }
    pConn->Release();
}

void CConn::ConnectFailed( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );

    SIZE_T BytesRet;
    HRESULT hr = pConn->m_pConn->GetOverlappedResult( pOv, &BytesRet, FALSE );

    switch( hr )
    {
    case ND_CONNECTION_REFUSED:
        if( pConn->m_Rank > pConn->m_PeerRank )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Connect failed with %08x", __LINE__ );
        }
        pConn->m_pEp->Flush();
        __fallthrough;

    case ND_CANCELED:
        pConn->Release();
        break;

    default:
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Connect failed with %08x", __LINE__ );
    }
}

void CConn::CompleteConnectSucceeded( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );

    printf( "%d connected to %d\n", pConn->m_Rank, pConn->m_PeerRank );
    pConn->SendClose();

    //
    // Release the CompleteConnect reference.
    //
    pConn->Release();
}

void CConn::CompleteConnectFailed( COverlapped* pOv )
{
    CConn* pConn = CONTAINING_RECORD( pOv, CConn, m_Ov );

    SIZE_T BytesRet;
    HRESULT hr = pConn->m_pConn->GetOverlappedResult( pOv, &BytesRet, FALSE );

    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Connect failed with %08x", __LINE__ );
}


//
// CRank: represents a rank in the test.
//
class CRank : public CReference
{
public:
    CRank( __in INDAdapter* pAdapter, __in USHORT Rank );
    ~CRank();

    void Connect(
        __in struct sockaddr_in* pAddr,
        __in USHORT Rank
        );

    bool IsDone();

private:
    static void GetConnectionRequestSucceeded( COverlapped* pOv );
    static void GetConnectionRequestFailed( COverlapped* pOv );

private:
    INDAdapter* m_pAdapter;
    INDListen* m_pListen;
    COverlapped m_ListenOv;
    INDConnector* m_pConnector;

    CConn* m_pConn[2];

    USHORT m_Rank;
};

CRank::CRank( INDAdapter* pAdapter, USHORT Rank ) :
    m_pAdapter( pAdapter ),
    m_Rank( Rank )
{
    HRESULT hr;
    USHORT Port = htons( 1000 + m_Rank );

    pAdapter->AddRef();

    for( int i = 0; i < _countof(m_pConn); i++ )
    {
        m_pConn[i] = NULL;
    }

    hr = pAdapter->Listen( 0, 234, Port, NULL, &m_pListen );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Listen failed with %08x", __LINE__ );
    }

    hr = pAdapter->CreateConnector( &m_pConnector );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    m_ListenOv.Set( GetConnectionRequestSucceeded, GetConnectionRequestFailed );
    AddRef();
    hr = m_pListen->GetConnectionRequest( m_pConnector, &m_ListenOv );
    if( FAILED( hr ) )
    {
        Release();
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDListen::GetConnectionRequest failed with %08x", __LINE__ );
    }
}

CRank::~CRank()
{
    m_pListen->CancelOverlappedRequests();
    m_pListen->Release();
    m_pAdapter->Release();
}

void CRank::Connect(
    __in struct sockaddr_in* pAddr,
    __in USHORT Rank
    )
{
    //
    // Find the index into the connection array.
    //
    int i = Rank >> 1;

    if( m_pConn[i] != NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Connection is not NULL", __LINE__ );
    }

    m_pConn[i] = new CConn( m_pAdapter, m_Rank );
    if( m_pConn[i] == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate CConn", __LINE__ );
    }

    AddRef();
    m_pConn[i]->Connect( pAddr, Rank );
}

bool CRank::IsDone()
{
    for( int i = 0; i < _countof( m_pConn ); i++ )
    {
        if( m_pConn[i] != NULL )
        {
            if( m_pConn[i]->IsDone() )
            {
                m_pConn[i]->Release();
                m_pConn[i] = NULL;
            }
            else
            {
                return false;
            }
        }
    }
    return true;
}

void CRank::GetConnectionRequestSucceeded( COverlapped* pOv )
{
    CRank* pRank = CONTAINING_RECORD( pOv, CRank, m_ListenOv );

    HRESULT hr;
    PRIVATE_DATA Data;
    SIZE_T Len = sizeof(Data);

    hr = pRank->m_pConnector->GetConnectionData( NULL, NULL, &Data, &Len );
    if( FAILED( hr ) && hr != ND_BUFFER_OVERFLOW || Len < sizeof(Data) )
    {
        //
        // May have timed out...
        //
        pRank->m_pConnector->Reject( NULL, 0 );
        pRank->m_pConnector->Release();
        pRank->m_pConnector = NULL;

        if( hr != ND_CONNECTION_ABORTED )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::GetConnectionData failed with %08x", __LINE__ );
        }
        goto next;
    }

    switch( pRank->m_Rank )
    {
    case 0:
        switch( Data.Rank )
        {
        case 3:
            break;
        default:
            LOG_FAILURE_AND_EXIT( L"0 received connection request from invalid rank", __LINE__ );
        }
        break;

    case 1:
        switch( Data.Rank )
        {
        case 0:
        case 2:
            break;
        default:
            LOG_FAILURE_AND_EXIT( L"1 received connection request from invalid rank", __LINE__ );
        }
        break;

    case 2:
        switch( Data.Rank )
        {
        case 1:
        case 3:
            break;
        default:
            LOG_FAILURE_AND_EXIT( L"2 received connection request from invalid rank", __LINE__ );
        }
        break;

    case 3:
        switch( Data.Rank )
        {
        case 0:
            break;
        default:
            LOG_FAILURE_AND_EXIT( L"1 received connection request from invalid rank", __LINE__ );
        }
        break;
    }

    int iConn = Data.Rank >> 1;
    if( pRank->m_pConn[iConn] != NULL )
    {
        //
        // Head to head.  See who wins.
        //
        if( pRank->m_Rank > Data.Rank )
        {
            //
            // Our connection request will take the active role.  Reject.
            //
            printf( "%d reject %d\n", pRank->m_Rank, Data.Rank );
            pRank->m_pConnector->Reject( NULL, 0 );
            goto next;
        }

        //
        // Our connection request will be rejected by the other side.
        //
        pRank->m_pConn[iConn]->Release();
        pRank->m_pConn[iConn] = NULL;
    }

    struct sockaddr_in DestAddr;
    Len = sizeof(DestAddr);
    hr = pRank->m_pConnector->GetPeerAddress(
        (struct sockaddr*)&DestAddr,
        &Len
        );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::GetPeerAddress failed with %08x", __LINE__ );
    }

    pRank->m_pConn[iConn] = new CConn( pRank->m_pAdapter, pRank->m_Rank );
    if( pRank->m_pConn[iConn] == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate CConn", __LINE__ );
    }

    pRank->m_pConn[iConn]->Accept( pRank->m_pConnector, Data.Rank );

next:
    hr = pRank->m_pAdapter->CreateConnector( &pRank->m_pConnector );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    hr = pRank->m_pListen->GetConnectionRequest( pRank->m_pConnector, &pRank->m_ListenOv );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDListen::GetConnectionRequest failed with %08x", __LINE__ );
    }
}

void CRank::GetConnectionRequestFailed( COverlapped* pOv )
{
    CRank* pRank = CONTAINING_RECORD( pOv, CRank, m_ListenOv );

    SIZE_T BytesRet;
    HRESULT hr = pRank->m_pListen->GetOverlappedResult( pOv, &BytesRet, FALSE );

    if( hr == ND_CANCELED )
        return;

    LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDListen::GetConnectionRequest failed with %08x", __LINE__ );
}


void ShowUsage()
{
    printf( "ndmpic <0|1> <remote ip> [l<log>]\n"
        "\t0 - start ranks 0 & 1\n"
        "\t1 - start ranks 2 & 3\n"
        "\t<remote ip> - IPv4 Address of other process\n"
        "\tl - log output to a file named <log>.\n");
}


void TestRoutine(
    __in ULONG Address,
    __in USHORT Rank
    )
{
    struct sockaddr_in v4 = {0};
    struct sockaddr_in LocalAddr;

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = 0;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdResolveAddress failed with %08x", __LINE__ );
    }

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &pAdapter );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdOpenIAdapter failed with %08x", __LINE__ );
    }

    HANDLE hIocp = CreateIoCompletionPort( pAdapter->GetFileHandle(), NULL, 0, 0 );
    if( hIocp == NULL )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( GetLastError(), L"CreateIoCompletionPort failed with %d", __LINE__ );
    }

    CRank* pRank[2];
    pRank[0] = new CRank( pAdapter, Rank );
    if( pRank[0] == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate CRank[0]", __LINE__ );
    }
    pRank[1] = new CRank( pAdapter, Rank + 2 );
    if( pRank[0] == NULL || pRank[1] == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate CRank[1]", __LINE__ );
    }

    //
    // Give the other side a little time to come up...
    //
    Sleep( 5000 );

    //
    // Start connections.
    //
    if( Rank == 0 )
    {
        pRank[0]->Connect( &v4, 1 );
        pRank[0]->Connect( &v4, 3 );
        pRank[1]->Connect( &v4, 1 );
    }
    else
    {
        pRank[0]->Connect( &v4, 2 );
        pRank[1]->Connect( &v4, 0 );
        pRank[1]->Connect( &v4, 2 );
    }

    bool fDone;
    do
    {
        DWORD bytesRet;
        ULONG_PTR key;
        OVERLAPPED* pOv = NULL;
        GetQueuedCompletionStatus( hIocp, &bytesRet, &key, &pOv, 100 );
        if( pOv )
        {
            SIZE_T BytesRet;
            hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, FALSE );
            static_cast<COverlapped*>(pOv)->Complete( hr );
        }
        else if( GetLastError() != WAIT_TIMEOUT )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( GetLastError(), L"GetQueuedCompletionStatus returned %d", __LINE__ );
        }

        fDone = true;
        for( int i = 0; i < _countof( pRank ); i++ )
        {
            if( !pRank[i]->IsDone() )
            {
                fDone = false;
                break;
            }
        }

    } while( !fDone );
}


int __cdecl main(int argc, char* argv[])
{
    USHORT BaseRank = 0;
    ULONG Address = 0;

    INIT_LOG( TESTNAME );

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case '1':
            BaseRank = 1;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            break;
        case '0':
            BaseRank = 0;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( BaseRank > 1 )
    {
        printf( "Rank must be 0 or 1\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdStartup failed with %08x", __LINE__ );
    }

    TestRoutine( Address, BaseRank );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdCleanup failed with %08x", __LINE__ );
    }

    END_LOG( TESTNAME );

    _fcloseall();

    return 0;
}

