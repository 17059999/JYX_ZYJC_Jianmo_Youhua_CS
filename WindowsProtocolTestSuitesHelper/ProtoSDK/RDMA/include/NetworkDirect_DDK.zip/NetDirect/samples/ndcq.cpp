// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndcq.cpp - Network Direct completion queue test
//

#include "precomp.h"


const SIZE_T x_Iterations = 1000;


void ShowUsage()
{
    printf( "ndcq <ip> [l<log>]\n"
        "\t<ip> - IPv4 Address\n"
        "\tl - log output to a file named <log>.\n");
}


void TestRoutine( __in ULONG Address )
{
    INDAdapter* pAdapter;
    INDCompletionQueue* pCq1;
    OVERLAPPED Ov1 = {0};
    INDCompletionQueue* pCq2;
    OVERLAPPED Ov2 = {0};

    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = 0;

    HRESULT hr = NdOpenIAdapter(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        &pAdapter
        );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    HANDLE hIocp = CreateIoCompletionPort( pAdapter->GetFileHandle(), NULL, 0, 0 );
    if( hIocp == NULL )
    {
        printf( "Failed to bind adapter to IOCP, error %d\n", GetLastError() );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Create CQs
    //
    hr = pAdapter->CreateCompletionQueue( Info.MaxCqEntries, &pCq1 );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    hr = pAdapter->CreateCompletionQueue( Info.MaxCqEntries, &pCq2 );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    OVERLAPPED* pOv;
    DWORD BytesRet;
    ULONG_PTR Key;
    SIZE_T BytesRet2;

    //
    // Request notification and cancel in the same order as request.
    //
    printf( "Testing in-order notify/cancelation..." );
    for( SIZE_T i = 0; i < x_Iterations; i++ )
    {
        //
        // Request CQ notifications.
        //
        hr = pCq1->Notify( ND_CQ_NOTIFY_ANY, &Ov1 );
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }
        hr = pCq2->Notify( ND_CQ_NOTIFY_ANY, &Ov2 );
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Cancel CQ notifications.
        //
        hr = pCq1->CancelOverlappedRequests();
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::CancelOverlappedResult failed with %08x\n", hr );
            exit( __LINE__ );
        }

        hr = pCq2->CancelOverlappedRequests();
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::CancelOverlappedResult failed with %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Reap completed I/Os.
        //
        // First should be Ov1, since we canceled it first.
        //
        BOOL fSuccess = GetQueuedCompletionStatus( hIocp, &BytesRet, &Key, &pOv, 0 );
        if( fSuccess == TRUE )
        {
            printf( "Expected failure due to canceled I/O\n" );
            exit( __LINE__ );
        }

        if( pOv != &Ov1 )
        {
            printf( "Expected Send OV %p, got %p\n", &Ov1, pOv );
            exit( __LINE__ );
        }

        hr = pCq1->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( hr != ND_CANCELED )
        {
            printf( "Expected ND_CANCELED, got %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Second should be Ov2, since we canceled it second.
        //
        fSuccess = GetQueuedCompletionStatus( hIocp, &BytesRet, &Key, &pOv, 0 );
        if( fSuccess == TRUE )
        {
            printf( "Expected failure due to canceled I/O\n" );
            exit( __LINE__ );
        }

        if( pOv != &Ov2 )
        {
            printf( "Expected Recv OV %p, got %p\n", &Ov2, pOv );
            exit( __LINE__ );
        }

        hr = pCq2->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( hr != ND_CANCELED )
        {
            printf( "Expected ND_CANCELED, got %08x\n", hr );
            exit( __LINE__ );
        }
    }
    printf( "PASSED\n" );

    //
    // Request notification and cancel in reverse order.
    //
    printf( "Testing reverse-order notify/cancelation..." );
    for( SIZE_T i = 0; i < x_Iterations; i++ )
    {
        //
        // Request CQ notifications.
        //
        hr = pCq1->Notify( ND_CQ_NOTIFY_ANY, &Ov1 );
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }
        hr = pCq2->Notify( ND_CQ_NOTIFY_ANY, &Ov2 );
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Cancel CQ notifications.
        //
        hr = pCq2->CancelOverlappedRequests();
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::CancelOverlappedResult failed with %08x\n", hr );
            exit( __LINE__ );
        }

        hr = pCq1->CancelOverlappedRequests();
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::CancelOverlappedResult failed with %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Reap completed I/Os.
        //
        // First should be Ov2, since we canceled it first.
        //
        BOOL fSuccess = GetQueuedCompletionStatus( hIocp, &BytesRet, &Key, &pOv, 0 );
        if( fSuccess == TRUE )
        {
            printf( "Expected failure due to canceled I/O\n" );
            exit( __LINE__ );
        }

        if( pOv != &Ov2 )
        {
            printf( "Expected Send OV %p, got %p\n", &Ov1, pOv );
            exit( __LINE__ );
        }

        hr = pCq2->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( hr != ND_CANCELED )
        {
            printf( "Expected ND_CANCELED, got %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Second should be Ov1, since we canceled it second.
        //
        fSuccess = GetQueuedCompletionStatus( hIocp, &BytesRet, &Key, &pOv, 0 );
        if( fSuccess == TRUE )
        {
            printf( "Expected failure due to canceled I/O\n" );
            exit( __LINE__ );
        }

        if( pOv != &Ov1 )
        {
            printf( "Expected Recv OV %p, got %p\n", &Ov2, pOv );
            exit( __LINE__ );
        }

        hr = pCq1->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( hr != ND_CANCELED )
        {
            printf( "Expected ND_CANCELED, got %08x\n", hr );
            exit( __LINE__ );
        }
    }
    printf( "PASSED\n" );

    //
    // Multiple requests to the same CQ.
    //
    printf( "Testing multiple notify/cancelation on one CQ..." );
    for( SIZE_T i = 0; i < x_Iterations; i++ )
    {
        //
        // Request CQ notifications.
        //
        hr = pCq1->Notify( ND_CQ_NOTIFY_ANY, &Ov1 );
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }
        hr = pCq1->Notify( ND_CQ_NOTIFY_ANY, &Ov2 );
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Cancel CQ notifications.
        //
        hr = pCq1->CancelOverlappedRequests();
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::CancelOverlappedResult failed with %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Reap completed I/Os.
        //
        // First should be Ov1, since we requested it first.
        //
        BOOL fSuccess = GetQueuedCompletionStatus( hIocp, &BytesRet, &Key, &pOv, 0 );
        if( fSuccess == TRUE )
        {
            printf( "Expected failure due to canceled I/O\n" );
            exit( __LINE__ );
        }

        if( pOv != &Ov1 )
        {
            printf( "Expected Send OV %p, got %p\n", &Ov1, pOv );
            exit( __LINE__ );
        }

        hr = pCq1->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( hr != ND_CANCELED )
        {
            printf( "Expected ND_CANCELED, got %08x\n", hr );
            exit( __LINE__ );
        }

        //
        // Second should be Ov2, since we requested it second.
        //
        fSuccess = GetQueuedCompletionStatus( hIocp, &BytesRet, &Key, &pOv, 0 );
        if( fSuccess == TRUE )
        {
            printf( "Expected failure due to canceled I/O\n" );
            exit( __LINE__ );
        }

        if( pOv != &Ov2 )
        {
            printf( "Expected Recv OV %p, got %p\n", &Ov2, pOv );
            exit( __LINE__ );
        }

        hr = pCq1->GetOverlappedResult( pOv, &BytesRet2, FALSE );
        if( hr != ND_CANCELED )
        {
            printf( "Expected ND_CANCELED, got %08x\n", hr );
            exit( __LINE__ );
        }
    }
    printf( "PASSED\n" );

    pCq1->Release();
    pCq2->Release();
    pAdapter->Release();

    CloseHandle( hIocp );
}


int __cdecl main(int argc, char* argv[])
{
    ULONG Address = 0;

    if( argc < 2 || argc > 3 )
    {
        ShowUsage();
        exit( __LINE__ );
    }

    Address = inet_addr( argv[1] );

    if( argc == 3 )
    {
        if( argv[2][0] != 'l' &&
            argv[2][0] != 'L' )
        {
            ShowUsage();
            exit( __LINE__ );
        }

//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
        if( freopen( &argv[2][1], "w", stdout ) == NULL ||
            freopen( &argv[2][1], "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
        {
            printf( "Could not open log file.\n" );
            exit( __LINE__ );
        }
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    TestRoutine( Address );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    _fcloseall();

    return 0;
}

