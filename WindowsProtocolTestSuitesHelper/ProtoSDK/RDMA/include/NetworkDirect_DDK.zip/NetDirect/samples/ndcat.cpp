// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndcat.cpp - Network Direct catalog test
//
// This test checks that the input IP address is a valid NetworkDirect
// address, and that all addresses returned by QueryAddressList are
// valid NetworkDirect addresses.  If there are no addresses the test
// generates an error.

#include "precomp.h"
#include <logging.h>


const LPWSTR TESTNAME = L"ndcat.exe";


void ShowUsage()
{
    printf( "ndcat <ip> [l<log>]\n"
        "\t<ip> - IPv4 Address\n"
        "\tl - log output to a file named <log>.\n");
}


int __cdecl main(int argc, char* argv[])
{
    INIT_LOG( TESTNAME );

    if( argc < 2 || argc > 3 )
    {
        ShowUsage();
        exit( __LINE__ );
    }

    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = inet_addr( argv[1] );
    v4.sin_port = 0;

    if( argc == 3 )
    {
        if( argv[2][0] != 'l' &&
            argv[2][0] != 'L' )
        {
            ShowUsage();
            exit( __LINE__ );
        }

//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
        if( freopen( &argv[2][1], "w", stdout ) == NULL ||
            freopen( &argv[2][1], "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
        {
            printf( "Could not open log file.\n" );
            exit( __LINE__ );
        }
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdStartup failed with %08x", __LINE__ );
    }

    hr = NdCheckAddress( (struct sockaddr*)&v4, sizeof(v4) );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdCheckAddress for input address returned %08x", __LINE__ );
    }

    SIZE_T Len = 0;
    hr = NdQueryAddressList( 0, NULL, &Len );
    if( hr != ND_BUFFER_OVERFLOW )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdQueryAddressList returned %08x", __LINE__ );
    }

    if( Len == 0 )
    {
        LOG_FAILURE_AND_EXIT( L"NdQueryAddressList returned zero-length list", __LINE__ );
    }

    SOCKET_ADDRESS_LIST* pList = (SOCKET_ADDRESS_LIST*)HeapAlloc( GetProcessHeap(), 0, Len );
    if( pList == NULL )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( (HRESULT)Len, L"Failed to allocate address list (%d bytes)", __LINE__ );
    }

    hr = NdQueryAddressList( 0, pList, &Len );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdQueryAddressList returned %08x", __LINE__ );
    }

    if( pList->iAddressCount == 0 )
    {
        LOG_FAILURE_AND_EXIT( L"NdQueryAddressList returned zero-length list", __LINE__ );
    }

    for( int i = 0; i < pList->iAddressCount; i++ )
    {
        hr = NdCheckAddress( pList->Address[i].lpSockaddr, pList->Address[i].iSockaddrLength );
        if( FAILED( hr ) )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdCheckAddress returned %08x", __LINE__ );
        }
    }

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdCleanup failed with %08x", __LINE__ );
    }

    END_LOG( TESTNAME );

    _fcloseall();

    return 0;
}

