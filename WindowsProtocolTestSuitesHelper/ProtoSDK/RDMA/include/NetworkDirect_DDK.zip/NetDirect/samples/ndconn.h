// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndconn.h - Network Direct connection scalability test
//

#pragma once


inline DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}

inline LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}

inline LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}

inline LONGLONG GetFrequency()
{
    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    return Frequency.QuadPart;
}


class __declspec( novtable) CReference
{
public:
    CReference() : m_nRef( 1 ){};

    void AddRef()
    {
        InterlockedIncrement( &m_nRef );
    }

    void Release()
    {
        if( InterlockedDecrement( &m_nRef ) > 0 )
            return;

        delete this;
    }

protected:
    virtual ~CReference(){};

private:
    LONG m_nRef;
};


class COverlapped : public OVERLAPPED
{
public:
    typedef void (*CompletionRoutine)( __in COverlapped* This );

public:
    COverlapped( __in CompletionRoutine pfnSucceeded, __in CompletionRoutine pfnFailed ) :
        m_pfnSucceeded( pfnSucceeded ),
        m_pfnFailed( pfnFailed )
    {
        Internal = 0;
        InternalHigh = 0;
        Pointer = NULL;
        hEvent = NULL;
    };

    void Succeeded(){ m_pfnSucceeded( this ); }
    void Failed(){ m_pfnFailed( this ); }

protected:
    CompletionRoutine m_pfnSucceeded;
    CompletionRoutine m_pfnFailed;
};


class CTest
{
public:
    CTest( __in SIZE_T BufferSize );
    ~CTest();

protected:
    void Start();

protected:
    HANDLE m_hIocp;
    INDAdapter* m_pAdapter;
    char* m_pBuf;
    SIZE_T m_BufferSize;
    ND_MR_HANDLE m_hMr;

    volatile bool m_fEndTest;
};


//
// Client test object.
//
class CClientTest : public CTest
{
    friend class CClientEp;

public:
    CClientTest( __in SIZE_T BufferSize, __in LONG nThreads );
    ~CClientTest();

    void Run();
    void OpenAdapter( __in ULONG Address, __in USHORT Port );

protected:
    static DWORD WINAPI TestRoutine( __in LPVOID This );

private:
    static void SendSucceeded( __in COverlapped* pOv );
    static void SendFailed( __in COverlapped* pOv );
    static void RecvSucceeded( __in COverlapped* pOv );
    static void RecvFailed( __in COverlapped* pOv );

protected:
    INDCompletionQueue* m_pSendCq;
    COverlapped m_SendOv;
    INDCompletionQueue* m_pRecvCq;
    COverlapped m_RecvOv;

    struct sockaddr_in m_Addr;

    LONG m_nThreads;

    volatile LONG m_nEpCreated;
    volatile LONG m_nEpDestroyed;

    volatile LONGLONG m_ConnectTime;
    volatile LONGLONG m_CompleteConnectTime;
    volatile LONGLONG m_DisconnectTime;

    volatile LONG m_nConnFailure;
    volatile LONG m_nConnTimeout;
};


//
// Server test object.
//
class CServerTest : public CTest
{
    friend class CServerEp;
    friend class CConnReq;

public:
    CServerTest( __in SIZE_T BufferSize, __in LONG nThreads );
    ~CServerTest();

    void Run();
    void OpenAdapter( __in ULONG Address, __in USHORT Port );

protected:
    static DWORD WINAPI TestRoutine( __in LPVOID This );

private:
    static void SendSucceeded( __in COverlapped* pOv );
    static void SendFailed( __in COverlapped* pOv );
    static void RecvSucceeded( __in COverlapped* pOv );
    static void RecvFailed( __in COverlapped* pOv );

protected:
    INDListen* m_pListen;
    INDCompletionQueue* m_pSendCq;
    COverlapped m_SendOv;
    INDCompletionQueue* m_pRecvCq;
    COverlapped m_RecvOv;

    LONG m_nThreads;

    volatile LONG m_nEpCreated;
    volatile LONG m_nEpDestroyed;
    volatile LONG m_nOv;

    volatile LONGLONG m_AcceptTime;
    volatile LONGLONG m_DisconnectTime;

    volatile LONG m_nConnFailure;
};


class CConnReq : public COverlapped
{
public:
    CConnReq( CServerTest* pTest ) :
        COverlapped( GetConnSucceeded, GetConnFailed ),
        m_pTest( pTest ),
        m_pConnector( NULL )
    {
        GetNextRequest();
    };

    ~CConnReq()
    {
        if( m_pConnector )
        {
            m_pConnector->Release();
        }
    }

private:
    void GetNextRequest();

private:
    static void GetConnSucceeded( __in COverlapped* pOv );
    static void GetConnFailed( __in COverlapped* pOv );

public:
    CServerTest* m_pTest;
    INDConnector* m_pConnector;
};


class CServerEp : public CReference
{
    friend class CServerTest;

private:
    CServerEp( __in CServerTest* pTest );
    ~CServerEp();
    HRESULT Init( __in INDConnector* pConnector );

public:
    static HRESULT Create( __in CServerTest* pTest, __in INDConnector* pConnector );

private:
    void Send();
    void AcceptError( __in HRESULT hr );

private:
    static void AcceptSucceeded( __in COverlapped* pOv );
    static void AcceptFailed( __in COverlapped* pOv );
    static void DisconnectSucceeded( __in COverlapped* pOv );
    static void DisconnectFailed( __in COverlapped* pOv );
    static void NotifyDisconnectSucceeded( __in COverlapped* pOv );
    static void NotifyDisconnectFailed( __in COverlapped* pOv );

    static void SendDone( __in ND_RESULT* pResult );
    static void RecvDone( __in ND_RESULT* pResult );

private:
    LONGLONG m_AcceptTime;
    LONGLONG m_DisconnectTime;
    CServerTest* m_pTest;
    INDConnector* m_pConnector;
    INDEndpoint* m_pEp;
    COverlapped m_AcceptOv;
    COverlapped m_DisconnectOv;
    COverlapped m_NotifyDisconnectOv;
    ND_RESULT m_Result;

    volatile LONG m_fDoSend;
};


class CClientEp : public CReference
{
    friend class CClientTest;

private:
    CClientEp( __in CClientTest* pTest );
    ~CClientEp();
    HRESULT Init();

public:
    static HRESULT Create( __in CClientTest* pTest );

private:
    void ConnectError( __in HRESULT hr );

private:
    static void ConnectSucceeded( __in COverlapped* pOv );
    static void ConnectFailed( __in COverlapped* pOv );
    static void CompleteConnectSucceeded( __in COverlapped* pOv );
    static void CompleteConnectFailed( __in COverlapped* pOv );
    static void DisconnectSucceeded( __in COverlapped* pOv );
    static void DisconnectFailed( __in COverlapped* pOv );

    static void SendDone( __in ND_RESULT* pResult );
    static void RecvDone( __in ND_RESULT* pResult );

private:
    LONGLONG m_ConnectTime;
    LONGLONG m_CompleteConnectTime;
    LONGLONG m_DisconnectTime;
    CClientTest* m_pTest;
    INDConnector* m_pConnector;
    INDEndpoint* m_pEp;
    COverlapped m_ConnectOv;
    COverlapped m_CompleteConnectOv;
    COverlapped m_DisconnectOv;
    ND_RESULT m_Result;
};


