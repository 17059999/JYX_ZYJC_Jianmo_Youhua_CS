// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// Net Direct Helper Interface
//

#pragma once

#ifndef _NETDIRECT_H_
#define _NETDIRECT_H_

#include <ndspi.h>


#ifdef __cplusplus
extern "C"
{
#endif  // __cplusplus

#define ND_HELPER_API  __stdcall


//
// Initialization
//
HRESULT ND_HELPER_API
NdStartup(
    VOID
    );

HRESULT ND_HELPER_API
NdCleanup(
    VOID
    );

VOID ND_HELPER_API
NdFlushProviders(
    VOID
    );

//
// Network capabilities
//
#define ND_QUERY_EXCLUDE_EMULATOR_ADDRESSES

HRESULT ND_HELPER_API
NdQueryAddressList(
    __in DWORD Flags,
    __out_bcount_part_opt(*pBufferSize, *pBufferSize) SOCKET_ADDRESS_LIST* pAddressList,
    __inout SIZE_T* pBufferSize
    );


HRESULT ND_HELPER_API
NdResolveAddress(
    __in_bcount(RemoteAddressLength) const struct sockaddr* pRemoteAddress,
    __in SIZE_T RemoteAddressLength,
    __out_bcount(LocalAddressLength) struct sockaddr* pLocalAddress,
    __inout SIZE_T* pLocalAddressLength
    );


HRESULT ND_HELPER_API
NdCheckAddress(
    __in_bcount(AddressLength) const struct sockaddr* pAddress,
    __in SIZE_T AddressLength
    );


HRESULT ND_HELPER_API
NdOpenIAdapter(
    __in_bcount(AddressLength) const struct sockaddr* pAddress,
    __in SIZE_T AddressLength,
    __deref_out INDAdapter** ppIAdapter
    );

#ifdef __cplusplus
}
#endif  // __cplusplus


#endif // _NETDIRECT_H_
