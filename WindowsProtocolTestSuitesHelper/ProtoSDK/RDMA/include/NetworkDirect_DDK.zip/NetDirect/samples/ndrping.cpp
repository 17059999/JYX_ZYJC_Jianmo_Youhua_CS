// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndrping.cpp - Network Direct unidirectional RDMA ping test
//
// For this test, the server side simply allocates a buffer and
// advertises it to the client.  The client then performs RDMA
// operations to its heart's content with no further involvement
// of the server.
//

#include "precomp.h"

const SIZE_T x_MaxXfer = (4 * 1024 * 1024);
const SIZE_T x_HdrLen = 40;
const SIZE_T x_MaxVolume = (500 * x_MaxXfer);
const SIZE_T x_MaxIterations = 500000;

#define RECV    0
#define SEND    1
#define BIND    2
#define RDMA    2

void ShowUsage()
{
    printf( "ndrping s|c <ip> <port> b|p<nSge> [r] [q<pipeline>] [l<log>]\n"
        "\ts - start as server (listen on IP/Port)\n"
        "\tc - start as client (connect to server IP/Port)\n"
        "\t<ip> - IPv4 Address\n"
        "\t<port> - Port number\n"
        "\tb - client only: blocking I/O (wait for CQ notification)\n"
        "\tp - client only: polling I/O (Poll on the CQ)\n"
        "\t<nSge> - client only: Number of scatter/gather entries per transfer.\n"
        "\tq - client only: pipeline limit of <pipeline> requests\n"
        "\tr - client only: Use RDMA Read (RDMA Write by default)\n"
        "\tl - log output to a file named <log>.\n");
}

DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}

LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}

LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}

void Server(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port )
{
    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    INDAdapter* pAdapter;
    HRESULT hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        printf( "Failed to allocate data buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDMemoryWindow* pMw;
    ND_RESULT InvalidateResult;
    hr = pAdapter->CreateMemoryWindow( &InvalidateResult, &pMw );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateMemoryWindow failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Listen and get incoming connection request.
    //
    INDListen* pListen;
    hr = pAdapter->Listen( 0, 234, Port, NULL, &pListen );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Listen failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x", hr );
        exit( __LINE__ );
    }

    hr = pListen->GetConnectionRequest( pConnector, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDListen::GetConnectionRequest failed with %08x\n", hr );
        exit( __LINE__ );
    }

    SIZE_T InboundReadLimit;
    hr = pConnector->GetConnectionData( NULL, &InboundReadLimit, NULL, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::GetConnectionData failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Create a CQ for two entries - the send we issue to advertise
    // the memory window, and a receive to detect test completion.
    //
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( 4, &pCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        2,
        2, // Need to be able to issue bind and send at the same time.
        1,
        1,
        min(InboundReadLimit, Info.MaxInboundReadLimit),
        0,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT Results[BIND + 1];

    //
    // Pre-post the receive request.
    //
    hr = pEndpoint->Receive( &Results[RECV], NULL, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Accept the connection.
    //
    hr = pConnector->Accept(
        pEndpoint,
        NULL,
        0,
        pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDListen::Accept failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Server always uses blocking mode, since RDMA operations are one-sided.
    //
    // Client must issue the first transfer (iWARP rule).  Wait for a receive.
    //
    hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT* pResult;
    SIZE_T nResults = pCq->GetResults( &pResult, 1 );
    if( nResults != 1 )
    {
        printf( "INDCompletionQueue::GetResults returned no result.\n" );
        exit( __LINE__ );
    }
    if( pResult != &Results[RECV] )
    {
        printf( "INDCompletionQueue::GetResults returned unexpected result.\n" );
        exit( __LINE__ );
    }

    //
    // Repost the receive.
    //
    hr = pEndpoint->Receive( &Results[RECV], 0, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Bind the MW.
    //
    hr = pEndpoint->Bind(
        &Results[BIND],
        hMr,
        pMw,
        pBuf,
        x_MaxXfer + x_HdrLen,
        ND_OP_FLAG_ALLOW_READ | ND_OP_FLAG_ALLOW_WRITE,
        (ND_MW_DESCRIPTOR*)pBuf );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Bind failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_SGE Sgl;
    Sgl.pAddr = pBuf;
    Sgl.Length = sizeof(ND_MW_DESCRIPTOR);
    Sgl.hMr = hMr;

    //
    // Send the MW descriptor.
    //
    hr = pEndpoint->Send( &Results[SEND], &Sgl, 1, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Wait for next receive completion that indicates test completion.
    //
    do
    {
        hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
        if( hr == ND_PENDING )
        {
            SIZE_T BytesRet;
            hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
        }
        if( FAILED( hr ) )
        {
            printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
            exit( __LINE__ );
        }

        for( ;; )
        {
            nResults = pCq->GetResults( &pResult, 1 );
            if( nResults == 0 )
                break;

            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                //
                // Ignore send completions
                //
                if( pResult != &Results[RECV] )
                    break;

                //
                // We want to break out of the while loop...
                //
                hr = ND_CANCELED;
                break;

            case ND_CANCELED:
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }

        }

    } while( hr == ND_SUCCESS );

    //
    // Invalidate the MW.
    //
    hr = pEndpoint->Invalidate( &Results[BIND], pMw, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Invalidate failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Wait for completion.  For simplicity, just do a polling loop.
    //
    do
    {
        nResults = pCq->GetResults( &pResult, 1 );

    } while( nResults == 0 );

    if( FAILED( pResult->Status ) )
    {
        printf( "INDEndpoint::Invalidate failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    pMw->Release();

    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDEndpoint::Disconnect failed wtih %08x\n", hr );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    pListen->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );

    pAdapter->Release();

    HeapFree( GetProcessHeap(), 0, pBuf );
}

HRESULT Ping(
    __in INDEndpoint* pEndpoint,
    __in INDCompletionQueue* pCq,
    __in OVERLAPPED* pOv,
    __in ND_RESULT* Results,
    __in const ND_SGE* Sgl,
    __in const SIZE_T nSge,
    __in const ND_MW_DESCRIPTOR* pMwDescriptor,
    __in const SIZE_T QueueDepth,
    __in SIZE_T nPipeline,
    __in SIZE_T Iterations,
    __in bool bRead,
    __in bool bUseEvents )
{
    //
    // We'll blast QueueDepth requests out, make sure we don't overrun
    // either the local or remote endpoint.
    //
    SIZE_T nPosted;

    if( nPipeline > Iterations )
        nPipeline = Iterations;
    if( nPipeline > QueueDepth )
        nPipeline = QueueDepth;

    //
    // First we post up to our limit (either Credits or QueueDepth).
    //
    SIZE_T i;
    for( i = 0; i < nPipeline; i++ )
    {
        //
        // Post RDMA.
        //
        HRESULT hr;
        if( bRead )
            hr = pEndpoint->Read( &Results[i], Sgl, nSge, pMwDescriptor, 0, 0 );
        else
            hr = pEndpoint->Write( &Results[i], Sgl, nSge, pMwDescriptor, 0, 0 );

        if( FAILED( hr ) )
        {
            printf( "%s failed with %08x\n", bRead?"INDEndpoint::Read":"INDEndpoint::Write", hr );
            exit( __LINE__ );
        }
    }

    nPosted = i;
    Iterations -= i;

    //
    // Now that things are under way, poll/post as needed.
    //
    HRESULT hr = ND_SUCCESS;
    do
    {
        if( bUseEvents )
        {
            hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( hr == ND_PENDING )
            {
                SIZE_T BytesRet;
                hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
            }
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
        }

        SIZE_T nResults;
        ND_RESULT* pResult;
        while( (nResults = pCq->GetResults( &pResult, 1 )) != 0 )
        {
            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                if( Iterations )
                {
                    //
                    // Repost the Ping.
                    //
                    if( bRead )
                    {
                        hr = pEndpoint->Read(
                            pResult,
                            Sgl,
                            nSge,
                            pMwDescriptor,
                            0,
                            0 );
                    }
                    else
                    {
                        hr = pEndpoint->Write(
                            pResult,
                            Sgl,
                            nSge,
                            pMwDescriptor,
                            0,
                            0 );
                    }

                    if( FAILED( hr ) )
                    {
                        printf( "%s failed with %08x\n",
                            bRead?"INDEndpoint::Read":"INDEndpoint::Write",
                            hr );
                        exit( __LINE__ );
                    }

                    Iterations--;
                }
                else
                {
                    nPosted--;
                }
                break;

            case ND_CANCELED:
                Iterations = 0;
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }

        }// while( nResults != 0 );

    } while( Iterations != 0 || nPosted != 0 );

    return hr;
}

void Client(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in bool bRead,
    __in bool bUseEvents,
    __in SIZE_T nPipeline )
{
    struct sockaddr_in v4 = {0};
    struct sockaddr_in LocalAddr;

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) )
    {
        printf( "NdResolveAddress failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        printf( "Failed to allocate data buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        printf( "Failed to allocate SGL.\n" );
        exit( __LINE__ );
    }

    //
    // Create a CQ.
    //
    SIZE_T QueueDepth = min( Info.MaxCqEntries, Info.MaxInboundRequests ) - 1;
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( QueueDepth + 1, &pCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x", hr );
        exit( __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        1,
        QueueDepth,
        1,
        nSge,
        0,
        Info.MaxOutboundReadLimit,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[QueueDepth + 1];
    if( Results == NULL )
    {
        printf( "Failed to allocate ND_RESULT array.\n" );
        exit( __LINE__ );
    }

    //
    // Pre-post receive request for the MW descriptor.
    //
    Sgl[0].pAddr = pBuf;
    Sgl[0].Length = sizeof(ND_MW_DESCRIPTOR);
    Sgl[0].hMr = hMr;
    hr = pEndpoint->Receive( &Results[QueueDepth], Sgl, 1 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Receive failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Connect to the server.
    //
    hr = pConnector->Connect(
        pEndpoint,
        (const struct sockaddr*)&v4,
        sizeof(v4),
        234,
        0,
        NULL,
        0,
        pOv
        );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::Connect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Get the remote peer's inbound read limit (what we will use
    // as outbound read limit).
    //
    SIZE_T OutboundReadLimit = 0;
    hr = pConnector->GetConnectionData(
        &OutboundReadLimit,
        NULL,
        NULL,
        0 );
    if( FAILED( hr ) && hr != ND_BUFFER_OVERFLOW )
    {
        printf( "NdGetCallerData failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Complete the connection - this transitions the endpoint so it can send.
    //
    hr = pConnector->CompleteConnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::CompleteConnect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Now for MW descriptor exchange.  We issue a zero-byte send, to which
    // the server will respond with the MW descriptor.
    //
    hr = pEndpoint->Send( &Results[0], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT *pResult;
    ND_MW_DESCRIPTOR MwDescriptor;
    SIZE_T nPosted = 2;
    do
    {
        SIZE_T nResults = pCq->GetResults( &pResult, 1 );
        if( !nResults )
            continue;

        if( FAILED( pResult->Status ) )
        {
            printf( "Result %p (Results array at %p), failed with %08x\n",
                pResult, Results, pResult->Status );
            exit( __LINE__ );
        }

        if( pResult == &Results[QueueDepth] )
        {
            //
            // Receive completion - copy the MW descriptor.
            //
            MwDescriptor = *(ND_MW_DESCRIPTOR*)pBuf;
        }
        else if( pResult == &Results[0] )
        {
            //
            // Ping completion - do nothing.
            //
            NULL;
        }
        else
        {
            printf( "Unexpected result completion: %p (Results array at %p)\n",
                pResult, Results );
            exit( __LINE__ );
        }

        nPosted--;

    } while( nPosted );

    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    printf( "Using %d processors. Sender Frequency is %I64d\n",
        GetProcessorCount(),
        Frequency.QuadPart );

    //
    // Warm up run, transfer only header.
    //
    Sgl[0].Length = x_HdrLen;
    hr = Ping(
        pEndpoint,
        pCq,
        pOv,
        Results,
        Sgl,
        1,
        &MwDescriptor,
        QueueDepth,
        nPipeline,
        1000,
        bRead,
        false );
    if( FAILED( hr ) )
    {
        printf( "Connection unexpectedly aborted.\n" );
        exit( __LINE__ );
    }

    Sleep(1000);

    for( SIZE_T szXfer = 1; szXfer <= x_MaxXfer; szXfer <<= 1 )
    {

        for( SIZE_T i = 0; i < nSge; i++ )
        {
            Sgl[i].pAddr = pBuf + (x_HdrLen * i);
            Sgl[i].Length = x_HdrLen;
            Sgl[i].hMr = hMr;
        }

        // Last SGE has the remainder of the data.
        Sgl[nSge - 1].Length = x_HdrLen + szXfer - (x_HdrLen * (nSge - 1));

        SIZE_T Iterations = x_MaxIterations;
        if( (Iterations * szXfer) > x_MaxVolume )
            Iterations = x_MaxVolume / szXfer;

        LONGLONG cpuStart = GetCPUTime();
        LONGLONG tStart = GetElapsedTime();

        hr = Ping(
            pEndpoint,
            pCq,
            pOv,
            Results,
            Sgl,
            nSge,
            &MwDescriptor,
            QueueDepth,
            nPipeline,
            Iterations,
            bRead,
            bUseEvents );
        if( FAILED( hr ) )
        {
            printf( "Connection unexpectedly aborted.\n" );
            exit( __LINE__ );
        }
        LONGLONG tEnd = GetElapsedTime();
        LONGLONG cpuEnd = GetCPUTime();

        LONGLONG ElapsedNanoSec = (tEnd - tStart) / Iterations * 1000000000I64 / Frequency.QuadPart;
        LONGLONG CpuNanoSec = ((cpuEnd - cpuStart) * 100I64 / Iterations);
        LONGLONG BytesSec = szXfer * 1000000000I64 / ElapsedNanoSec;

        double elapsed = (double) ElapsedNanoSec / 1000.0;
        double cpu = (double) CpuNanoSec / (double) ElapsedNanoSec * 100.0;
        printf(" %9Id %9Id %9.2f %7.2f %11I64d\n", szXfer, Iterations, elapsed, cpu, BytesSec);
    }

    //
    // Now send a zero-byte message to indicate to the server that
    // the test is over.
    //
    hr = pEndpoint->Send( &Results[0], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        printf( "INDEndpoint::Send failed with %08x\n", hr );
        exit( __LINE__ );
    }

    nPosted = 1;
    do
    {
        SIZE_T nResults = pCq->GetResults( &pResult, 1 );
        if( !nResults )
            continue;

        if( FAILED( pResult->Status ) )
        {
            printf( "Result %p (Results array at %p), failed with %08x\n",
                pResult, Results, pResult->Status );
            exit( __LINE__ );
        }
        else if( pResult == &Results[0] )
        {
            //
            // Ping completion - do nothing.
            //
            NULL;
        }
        else
        {
            printf( "Unexpected result completion: %p (Results array at %p)\n",
                pResult, Results );
            exit( __LINE__ );
        }

        nPosted--;

    } while( nPosted );

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDEndpoint::Disconnect failed wtih %08x\n", hr );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


int __cdecl main(int argc, char* argv[])
{
    bool bServer = false;
    bool bClient = false;
    ULONG Address = 0;
    USHORT Port = 0;
    SIZE_T nSge = 0;
    bool bPolling = false;
    bool bBlocking = false;
    SIZE_T nPipeline = 128;
    bool bRead = false;

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 's':
        case 'S':
            bServer = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'c':
        case 'C':
            bClient = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'p':
        case 'P':
            bPolling = true;
            nSge = atol( ++pArg );
            break;
        case 'b':
        case 'B':
            bBlocking = true;
            nSge = atol( ++pArg );
            break;
        case 'q':
        case 'Q':
            nPipeline = atol( ++pArg );
            break;
        case 'r':
        case 'R':
            bRead = true;
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( (bClient && bServer) || (!bClient && !bServer) )
    {
        printf( "Exactly one of client (c or "
            "server (s) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( Port == 0 )
    {
        printf( "Bad port.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( bClient )
    {
        if( ((bPolling && bBlocking) || (!bPolling && !bBlocking)) )
        {
            printf( "Exactly one of blocking (b or "
                "polling (p) must be specified.\n" );
            ShowUsage();
            exit( __LINE__ );
        }

        if( nSge == 0 )
        {
            printf( "Invalid or missing SGE, expected positive integer after p or b.\n" );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    OVERLAPPED Ov;
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        printf( "Failed to allocate event for overlapped operations.\n" );
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    if( bServer )
        Server( &Ov, Address, Port );
    else
        Client( &Ov, Address, Port, nSge, bRead, bBlocking, nPipeline );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    CloseHandle( Ov.hEvent );

    _fcloseall();

    return 0;
}

