// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndmw.cpp - Network Direct memory window test
//
// This test establishes a connection, binds a memory window to a large
// (64MB) buffer, and performs RDMA operations on the memory window
// checking buffer contents, at various offset in the advertised region.
//
// Client operation:
//  1. Establish connection
//  2. Bind memory window
//  3. Format upper 32MB of buffer
//  4. Send 1024 bytes of buffer at 32MB offset and MW descriptor
//  5. Wait for receive
//  7. Validate buffer contents - lower 32MB should be bitwise NOT of upper 32MB.
//  8. Send 0 byte message to start second test.
//  9. Wait for receive
//  10. Validate buffer contents - lower 32MB should be reverse order (in 4-byte
//     chunks) of upper 32MB.
//  11. Disconnect
//
// Server operation:
//  1. Establish connection
//  2. Receive MW descriptor and 1024 bytes of data.
//  3. RDMA Read at offset 32MB for 1024 bytes.
//  4. Check that 1024 bytes received match 1024 bytes read.
//  5. RDMA Read at offset 32MB + 1024 bytes for 32MB - 1024 bytes.
//  6. Reverse all byte values in upper 32 MB.
//  7. Write to offset 16MB buffer contents from 48-64 MB
//  8. Write to offset 0 buffer contents from 32-48 MB
//  9. Send 0-byte message indicating first test complete.
//  10. Wait for receive.
//  11. RDMA write 4 bytes at a time, writing bottom up to offset 32MB-64MB
//      from from 64MB-32MB (yes, lots of writes).
//  12. Send 0-byte message indicating second test complete.
//  13. Disconnect

#include "precomp.h"
#include <logging.h>

struct PRIVATE_DATA
{
    UINT8 Key[36];
};

const PRIVATE_DATA x_DefaultData = {
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
    17,
    18,
    19,
    20,
    21,
    22,
    23,
    24,
    25,
    26,
    30,
    31,
    32,
    33,
    34,
    35
};

const SIZE_T x_MaxXfer = (64 * 1024 * 1024);
const SIZE_T x_PiggyBackXfer = 1024;

const SIZE_T x_ReadBase = (32 * 1024 * 1024);
const SIZE_T x_BigChunkSize = (16 * 1024 * 1024);
const SIZE_T x_SmallChunkSize = 4;

const LPWSTR TESTNAME = L"ndmw.exe";

enum NdResultIndex
{
    Recv,
    Send,
    Read,
    MwBind = Read,
    Write,
    MwInvalidate = Write,
    ResultCount
};


void ShowUsage()
{
    printf( "ndmw s|c <ip> <port> [l<log>]\n"
        "\ts - start as server (listen on IP/Port)\n"
        "\tc - start as client (connect to server IP/Port)\n"
        "\t<ip> - IPv4 Address\n"
        "\t<port> - Port number\n"
        "\tl - log output to a file named <log>.\n");
}

DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}

LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}

LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}

void WaitForCompletion( INDCompletionQueue* pCq, OVERLAPPED* pOv, ND_RESULT** ppResult, int line )
{
    HRESULT hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDCompletionQueue::Notify failed with %08x", line );
    }

    pCq->GetResults( ppResult, 1 );
}

void Server(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port
    )
{
    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    INDAdapter *pAdapter;
    HRESULT hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &pAdapter );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdOpenIAdapter failed with %08x", __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Query failed with %08x", __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer );
    if( !pBuf ) 
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate data buffer.", __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::RegisterMemory failed with %08x", __LINE__ );
    }

    //
    // Listen and get incoming connection request.
    //
    INDListen *pListen;
    hr = pAdapter->Listen( 0, 234, Port, NULL, &pListen );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Listen failed with %08x", __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    printf( "Waiting for connection.\n" );
    hr = pListen->GetConnectionRequest( pConnector, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDListen::GetConnectionRequest failed with %08x", __LINE__ );
    }

    SIZE_T Ird;
    SIZE_T Ord;
    PRIVATE_DATA PrivateData;
    Len = sizeof(PrivateData);
    hr = pConnector->GetConnectionData( &Ird, &Ord, &PrivateData, &Len );
    if( FAILED( hr ) && hr != ND_BUFFER_OVERFLOW )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::GetConnectionData failed with %08x", __LINE__ );
    }

    if( Len < sizeof(PrivateData) )
    {
        LOG_FAILURE_AND_EXIT(
            L"INDConnector::GetConnectionData failed to return expected private data.",
            __LINE__
            );
    }

    if( memcmp( &PrivateData, &x_DefaultData, sizeof(PrivateData) ) )
    {
        LOG_FAILURE_AND_EXIT( L"PrivateData not as expected.", __LINE__ );
    }

    //
    // Create a CQ.
    //
    INDCompletionQueue *pCq;
    hr = pAdapter->CreateCompletionQueue( 2, &pCq );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateCompletionQueue failed with %08x", __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        1,
        1,
        1,
        1,
        Ird,
        Ord,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CreateEndpoint failed with %08x", __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[ResultCount];
    if( Results == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate ND_RESULT array.", __LINE__ );
    }

    //
    // Pre-post receive request.
    //
    ND_SGE Sge;
    Sge.pAddr = pBuf;
    Sge.Length = x_PiggyBackXfer + sizeof(ND_MW_DESCRIPTOR);
    Sge.hMr = hMr;
    hr = pEndpoint->Receive( &Results[Recv], &Sge, 1 );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
    }

    //
    // Accept the connection, notifying the caller of our queue depth.
    // Note that we send the queue depth in host order (little endian)
    // so that we don't have to worry about 32/64 bit SIZE_T issues.
    // The lower bytes will always be transferred first.
    //
    hr = pConnector->Accept(
        pEndpoint,
        &PrivateData,
        sizeof(PrivateData),
        pOv );

    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::Accept failed with %08x", __LINE__ );
    }

    printf( "Connected.\n" );

    //
    // Test 1.
    //
    ND_RESULT* pResult;

    printf( "Phase 1: Large read/write test with data validation.\n" );

    //
    // Wait for receive completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Recv] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Recv.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != x_PiggyBackXfer + sizeof(ND_MW_DESCRIPTOR) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Received %d bytes, expected 1044",
            __LINE__
            );
    }

    ND_MW_DESCRIPTOR Desc = *(ND_MW_DESCRIPTOR*)(pBuf + x_PiggyBackXfer);

    //
    // Issue RDMA Read for the first KB.
    //
    Sge.pAddr = pBuf + x_ReadBase;
    Sge.Length = x_PiggyBackXfer;
    hr = pEndpoint->Read( &Results[Read], &Sge, 1, &Desc, x_ReadBase, 0 );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Read failed with %08x", __LINE__ );
    }

    //
    // Wait for read completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Read] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Read.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Read failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != Sge.Length )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Read %d bytes, expected 1024",
            __LINE__
            );
    }

    //
    // Compare the 1KB we read with the 1KB we received.
    //
    if( memcmp( pBuf, pBuf + x_ReadBase, x_PiggyBackXfer ) != 0 )
    {
        LOG_FAILURE_AND_EXIT( L"Recv/Read buffer mismatch.", __LINE__ );
    }

    //
    // Read the rest of the 32MB.
    //
    Sge.pAddr = pBuf + x_ReadBase + x_PiggyBackXfer;
    Sge.Length = x_ReadBase - x_PiggyBackXfer;
    hr = pEndpoint->Read( &Results[Read], &Sge, 1, &Desc, x_ReadBase + x_PiggyBackXfer, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Read failed with %08x", __LINE__ );
    }

    //
    // Wait for read completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Read] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Read.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Read failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != Sge.Length )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Read %d bytes, expected 33553408",
            __LINE__
            );
    }

    //
    // Reverse all byte values in upper 32 MB.
    //
    for( SIZE_T i = x_ReadBase; i < x_MaxXfer; i++ )
    {
        pBuf[i] = ~pBuf[i];
    }

    //
    // Write the upper 16MB of the lower 32MB at the target.
    //
    Sge.pAddr = pBuf + x_ReadBase + x_BigChunkSize;
    Sge.Length = x_BigChunkSize;
    hr = pEndpoint->Write( &Results[Write], &Sge, 1, &Desc, x_BigChunkSize, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Write failed with %08x", __LINE__ );
    }

    //
    // Wait for write completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Write] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Write.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Write failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != Sge.Length )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Wrote %d bytes, expected 16777216",
            __LINE__
            );
    }

    //
    // Write the lower 16MB at the target.
    //
    Sge.pAddr = pBuf + x_ReadBase;
    Sge.Length = x_BigChunkSize;
    hr = pEndpoint->Write( &Results[Write], &Sge, 1, &Desc, 0, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Write failed with %08x", __LINE__ );
    }

    //
    // Wait for write completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Write] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Write.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Write failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != Sge.Length )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Wrote %d bytes, expected 16777216",
            __LINE__
            );
    }

    //
    // Post 0 byte receive to get test 2 start indication.
    //
    hr = pEndpoint->Receive( &Results[Recv], NULL, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    //
    // Send 0 byte message to indicate test 1 complete.
    //
    hr = pEndpoint->Send( &Results[Send], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    //
    // Wait for send completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Send] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Send.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Sent %d bytes, expected 0",
            __LINE__
            );
    }

    //
    // Wait for receive completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Recv] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Recv.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Received %d bytes, expected 0",
            __LINE__
            );
    }

    printf( "Phase 2: Small write test with data validation.\n" );

    //
    // Write 4-byte chunks, reversing the order of the chunks.
    //
    for( SIZE_T i = 0; i < x_ReadBase; i += x_SmallChunkSize )
    {
        //
        // Write the 4-byte chunk.
        //
        Sge.pAddr = pBuf + x_ReadBase + i;
        Sge.Length = x_SmallChunkSize;
        hr = pEndpoint->Write(
            &Results[Write],
            &Sge,
            1,
            &Desc,
            x_MaxXfer - x_SmallChunkSize - i,
            0
            );
        if( FAILED( hr ) )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Write failed with %08x", __LINE__ );
        }

        if( i % (x_ReadBase / 100) == 0 )
        {
            printf( "%d%%\r", i / (x_ReadBase / 100) );
        }

        SIZE_T nResults;
        do
        {
            //
            // Wait for write completion.
            //
            nResults = pCq->GetResults( &pResult, 1 );

        } while( nResults == 0 );

        if( pResult != &Results[Write] )
        {
            LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Write.", __LINE__ );
        }

        if( pResult->Status != ND_SUCCESS )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( pResult->Status, L"INDEndpoint::Write failed with %08x", __LINE__ );
        }

        if( pResult->BytesTransferred != Sge.Length )
        {
            LOG_FAILURE_HRESULT_AND_EXIT(
                (LONG)pResult->BytesTransferred,
                L"Wrote %d bytes, expected 16777216",
                __LINE__
                );
        }
    }

    //
    // Post 0 byte receive to get notification that we can disconnect.
    //
    hr = pEndpoint->Receive( &Results[Recv], NULL, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    //
    // Send 0 byte message to indicate test 2 complete.
    //
    hr = pEndpoint->Send( &Results[Send], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    //
    // Wait for send completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Send] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Send.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Sent %d bytes, expected 0",
            __LINE__
            );
    }

    //
    // Wait for receive completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Recv] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Recv.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Received %d bytes, expected 0",
            __LINE__
            );
    }

    printf( "Test complete\n" );
    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }

    if( FAILED( hr ) )  
        LOG_FAILURE_HRESULT( hr, L"INDEndpoint::Disconnect failed with %08x", __LINE__ );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();
    pListen->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        LOG_FAILURE_HRESULT( hr, L"INDAdapter::DeregisterMemory failed with %08x", __LINE__ );

    pAdapter->Release();

    delete[] Results;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


void Client(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port
    )
{
    struct sockaddr_in v4 = {0};
    struct sockaddr_in LocalAddr;

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdResolveAddress failed with %08x", __LINE__ );
    }

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &pAdapter );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdOpenIAdapter failed with %08x", __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::Query failed with %08x", __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer );
    if( !pBuf )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate data buffer.", __LINE__ );
    }

    //
    // Format the buffer.
    //
    for( SIZE_T i = x_ReadBase; i < x_MaxXfer; i++ )
    {
        pBuf[i] = (char)i;
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::RegisterMemory failed with %08x",__LINE__ );
    }

    //
    // Create a CQ.
    //
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( 2, &pCq );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateCompletionQueue failed with %08x", __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateConnector failed with %08x", __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        1,
        1,
        1,
        1,
        1,
        1,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) ) 
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::CreateEndpoint failed with %08x", __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[ResultCount];
    if( Results == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate ND_RESULT array.", __LINE__ );
    }

    //
    // Pre-post receive request for detecting test completion.
    //
    hr = pEndpoint->Receive( &Results[Recv], NULL, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Receive failed with %08x", __LINE__ );
    }

    //
    // Connect to the server.
    //
    printf( "Connecting...\r" );
    hr = pConnector->Connect(
        pEndpoint,
        (const struct sockaddr*)&v4,
        sizeof(v4),
        234,
        0,
        &x_DefaultData,
        sizeof(x_DefaultData),
        pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Connect failed with %08x", __LINE__ );
    }

    PRIVATE_DATA PrivateData;
    Len = sizeof(PrivateData);
    hr = pConnector->GetConnectionData(
        NULL,
        NULL,
        &PrivateData,
        &Len );
    if( FAILED( hr ) && hr != ND_BUFFER_OVERFLOW )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDConnector::GetCalleeData failed with %08x", __LINE__ );
    }

    if( Len < sizeof(PrivateData) )
    {
        LOG_FAILURE_AND_EXIT(
            L"INDConnector::GetConnectionData failed to return expected private data.",
            __LINE__
            );
    }

    if( memcmp( &PrivateData, &x_DefaultData, sizeof(PrivateData) ) )
    {
        LOG_FAILURE_AND_EXIT( L"PrivateData not as expected.", __LINE__ );
    }

    //
    // Complete the connection - this transitions the endpoint so it can send.
    //
    hr = pConnector->CompleteConnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::CompleteConnect failed with %08x", __LINE__ );
    }

    printf( "Connected.     \n" );

    INDMemoryWindow* pMw;
    hr = pAdapter->CreateMemoryWindow( &Results[MwInvalidate], &pMw );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDAdapter::CreateMemoryWindow failed with %08x", __LINE__ );
    }

    ND_MW_DESCRIPTOR* pDesc = (ND_MW_DESCRIPTOR*)pBuf;
    hr = pEndpoint->Bind(
        &Results[MwBind],
        hMr,
        pMw,
        pBuf,
        x_MaxXfer,
        ND_OP_FLAG_ALLOW_READ | ND_OP_FLAG_ALLOW_WRITE,
        pDesc
        );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Bind failed with %08x", __LINE__ );
    }

    if( pDesc->Length != _byteswap_uint64( x_MaxXfer ) )
    {
        LOG_FAILURE_AND_EXIT( L"INDEndpoint::Bind returned invalid length in ND_MW_DESCRIPTOR", __LINE__ );
    }

    ND_RESULT* pResult;
    //
    // Wait for bind completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[MwBind] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Bind.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Bind failed with %08x", __LINE__ );
    }

    ND_SGE Sgl[2];
    Sgl[0].pAddr = pBuf + x_ReadBase;
    Sgl[0].Length = x_PiggyBackXfer;
    Sgl[0].hMr = hMr;
    Sgl[1].pAddr = pBuf;
    Sgl[1].Length = sizeof(ND_MW_DESCRIPTOR);
    Sgl[1].hMr = hMr;
    hr = pEndpoint->Send( &Results[Send], Sgl, 2, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    //
    // Wait for send completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Send] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Send.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != x_PiggyBackXfer + sizeof(ND_MW_DESCRIPTOR) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Sent %d bytes, expected 1044",
            __LINE__
            );
    }

    //
    // Wait for the receive.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Recv] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Recv.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Received %d bytes, expected 0",
            __LINE__
            );
    }

    //
    // Post 0 byte receive to get test 2 complete indication.
    //
    hr = pEndpoint->Receive( &Results[Recv], NULL, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    //
    // Validate the buffer.
    //
    for( SIZE_T i = 0; i < x_ReadBase; i++ )
    {
        if( pBuf[i] != ~pBuf[i + x_ReadBase] )
        {
            LOG_FAILURE_HRESULT_AND_EXIT( (LONG)i, L"Buffer validation failed at index %d", __LINE__ );
        }
    }

    printf( "Phase 1: complete\n" );

    //
    // Start second test.
    //
    hr = pEndpoint->Send( &Results[Send], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    //
    // Wait for send completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Send] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Send.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Sent %d bytes, expected 0",
            __LINE__
            );
    }

    //
    // Wait for the receive.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Recv] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Recv.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Recv failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Received %d bytes, expected 0",
            __LINE__
            );
    }

    //
    // Validate buffer again.
    //
    UINT32* pLow = (UINT32*)pBuf;
    UINT32* pHigh = ((UINT32*)(pBuf + x_MaxXfer)) - 1;

    while( pLow < pHigh )
    {
        if( *pLow != *pHigh )
        {
            LOG_FAILURE_HRESULT_AND_EXIT(
                (LONG)((ULONG_PTR)pLow - (ULONG_PTR)pBuf) / sizeof(UINT32),
                L"Buffer validation failed at index %d",
                __LINE__
                );
        }
        pLow++;
        pHigh--;
    }

    printf( "Phase 2: complete\n" );

    //
    // Invalidate the MW.
    //
    hr = pEndpoint->Invalidate( &Results[MwBind], pMw, 0 );
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[MwBind] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected invalidate.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Invalidate failed with %08x", __LINE__ );
    }

    //
    // Send 0 byte message to indicate test 2 complete.
    //
    hr = pEndpoint->Send( &Results[Send], NULL, 0, 0 );
    if( FAILED( hr ) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    //
    // Wait for send completion.
    //
    WaitForCompletion( pCq, pOv, &pResult, __LINE__ );
    if( pResult != &Results[Send] )
    {
        LOG_FAILURE_AND_EXIT( L"Unexpected completion - expected Send.", __LINE__ );
    }

    if( pResult->Status != ND_SUCCESS )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"INDEndpoint::Send failed with %08x", __LINE__ );
    }

    if( pResult->BytesTransferred != 0 )
    {
        LOG_FAILURE_HRESULT_AND_EXIT(
            (LONG)pResult->BytesTransferred,
            L"Sent %d bytes, expected 0",
            __LINE__
            );
    }

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        LOG_FAILURE_HRESULT( hr, L"INDEndpoint::Disconnect failed wtih %08x", __LINE__ );

    pMw->Release();
    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) ) 
        LOG_FAILURE_HRESULT( hr, L"INDAdapter::DeregisterMemory failed with %08x", __LINE__ );

    pAdapter->Release();

    delete[] Results;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


int __cdecl main(int argc, char* argv[])
{
    bool bServer = false;
    bool bClient = false;
    ULONG Address = 0;
    USHORT Port = 0;

    INIT_LOG( TESTNAME );

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 's':
        case 'S':
            bServer = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'c':
        case 'C':
            bClient = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( (bClient && bServer) || (!bClient && !bServer) )
    {
        printf( "Exactly one of client (c or "
            "server (s) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( Port == 0 )
    {
        printf( "Bad port.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    OVERLAPPED Ov;
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        LOG_FAILURE_AND_EXIT( L"Failed to allocate event for overlapped operations.", __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdStartup failed with %08x", __LINE__ );
    }

    LONGLONG tStart = GetElapsedTime();
    if( bServer )
        Server( &Ov, Address, Port );
    else
        Client( &Ov, Address, Port );
    LONGLONG tEnd = GetElapsedTime();

    LARGE_INTEGER Freq;
    QueryPerformanceFrequency( &Freq );

    printf( "Elapsed time %f seconds\n", (double)(tEnd - tStart)/Freq.QuadPart );
    hr = NdCleanup();
    if( FAILED(hr) )
    {
        LOG_FAILURE_HRESULT_AND_EXIT( hr, L"NdCleanup failed with %08x", __LINE__ );
    }

    CloseHandle( Ov.hEvent );

    END_LOG( TESTNAME );

    _fcloseall();

    return 0;
}

