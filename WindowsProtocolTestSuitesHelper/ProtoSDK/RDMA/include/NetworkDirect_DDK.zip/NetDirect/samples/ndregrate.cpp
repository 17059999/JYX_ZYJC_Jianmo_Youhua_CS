// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndmrlat.cpp - Network Direct memory registration bandwidth test
//

#include "precomp.h"


const SIZE_T x_MaxSize = (4 * 1024 * 1024);
char x_Buf[x_MaxSize] = {0};
const LONG x_MaxReg = 2000;

struct MR_CONTEXT
{
    OVERLAPPED Ov;
    ND_MR_HANDLE hMr;
};

MR_CONTEXT g_MrContext[x_MaxReg] = {0};

INDAdapter* g_pAdapter = NULL;
HANDLE g_hIocp = NULL;
HANDLE g_hEvent = NULL;

volatile LONG g_nReg = 0;
volatile LONG g_nMr = 0;

//
// Registers buffers of increasing size 10000 times using multiple threads.
//


void ShowUsage()
{
    printf( "ndregrate <ip> t<threads> [l<log>]\n"
        "\t<ip> - IPv4 Address\n"
        "\tt - number of threads\n"
        "\tl - log output to a file named <log>.\n");
}


inline DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}


inline LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}


inline LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}


inline LONGLONG GetFrequency()
{
    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    return Frequency.QuadPart;
}


DWORD WINAPI TestRoutine( __in LPVOID Nothing )
{
    UNREFERENCED_PARAMETER( Nothing );

    LONGLONG Frequency = GetFrequency();

    for( SIZE_T szXfer = 1; szXfer <= x_MaxSize; szXfer <<= 1 )
    {
        bool Register = true;
        g_nMr = 0;
        g_nReg = 0;

        LONGLONG tMiddle = 0;
        LONGLONG cpuMiddle = 0;

        LONGLONG tStart = GetElapsedTime();
        LONGLONG cpuStart = GetCPUTime();
        while( g_nMr != x_MaxReg )
        {
            while( g_nReg != x_MaxReg )
            {
                //
                // Register
                //
                LONG iReg = InterlockedIncrement( &g_nReg ) - 1;
                if( iReg >= x_MaxReg )
                {
                    InterlockedDecrement( &g_nReg );
                    break;
                }

                //
                // TODO: The provider should be setting this to pending if using NtDeviceIoControl.
                //
                g_MrContext[iReg].Ov.Internal = ND_PENDING;

                if( Register )
                {
                    HRESULT hr = g_pAdapter->RegisterMemory(
                        x_Buf,
                        szXfer,
                        &g_MrContext[iReg].Ov,
                        &g_MrContext[iReg].hMr );

                    if( FAILED( hr ) )
                    {
                        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
                        exit( __LINE__ );
                    }
                }
                else
                {
                    HRESULT hr = g_pAdapter->DeregisterMemory(
                        g_MrContext[iReg].hMr,
                        &g_MrContext[iReg].Ov );

                    if( FAILED( hr ) )
                    {
                        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );
                        exit( __LINE__ );
                    }
                }
            }
            //
            // Check the IOCP for completions.
            //
            DWORD BytesRet;
            ULONG_PTR Key;
            OVERLAPPED* pOv;
            BOOL fSuccess = GetQueuedCompletionStatus(
                g_hIocp,
                &BytesRet,
                &Key,
                &pOv,
                INFINITE
                );

            if( fSuccess == FALSE )
            {
                printf( "GetQueuedCompletionStatus failed with %d\n", GetLastError() );
                exit( __LINE__ );
            }

            SIZE_T BytesRet2;
            HRESULT hr = g_pAdapter->GetOverlappedResult( pOv, &BytesRet2, FALSE );
            if( FAILED( hr ) )
            {
                printf( "INDAdapter->GetOverlappedResult failed with %08x\n", hr );
                exit( __LINE__ );
            }

            InterlockedIncrement( &g_nMr );
            if( g_nMr == x_MaxReg && Register )
            {
                tMiddle = GetElapsedTime();
                cpuMiddle = GetCPUTime();
                //
                // Repeat the loop for deregistration.
                //
                Register = false;
                g_nMr = 0;
                g_nReg = 0;
            }
        }
        LONGLONG tEnd = GetElapsedTime();
        LONGLONG cpuEnd = GetCPUTime();
        LONGLONG ElapsedNanoSec1 = (tMiddle - tStart) * 1000000000I64 / Frequency / x_MaxReg;
        LONGLONG CpuNanoSec1 = ((cpuMiddle - cpuStart) * 100I64) / x_MaxReg;
        LONGLONG ElapsedNanoSec2 = (tEnd - tMiddle) * 1000000000I64 / Frequency / x_MaxReg;
        LONGLONG CpuNanoSec2 = ((cpuEnd - cpuMiddle) * 100I64) / x_MaxReg;
        printf(
            "%9Id %9Id %9.2f %7.2f %9.2f %7.2f\n",
            szXfer,
            x_MaxReg,
            (double) ElapsedNanoSec1 / 1000.0,
            (double) CpuNanoSec1 / (double) ElapsedNanoSec1 * 100.0,
            (double) ElapsedNanoSec2 / 1000.0,
            (double) CpuNanoSec2 / (double) ElapsedNanoSec2 * 100.0
            );
    }
    return 0;
}


int __cdecl main(int argc, char* argv[])
{
    ULONG Address = 0;
    DWORD nThreads = 1;

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 't':
        case 'T':
            nThreads = atol( ++pArg );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            Address = inet_addr( argv[i] );
            break;
        }
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( nThreads == 0 )
    {
        printf( "Invalid number of threads.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    g_hEvent = CreateEvent( NULL, TRUE, FALSE, NULL );
    if( g_hEvent == NULL )
    {
        printf( "CreateEvent failed with %d\n", GetLastError() );
        exit( __LINE__ );
    }

    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = 0;

    hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &g_pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    g_hIocp = CreateIoCompletionPort( g_pAdapter->GetFileHandle(), NULL, 0, 0 );
    if( g_hIocp == NULL )
    {
        printf( "Failed to bind adapter to IOCP, error %d\n", GetLastError() );
        exit( __LINE__ );
    }

    printf(
        "Using %d processors. Sender Frequency is %I64d\n",
        GetProcessorCount(),
        GetFrequency() );

    printf(
        "                         Register          Deregister\n"
        "     Size     Iter    usec      cpu       usec      cpu\n"
        );

    HANDLE* hThreads = new HANDLE[nThreads];
    if( hThreads == NULL )
    {
        printf( "Failed to allocate thread handle array\n" );
        exit( __LINE__ );
    }

    //for( DWORD i = 0; i < nThreads; i++ )
    //{
    //    hThreads[i] = CreateThread( NULL, 0, TestRoutine, NULL, 0, 0 );
    //    if( hThreads[i] == NULL )
    //    {
    //        printf( "CreateThread for thread %d of %d failed with %d.\n", i + 1, nThreads, GetLastError() );
    //        exit( __LINE__ );
    //    }
    //}

    ////
    //// Wait for the threads to exit.
    ////
    //for( DWORD i = 0; i < nThreads; i++ )
    //{
    //    WaitForSingleObject( hThreads[i], INFINITE );
    //    CloseHandle( hThreads[i] );
    //    hThreads[i] = NULL;
    //}
    TestRoutine( NULL );

    g_pAdapter->Release();

    CloseHandle( g_hIocp );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    _fcloseall();

    return 0;
}

