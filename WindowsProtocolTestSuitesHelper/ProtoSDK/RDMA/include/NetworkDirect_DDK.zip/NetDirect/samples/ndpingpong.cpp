// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//
// ndpingpong.cpp - Network Direct send/recv pingpong test
//

#include "precomp.h"

const SIZE_T x_MaxXfer = (4 * 1024 * 1024);
const SIZE_T x_HdrLen = 40;
const SIZE_T x_MaxVolume = (500 * x_MaxXfer);
const SIZE_T x_MaxIterations = 100000;

#define RECV    0
#define SEND    1

void ShowUsage()
{
    printf( "ndping s|c <ip> <port> b|p<nSge> [l<log>]\n"
        "\ts - start as server (listen on IP/Port)\n"
        "\tc - start as client (connect to server IP/Port)\n"
        "\t<ip> - IPv4 Address\n"
        "\t<port> - Port number\n"
        "\tb - blocking I/O (wait for CQ notification)\n"
        "\tp - polling I/O (Poll on the CQ)\n"
        "\t<nSge> - Number of scatter/gather entries per transfer.\n"
        "\tl - log output to a file named <log>.\n");
}

DWORD GetProcessorCount()
{
    SYSTEM_INFO SystemInfo;
    GetSystemInfo(&SystemInfo);
    return SystemInfo.dwNumberOfProcessors;
}

LONGLONG GetCPUTime()
{
    LONGLONG IdleTime;
    LONGLONG KernelTime;
    LONGLONG UserTime;
    GetSystemTimes(
        (FILETIME*)&IdleTime,
        (FILETIME*)&KernelTime,
        (FILETIME*)&UserTime
        );

    return (KernelTime + UserTime - IdleTime);
}

LONGLONG GetElapsedTime()
{
    LARGE_INTEGER elapsed;
    QueryPerformanceCounter(&elapsed);
    return elapsed.QuadPart;
}

void Server(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in SIZE_T QueueDepth,
    __in bool bUseEvents )
{
    struct sockaddr_in v4 = {0};

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    INDAdapter* pAdapter;
    HRESULT hr = NdOpenIAdapter( (const struct sockaddr*)&v4, sizeof(v4), &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    SIZE_T Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        printf( "Failed to allocate data buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        printf( "Failed to allocate SGL.\n" );
        exit( __LINE__ );
    }

    //
    // Listen and get incoming connection request.
    //
    INDListen* pListen;
    hr = pAdapter->Listen( 0, 234, Port, NULL, &pListen );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Listen failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x", hr );
        exit( __LINE__ );
    }

    hr = pListen->GetConnectionRequest( pConnector, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDListen::GetConnectionRequest failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Create a CQ.
    //
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( QueueDepth * 2, &pCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        QueueDepth,
        QueueDepth,
        nSge,
        nSge,
        0,
        0,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[2];
    if( Results == NULL )
    {
        printf( "Failed to allocate ND_RESULT array.\n" );
        exit( __LINE__ );
    }

    for( SIZE_T i = 0; i < nSge; i++ )
    {
        Sgl[i].pAddr = pBuf + (x_HdrLen * i);
        Sgl[i].Length = x_HdrLen;
        Sgl[i].hMr = hMr;
    }

    // Last SGE has the remainder of the data.
    Sgl[nSge - 1].Length = x_MaxXfer + x_HdrLen - (x_HdrLen * (nSge - 1));

    //
    // Pre-post receive request.
    //
    ND_SGE rSge;
    rSge.pAddr = pBuf;
    rSge.Length = x_MaxXfer + x_HdrLen;
    rSge.hMr = hMr;

    for( SIZE_T i = 0; i < QueueDepth; i++ )
    {
        hr = pEndpoint->Receive( &Results[RECV], &rSge, 1 );
        if( FAILED( hr ) )
        {
            printf( "INDEndpoint::Receive failed with %08x\n", hr );
            exit( __LINE__ );
        }
    }

    //
    // Accept the connection.
    //
    hr = pConnector->Accept(
        pEndpoint,
        NULL,
        0,
        pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pListen->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDListen::Accept failed with %08x\n", hr );
        exit( __LINE__ );
    }

    SIZE_T nSendPosted = 0;
    bool NeedSend = false;
    do
    {
        if( bUseEvents )
        {
            hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( hr == ND_PENDING )
            {
                SIZE_T BytesRet;
                hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
            }
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
        }

        SIZE_T nResults;
        SIZE_T BytesTransferred = 0;
        do
        {
            ND_RESULT* pResult;
            nResults = pCq->GetResults( &pResult, 1 );
            if( nResults == 0 )
                break;

            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                //
                // Only issue the next send/recv pair when all oustanding
                // requests have completed.
                //
                if( pResult == &Results[RECV] )
                {
                    BytesTransferred = pResult->BytesTransferred;
                    //
                    // Repost the receive.
                    //
                    hr = pEndpoint->Receive( &Results[RECV], &rSge, 1 );
                    if( FAILED( hr ) )
                    {
                        printf( "INDEndpoint::Receive failed with %08x\n", hr );
                        exit( __LINE__ );
                    }

                    NeedSend = true;
                }
                else
                {
                    nSendPosted--;
                }

                if( !NeedSend )
                    break;

                if( nSendPosted == QueueDepth )
                    break;

                //
                // Adjust last SGE to pong the same size we received.
                //
                Sgl[nSge - 1].Length = BytesTransferred - (x_HdrLen * (nSge - 1));

                hr = pEndpoint->Send( &Results[SEND], Sgl, nSge, 0 );
                if( FAILED( hr ) )
                {
                    printf( "INDEndpoint::Send failed with %08x\n", hr );
                    exit( __LINE__ );
                }
                NeedSend = false;
                nSendPosted++;

                __fallthrough;
            case ND_CANCELED:
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }

        } while( nResults != 0 );

    } while( hr == ND_SUCCESS );

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDEndpoint::Disconnect failed wtih %08x\n", hr );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    pListen->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}

HRESULT Send(
    __in INDEndpoint* pEndpoint,
    __in INDCompletionQueue* pCq,
    __in OVERLAPPED* pOv,
    __in ND_RESULT* Results,
    __in const ND_SGE* Sgl,
    __in const SIZE_T nSge,
    __in const ND_SGE* rSgl,
    __in SIZE_T QueueDepth,
    __in SIZE_T Iterations,
    __in bool bUseEvents )
{
    SIZE_T BytesTransferred = 0;
    for( SIZE_T i = 0; i < nSge; i++ )
        BytesTransferred += Sgl[i].Length;

    HRESULT hr = ND_SUCCESS;
    SIZE_T nSendPosted = 0;
    bool NeedSend = true;
    do
    {
        if( NeedSend && nSendPosted < QueueDepth )
        {
            //
            // Post send.
            //
            hr = pEndpoint->Send( &Results[SEND], Sgl, nSge, 0 );
            if( FAILED( hr ) )
            {
                printf( "INDEndpoint::Send failed with %08x\n", hr );
                exit( __LINE__ );
            }
            nSendPosted++;
            NeedSend = false;
        }

        if( bUseEvents )
        {
            hr = pCq->Notify( ND_CQ_NOTIFY_ANY, pOv );
            if( hr == ND_PENDING )
            {
                SIZE_T BytesRet;
                hr = pCq->GetOverlappedResult( pOv, &BytesRet, TRUE );
            }
            if( FAILED( hr ) )
            {
                printf( "INDCompletionQueue::Notify failed with %08x\n", hr );
                exit( __LINE__ );
            }
        }

        SIZE_T nResults;
        ND_RESULT* pResult;
        while( (nResults = pCq->GetResults( &pResult, 1 )) != 0 )
        {
            hr = pResult->Status;

            switch( hr )
            {
            case ND_SUCCESS:
                if( pResult->BytesTransferred != BytesTransferred )
                {
                    printf( "Received %d bytes, expected %d\n",
                        pResult->BytesTransferred, BytesTransferred );
                    exit( __LINE__ );
                }

                if( pResult == &Results[RECV] )
                {
                    //
                    // Repost receive.
                    //
                    hr = pEndpoint->Receive( &Results[RECV], rSgl, 1 );
                    if( FAILED( hr ) )
                    {
                        printf( "INDEndpoint::Receive failed with %08x\n", hr );
                        exit( __LINE__ );
                    }

                    NeedSend = true;
                    Iterations--;
                }
                else
                {
                    nSendPosted--;
                }

                __fallthrough;
            case ND_CANCELED:
                break;

            default:
                printf(
                    "INDCompletionQueue::GetResults returned result with %08x.\n",
                    pResult->Status );
                exit( __LINE__ );
            }
        }// while( nResults != 0 )

    } while( hr == ND_SUCCESS && Iterations != 0 );

    return hr;
}

void Client(
    __in OVERLAPPED* pOv,
    __in ULONG Address,
    __in USHORT Port,
    __in SIZE_T nSge,
    __in SIZE_T QueueDepth,
    __in bool bUseEvents )
{
    struct sockaddr_in v4 = {0};
    struct sockaddr_in LocalAddr;

    v4.sin_family = AF_INET;
    v4.sin_addr.s_addr = Address;
    v4.sin_port = Port;

    SIZE_T Len = sizeof(LocalAddr);
    HRESULT hr = NdResolveAddress(
        (const struct sockaddr*)&v4,
        sizeof(v4),
        (struct sockaddr*)&LocalAddr,
        &Len );
    if( FAILED( hr ) )
    {
        printf( "NdResolveAddress failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDAdapter* pAdapter;
    hr = NdOpenIAdapter(
        (const struct sockaddr*)&LocalAddr,
        sizeof(LocalAddr),
        &pAdapter );
    if( FAILED( hr ) )
    {
        printf( "NdOpenIAdapter failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_ADAPTER_INFO Info;
    Len = sizeof(Info);
    hr = pAdapter->Query( 1, &Info, &Len );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::Query failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and register the data buffer.
    //
    char* pBuf = (char*)HeapAlloc( GetProcessHeap(), 0, x_MaxXfer + x_HdrLen );
    if( !pBuf )
    {
        printf( "Failed to allocate data buffer.\n" );
        exit( __LINE__ );
    }

    ND_MR_HANDLE hMr;
    hr = pAdapter->RegisterMemory( pBuf, x_MaxXfer + x_HdrLen, pOv, &hMr );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::RegisterMemory failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Allocate and setup the SGE for all the transfers.
    // Note that all the transfers overlap, so data verification
    // is not possible.
    //
    ND_SGE* Sgl = new( std::nothrow ) ND_SGE[nSge];
    if( Sgl == NULL )
    {
        printf( "Failed to allocate SGL.\n" );
        exit( __LINE__ );
    }

    //
    // Create a CQ.
    //
    INDCompletionQueue* pCq;
    hr = pAdapter->CreateCompletionQueue( QueueDepth * 2, &pCq );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateCompletionQueue failed with %08x\n", hr );
        exit( __LINE__ );
    }

    INDConnector* pConnector;
    hr = pAdapter->CreateConnector( &pConnector );
    if( FAILED( hr ) )
    {
        printf( "INDAdapter::CreateConnector failed with %08x", hr );
        exit( __LINE__ );
    }

    INDEndpoint* pEndpoint;
    hr = pConnector->CreateEndpoint(
        pCq,
        pCq,
        QueueDepth,
        QueueDepth,
        nSge,
        nSge,
        0,
        0,
        NULL,
        &pEndpoint
        );
    if( FAILED( hr ) )
    {
        printf( "INDConnector::CreateEndpoint failed with %08x\n", hr );
        exit( __LINE__ );
    }

    ND_RESULT* Results = new( std::nothrow ) ND_RESULT[2];
    if( Results == NULL )
    {
        printf( "Failed to allocate ND_RESULT array.\n" );
        exit( __LINE__ );
    }

    //
    // Connect to the server.
    //
    hr = pConnector->Connect(
        pEndpoint,
        (const struct sockaddr*)&v4,
        sizeof(v4),
        234,
        0,
        NULL,
        0,
        pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::Connect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    //
    // Pre-post receive request.
    //
    ND_SGE rSge;
    rSge.pAddr = pBuf;
    rSge.Length = x_HdrLen + x_MaxXfer;
    rSge.hMr = hMr;
    for( SIZE_T i = 0; i < QueueDepth; i++ )
    {
        hr = pEndpoint->Receive( &Results[RECV], &rSge, 1 );
        if( FAILED( hr ) )
        {
            printf( "INDEndpoint::Receive failed with %08x\n", hr );
            exit( __LINE__ );
        }
    }

    //
    // Complete the connection - this transitions the endpoint so it can send.
    //
    hr = pConnector->CompleteConnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) || hr == ND_TIMEOUT )
    {
        printf( "INDEndpoint::CompleteConnect failed with %08x\n", hr );
        exit( __LINE__ );
    }

    LARGE_INTEGER Frequency;
    QueryPerformanceFrequency(&Frequency);
    printf( "Using %d processors. Sender Frequency is %I64d\n",
        GetProcessorCount(),
        Frequency.QuadPart );

    //
    // Warm up run, transfer only header.
    //
    Sgl[0].pAddr = pBuf;
    Sgl[0].Length = x_HdrLen;
    Sgl[0].hMr = hMr;

    hr = Send(
        pEndpoint,
        pCq,
        pOv,
        Results,
        Sgl,
        1,
        &rSge,
        QueueDepth,
        1000,
        false );
    if( FAILED( hr ) )
    {
        printf( "Connection unexpectedly aborted.\n" );
        exit( __LINE__ );
    }

    Sleep(1000);

    for( SIZE_T szXfer = 1; szXfer <= x_MaxXfer; szXfer <<= 1 )
    {

        for( SIZE_T i = 0; i < nSge; i++ )
        {
            Sgl[i].pAddr = pBuf + (x_HdrLen * i);
            Sgl[i].Length = x_HdrLen;
            Sgl[i].hMr = hMr;
        }

        // Last SGE has the remainder of the data.
        Sgl[nSge - 1].Length = x_HdrLen + szXfer - (x_HdrLen * (nSge - 1));

        SIZE_T Iterations = x_MaxIterations;
        if( (Iterations * szXfer) > x_MaxVolume )
            Iterations = x_MaxVolume / szXfer;

        LONGLONG cpuStart = GetCPUTime();
        LONGLONG tStart = GetElapsedTime();

        hr = Send(
            pEndpoint,
            pCq,
            pOv,
            Results,
            Sgl,
            nSge,
            &rSge,
            QueueDepth,
            Iterations,
            bUseEvents );
        if( FAILED( hr ) )
        {
            printf( "Connection unexpectedly aborted.\n" );
            exit( __LINE__ );
        }
        LONGLONG tEnd = GetElapsedTime();
        LONGLONG cpuEnd = GetCPUTime();

        LONGLONG ElapsedNanoSec = (tEnd - tStart) / Iterations / 2I64* 1000000000I64 / Frequency.QuadPart;
        LONGLONG CpuNanoSec = ((cpuEnd - cpuStart) * 100I64 / Iterations / 2I64 );
        LONGLONG BytesSec = szXfer * 1000000000I64 / ElapsedNanoSec;

        double elapsed = (double) ElapsedNanoSec / 1000.0;
        double cpu = (double) CpuNanoSec / (double) ElapsedNanoSec * 100.0;
        printf(" %9Id %9Id %9.2f %7.2f %11I64d\n", szXfer, Iterations, elapsed, cpu, BytesSec);
    }

    //
    // Test is complete.  Note that during teardown we don't treat
    // errors as test failures, but we still report them.
    //
    hr = pConnector->Disconnect( pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pConnector->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDEndpoint::Disconnect failed wtih %08x\n", hr );

    pEndpoint->Release();
    pConnector->Release();
    pCq->Release();

    hr = pAdapter->DeregisterMemory( hMr, pOv );
    if( hr == ND_PENDING )
    {
        SIZE_T BytesRet;
        hr = pAdapter->GetOverlappedResult( pOv, &BytesRet, TRUE );
    }
    if( FAILED( hr ) )
        printf( "INDAdapter::DeregisterMemory failed with %08x\n", hr );

    pAdapter->Release();

    delete[] Results;
    delete[] Sgl;
    HeapFree( GetProcessHeap(), 0, pBuf );
}


int __cdecl main(int argc, char* argv[])
{
    bool bServer = false;
    bool bClient = false;
    ULONG Address = 0;
    USHORT Port = 0;
    SIZE_T nSge = 0;
    SIZE_T QueueDepth = 6;
    bool bPolling = false;
    bool bBlocking = false;

    for( int i = 1; i < argc; i++ )
    {
        const char* pArg;

        pArg = argv[i];

        // Skip leading dashes/slashes
        while( *pArg == '-' || *pArg == '/' )
            pArg++;

        switch( *pArg )
        {
        case 's':
        case 'S':
            bServer = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'c':
        case 'C':
            bClient = true;
            if( ++i == argc )
                break;
            Address = inet_addr( argv[i] );
            if( ++i == argc )
                break;
            Port = htons( (USHORT)atol( argv[i] ) );
            break;
        case 'p':
        case 'P':
            bPolling = true;
            nSge = atol( ++pArg );
            break;
        case 'b':
        case 'B':
            bBlocking = true;
            nSge = atol( ++pArg );
            break;
        case 'l':
        case 'L':
//
// Can't use freopen_s because it doesn't allow sharing.
// So supress the deprecated warning, because for our use
// it isn't deprecated.
//
#pragma warning( disable : 4996 )
            if( freopen( ++pArg, "w", stdout ) == NULL ||
                freopen( pArg, "a+", stderr ) == NULL )
#pragma warning( default : 4996 )
            {
                printf( "Could not open log file.\n" );
                exit( __LINE__ );
            }
            break;
        default:
            printf( "Unknown parameter %s\n", pArg );
            ShowUsage();
            exit( __LINE__ );
        }
    }

    if( (bClient && bServer) || (!bClient && !bServer) )
    {
        printf( "Exactly one of client (c or "
            "server (s) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( Address == 0 )
    {
        printf( "Bad address.\n");
        ShowUsage();
        exit( __LINE__ );
    }

    if( Port == 0 )
    {
        printf( "Bad port.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( (bPolling && bBlocking) || (!bPolling && !bBlocking) )
    {
        printf( "Exactly one of blocking (b or "
            "polling (p) must be specified.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    if( nSge == 0 )
    {
        printf( "Invalid or missing SGE, expected positive integer after p or b.\n" );
        ShowUsage();
        exit( __LINE__ );
    }

    OVERLAPPED Ov;
    Ov.hEvent = CreateEvent( NULL, FALSE, FALSE, NULL );
    if( Ov.hEvent == NULL )
    {
        printf( "Failed to allocate event for overlapped operations.\n" );
        exit( __LINE__ );
    }

    HRESULT hr = NdStartup();
    if( FAILED(hr) )
    {
        printf( "NdStartup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    if( bServer )
        Server( &Ov, Address, Port, nSge, QueueDepth, bBlocking );
    else
        Client( &Ov, Address, Port, nSge, QueueDepth, bBlocking );

    hr = NdCleanup();
    if( FAILED(hr) )
    {
        printf( "NdCleanup failed with %08x\n", hr );
        exit( __LINE__ );
    }

    CloseHandle( Ov.hEvent );

    _fcloseall();

    return 0;
}
